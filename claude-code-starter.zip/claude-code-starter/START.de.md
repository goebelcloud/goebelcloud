# Claude Code Starter

Drei Dinge liegen in diesem Ordner. Du brauchst am Anfang nur das erste.

| Was | Wofür |
| --- | --- |
| **START.de.md** / **START.md** | Diese Seite. Der Einstieg in zehn Minuten. |
| **handbook.html** | Das Nachschlagewerk. Deutsch und Englisch, umschaltbar. 30 Kapitel in sieben Stufen — du liest, was du brauchst, wenn du es brauchst. |
| **template/** | Das Projekt-Template. Kommt erst in Schritt 4 dran. |

---

## Schritt 0 — Was du mitbringen solltest

Ein Terminal bedienen, Git in Grundzügen, wissen, was ein Test und ein Linter tun. Fehlt
davon etwas, ist das kein Hindernis — aber lies zuerst **Anhang H** im Handbuch: jeder
Begriff in drei Sätzen und ein Link, der weiterführt. Wer „Exit-Code" oder „rot und grün"
nicht kennt, steigt sonst in Kapitel 1 aus.

## Schritt 1 — Installieren (5 Minuten)

```bash
# macOS, Linux, WSL
curl -fsSL https://claude.ai/install.sh | bash

# Windows — empfohlen: der Paketmanager von Microsoft
winget install Anthropic.ClaudeCode
```

Dann in irgendein Projektverzeichnis wechseln und `claude` eintippen. Der Browser öffnet
sich, du meldest dich mit deinem Claude-Konto an. Die Anmeldung hält einige Stunden bis
Tage; wenn Claude nach `/login` fragt, ist das normal. Firma mit AWS Bedrock und SSO?
Handbuch Kapitel 2, Weg D.

**Windows, zwei Dinge dazu:** winget aktualisiert nicht von selbst — Claude Code ändert
sich wöchentlich, also regelmäßig `winget upgrade Anthropic.ClaudeCode` ausführen. Und ohne
WSL **Git for Windows** mitinstallieren, sonst fehlt später die Bash. Wo winget nicht
verfügbar ist, geht auch `irm https://claude.ai/install.ps1 | iex` in PowerShell; das
aktualisiert sich selbst, führt aber ein Skript aus dem Netz aus.

→ Handbuch Kapitel 2, wenn etwas hakt. Wer über AWS Bedrock arbeitet: dort steht auch, was
damit nicht geht (Remote Control, Web, Advisor, Web-Suche) und was stattdessen.

## Schritt 2 — Laborübung: eine Session in fremdem Code (30 Minuten)

> **Übung, kein Ergebnis.** Was du hier tust, bringt deinem Vorhaben nichts. Du lernst, wie
> Claude Code liest, fragt, ändert und stoppt — an Code, der dir egal ist. Dein eigenes Projekt
> beginnt in Schritt 4, mit einer Spec statt mit Code.
>
> ⚠ **Nicht in einem Firmen-Repository.** Claude Code ändert Dateien, im Auto-Modus ohne
> Nachfrage. Im schlimmsten Fall wird Code geändert und committet, bevor du verstehst, was
> passiert. Nimm einen frischen Klon in einem eigenen Ordner, ein altes Privatprojekt oder
> ein öffentliches Repository.

Nicht im wichtigen Repository, aber eines mit Code drin — ein altes Projekt, oder ein geklontes
öffentliches Repository. Ein leerer Ordner taugt nicht. Dann probiere:

```
> Was tut dieses Projekt?
> Erklär mir, wie <irgendeine Datei> funktioniert.
> Füge in <Datei> eine Funktion hinzu, die <etwas Kleines> tut.
```

Claude liest, was es braucht. Bei Änderungen fragt es nach — oder auch nicht, je nach
Permission-Modus (`Shift+Tab` schaltet ihn um). Etwas falsch gelaufen? `Esc Esc` öffnet
das Menü zum Zurücksetzen.

Fünf Dinge reichen für die erste Woche: `claude` starten · `Shift+Tab` für den Plan-Modus ·
`Esc` zum Unterbrechen · `/clear` zwischen unabhängigen Aufgaben · `claude -c` zum
Fortsetzen.

→ Handbuch Kapitel 3 bis 7. Das ist Stufe 1. Danach ein paar Tage einfach arbeiten.

## Schritt 3 — Zwei Dinge wissen, bevor es ernst wird

**Permissions.** Auf Pro-, Max- und Team-Abos startet eine Terminal-Session im
Auto-Modus: ein Prüfmodell entscheidet statt dir. Bequem, aber du solltest es wissen.
→ Kapitel 6.

**Kontext.** Claudes Arbeitsgedächtnis für eine Unterhaltung ist begrenzt, und die
Antworten werden schlechter, je voller es ist. `/clear` zwischen unabhängigen Aufgaben
ist das Gegenmittel. → Kapitel 7.

## Schritt 4 — Ein eigenes Projekt mit dem Template (ein Nachmittag)

Voraussetzungen: `git`, `node`, `jq` und `task` (go-task). Fehlt etwas, sagt es dir der
nächste Schritt.

```bash
mkdir mein-projekt && cd mein-projekt && git init
cp -r /pfad/zu/claude-code-starter/template/. .
claude
```

```
> /setup Ich will <was du bauen willst>. 
```

Das ist der ganze Befehl. Den Stack musst du nicht nennen — er fragt.

**Im Terminal, nicht in der VS-Code-Erweiterung.** Die Erweiterung kennt nur eine Teilmenge
der Befehle und Skills. Wer in VS Code bleiben will: integriertes Terminal öffnen und dort
`claude` starten — das braucht die CLI-Installation aus Schritt 1.

Was dann passiert, in drei Phasen, und er hält vor jeder auf dein Ja an:

1. **Verstehen.** Er interviewt dich, eine Frage nach der anderen, jede mit einem
   Vorschlag: Ziel, Nutzer, was „fertig" heißt, was ausdrücklich nicht dazugehört, Stack,
   Grenzen, Daten, was unumkehrbar ist. Acht bis zwölf Fragen. Am Ende zeigt er dir eine
   einseitige Projektbeschreibung und fragt: *Ist das das Projekt?* Daraus entstehen die
   ersten Entscheidungen, das erste Feature mit Kriterien und die ersten Aufgaben.
   Noch keine Zeile Code. Und kein `/init` — das ist nur für bestehenden Code; hier entsteht die CLAUDE.md aus der Spec.
2. **Toolkette.** Aus deinem Stack leitet er Formatter, Linter, Sicherheitsscanner,
   Testrunner und die Hooks ab, installiert und verdrahtet sie — und macht dann **jede
   Prüfung einmal absichtlich rot**, damit du weißt, dass sie wirklich prüft. Ende:
   `task chain` ist grün. Immer noch keine Zeile Code.
3. **Übergabe.** Er räumt sich weg und sagt: `/task next`.

Ab jetzt läuft jede Arbeit gleich: `/task next` nimmt die nächste Aufgabe, baut sie auf
einem eigenen Branch, testet, öffnet den Pull Request, lässt Code- und Security-Review
laufen. `/closeout` schließt sie ehrlich ab. `/feature` legt das nächste Feature an,
`/decide` hält eine Entscheidung fest.

→ Kapitel 8 (was ein Projekt mindestens braucht) und Kapitel 29 (das Template).

## Schritt 5 — Weiterlesen, wenn dich etwas stört

Erst dann. Das Handbuch löst Probleme, die du noch nicht hast:

| Wenn… | dann… |
| --- | --- |
| Claude in generierte Dateien schreibt oder Regeln ignoriert | Kapitel 13–19: Harness, Hooks, Guardrails |
| du zwei Dinge gleichzeitig laufen lassen willst | Kapitel 20–22: Worktrees, Hintergrund-Sessions |
| du über Nacht arbeiten lassen willst | Kapitel 24: Unbeaufsichtigt |
| dieselben Fehler immer wieder passieren | Kapitel 25–28: Arbeitsweise und Fehlerbilder |

---

Was dieses Paket **nicht** ist: ein Tool, das dir das Denken abnimmt. Das Template
stellt Fragen, weil die Antworten deine sind. Wenn du eine nicht beantworten kannst, nimmt
sie den Vorschlag, markiert ihn als Annahme und macht weiter — und du siehst es.

Stand: September 2026, Claude Code ≈ 2.1. Bei Abweichungen gilt `/help` und die Doku
unter code.claude.com.
