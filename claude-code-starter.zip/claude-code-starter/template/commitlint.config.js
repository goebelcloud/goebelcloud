// Conventional Commits. The commit-msg hook calls commitlint; nothing hand-rolled beside it.
export default { extends: ['@commitlint/config-conventional'] };
