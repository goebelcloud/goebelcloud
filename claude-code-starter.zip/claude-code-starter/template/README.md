# Claude Code project template

A starting layout for any repository worked on with Claude Code. It contains three things
and nothing else:

1. **What Anthropic documents** for Claude Code — a short `CLAUDE.md`, permission scoping,
   two hooks for things that must happen deterministically, read-only subagents, skills.
2. **Standard tools** in place of anything home-grown — Backlog.md for work tracking,
   secretlint for leaks, commitlint for messages, and the linter/formatter/security scanner
   each language community already uses (`docs/TOOLS.md`).
3. **One workflow**: decision → feature → task, each a Backlog.md entity, each task one
   pull request (`docs/WORKFLOW.md`), under engineering guidelines that apply to any
   language (`docs/ENGINEERING_GUIDELINES.md`).

Everything here has a source you can check: the Claude Code docs at code.claude.com, the
tools' own docs, or a widely adopted practice named in the file. Nothing is a private
convention.

## Start here

```
mkdir my-project && cd my-project && git init
<copy this template's files into the folder>
claude
> /setup I want to build <what>   (stack optional — it will ask)
```

`/setup` runs three phases and stops for your yes between them:

1. **Understand** — it interviews you, one question at a time with a suggested answer,
   until it can write a one-page project spec. From the spec it records the decisions,
   the first feature with acceptance criteria, and its tasks. No code.
2. **Toolchain** — from your stack and the spec it derives the formatter, linter, security
   scanner, test runner, secretlint, commitlint and the hooks, installs and wires them,
   and then drives **every station red once** so you know each one can fail. Ends with a
   green `task chain`. Still no code.
3. **Hand over** — commits, deletes itself, and tells you: `/task next`.

Nothing else in the template needs editing to get started. The harness — settings, hooks,
rules — is derived; you do not have to know it exists.

## What is where

```
CLAUDE.md                     always-loading instructions; short; points at docs/
.claude/settings.json         permission scoping + deny list + two hooks
.claude/settings.local.json.example   per-machine overrides (gitignored copy)
.claude/hooks/                format-after-edit · protect-generated (tested by repro/hooks-fire.sh)
.claude/rules/                path-scoped rules by file KIND: code · tests · infra
.claude/agents/               explore (haiku, read-only) · reviewer (opus, read-only)
.claude/skills/               setup · decide · feature · task · closeout · grilling
docs/ENGINEERING_GUIDELINES.md            engineering rules, language-independent
docs/WORKFLOW.md              decision → feature → task with Backlog.md
docs/TOOLS.md                 the standard tool per language, and why
docs/SPEC_TEMPLATE.md         the one-page project spec /setup writes
scripts/hooks/                git hooks: commit (fast, staged-scoped) · push (full chain) · commit-msg
scripts/qa/repro/hooks-fire.sh   proves the two Claude hooks fire
Taskfile.yml                  fmt · lint · test · build · secrets · audit · chain · repo:prepare
.secretlintrc.json · commitlint.config.js · .editorconfig · .gitattributes · .worktreeinclude
```

## Principles the template applies to itself

- **YAGNI.** No config flag without a consumer, no abstraction over a tool nobody plans to
  replace, no check without a documented reason. If you cannot say what a file is for,
  delete it.
- **Adopt the standard and delete your half.** If a maintained tool covers a rule, the rule
  is the tool's config, not a script beside it.
- **A check that has never failed is unproven.** The two Claude hooks ship with a script
  that drives them red and green. Every gate you add to the chain should be able to fail;
  run `task chain` once with a deliberate defect before trusting its green.
- **Manual mode is the tool's job, not a prompt's.** What must never happen is a deny rule
  or a hook, not a sentence in `CLAUDE.md`.

## Prerequisites

`git`, `bash` (on Windows: Git Bash or WSL), `jq`, `node` (for secretlint, commitlint,
Backlog.md), and `go-task` (`task`). `/setup` checks for them and tells you what is
missing. The formatter, linter and scanner for your stack are installed by `/setup`
from `docs/TOOLS.md`.

## Terminal, not the IDE extension

The skills in this template (`/setup`, `/task`, …) are built for the terminal CLI. The VS
Code extension exposes only a subset of commands and skills (type `/` there to see what is
available) and cannot show worktrees, background sessions or the status line. Anthropic's
documented route for CLI-only features is to run `claude` in VS Code's integrated terminal,
which requires the standalone CLI install. Hooks, permissions and MCP settings are shared
between both.

## AWS Bedrock, Vertex, Foundry, gateways

Everything in this template runs locally and works on every provider. What differs:
sessions start in **Manual** mode on third-party providers (turn auto mode on in your user
settings if you want it; Sonnet 5, Opus 4.7+ or Fable 5 only); `WebSearch` is unavailable
on Bedrock (`WebFetch` with a URL works); and the claude.ai-only extras — Remote Control,
`/schedule`, the Code Review GitHub app, `/code-review ultra`, Advisor, Channels — are not
available. `/setup` detects the provider and adjusts. Keep provider env in
`.claude/settings.local.json`, not in the committed file. Full list: the handbook, chapter 2.

## Windows

The hooks are Bash and registered with `"shell": "bash"`; they run under Git Bash or WSL.
Without one of those they do not run — silently. Verify with `claude --debug` that the
`PostToolUse` hook fires before trusting the setup on a Windows machine.
