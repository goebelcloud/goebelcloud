# Workflow: decision → feature → task

## Before any code: three phases, run by `/setup`

| Phase | Produces | Accepted when |
| --- | --- | --- |
| **1 Understand** — an interview, one question at a time | the **project spec** (`backlog doc`), decisions (ADRs), the first feature with acceptance criteria, its tasks | the owner confirms "this is the project" |
| **2 Toolchain** — derived from the stack and the spec, not interviewed | the **harness**: CLAUDE.md, permissions, Taskfile, git hooks, Claude hooks, Backlog.md definition of done | every station was driven red once and `task chain` is green |
| **3 Build** — `/task next` | code, one PR per task | each PR passed both reviews and `/closeout` |

The process spec — this document — is not interviewed. The template brings it; phase 1
sets three parameters (solo/team, irreversible actions, release policy). Nothing else
about the process is decided per project.


Every unit of work has a home in Backlog.md, and every entity has a CLI command. Nothing
about work lives in a chat message, a stray markdown file or someone's memory.

| Entity | What it is | Backlog.md | Skill |
| --- | --- | --- | --- |
| **Decision** | Something expensive to reverse: a library, a data model, an API shape, a policy. Also decisions *turned down*. | `backlog decision create` | `/decide` |
| **Feature** | A user-visible outcome that is more than one PR. Carries acceptance criteria and names its proof. | `backlog task create --type feature` (parent task) | `/feature` |
| **Task** | One unit of work = one branch = one pull request. Child of a feature (or a standalone chore/bug). | `backlog task create -p <feature>` | `/task` |
| **Closeout** | The honest end of a task: criteria verified, gates named, summary written. | `backlog task edit --final-summary -s Done` | `/closeout` |

Why three levels and not two: without features, tasks accumulate that nobody asked for;
without decisions, the same argument is had again in three months. Why not four: a
milestone is a Backlog.md label on features (`backlog milestone add`), not a new entity.

## The loop, for a human or a session

```
/feature  "Users can log in with Google"      → feature + 3–7 tasks, each one PR
/task next                                    → verify premise · branch · plan · build · test · PR · reviews
/closeout                                     → criteria · gates · not-checked · summary · Done
/task next
```

A task may only originate from a feature, from a self-found defect during a task, or
from a decision's consequences. A task nobody can trace to one of those is deleted, not
worked.

## Rules that make the loop hold

1. **Verify the premise before working an item.** Does what the task asserts still
   describe the tree? If not, correct the task and take the next one. Autonomy
   multiplies a false premise by the hours nobody is watching.
2. **One state change per call.** Creating a branch, switching a worktree or a cloud
   context runs alone, and its result is read before the next command.
3. **Self-found defects become tasks**, not inline fixes, unless they block the task in
   hand. A fix swimming inside unrelated work cannot be reviewed.
4. **The session opens and reviews the PR itself.** `gh pr create`, then `/code-review`
   and `/security-review` on the PR; each finding fixed or refused in one written line.
   Handing a human a command to run is a missing step with a person standing in it.
5. **A clean review is a second pair of eyes, never a gate.** The gate is `task chain`.
6. **Done means:** every acceptance criterion checked, chain green, reviews run, final
   summary written. A summary says what was checked AND what was not.

## What an unattended session does not decide

File it as a task or a comment, say so in one line, take the next piece of work:
- anything irreversible — deploy, force-push, delete outside the task's scope, anything
  visible outside the repository
- a red gate where "broken check or real defect?" changes what gets edited
- skipping/retrying/muting a test, or changing the environment until red goes away
- abandoning an approach, or building a new check
- a question the owner reserved by name (label `owner-decision`)

## Reading Backlog.md as a session

`backlog task list -s "To Do" --plain` · `backlog task <id> --plain` ·
`backlog search "<term>" --plain` · `backlog decision create` · `backlog instructions overview`
for the tool's own workflow guide. Never edit the markdown files by hand.
