# Project spec — <name>

<!-- Written by /setup from the interview. One page. Every "(assumed)" was decided by the
     recommended answer, not by the owner — confirm or change it. -->

## Goal
<One sentence a stranger understands.>

## Users and what they do
<Who, and what they do with it on a normal day.>

## Done for the first milestone
<The smallest thing that is useful end to end. This becomes the first feature.>

## Non-goals
- <deliberately not doing this>
- <deliberately not doing this>

## Stack
<Languages, runtime, cloud, data stores — and why, if it was a choice (→ decision id).>

## Constraints
<Must-use tools or platforms, compliance, offline/online, time or money.>

## Data and secrets
<What flows in and out, what is sensitive, where secrets live (a store, never the repo).>

## Irreversible actions in this project
<Deploy, delete, spend, send — each becomes a deny rule and is never run unattended.>

## Team and release
<Solo or team; branch policy; how a release happens.>

## Quality bar
<What must never ship broken — the paths the tests must cover.>

## Later milestones
<One line each. No tasks are created for these until the first milestone is done.>

## Decisions
<decision ids from Backlog.md>
