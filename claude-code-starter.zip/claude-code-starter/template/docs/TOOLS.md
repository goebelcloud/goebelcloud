# Standard tools per language

The rule: adopt the tool the language community already uses, and delete anything of
ours it makes redundant. `/setup` wires the row for your stack into `Taskfile.yml`.
Versions are deliberately absent — install the current release.

| Stack | Formatter | Linter / static analysis | Security | Tests | Install hint |
| --- | --- | --- | --- | --- | --- |
| TypeScript / Node | prettier | eslint + typescript-eslint + eslint-plugin-sonarjs; `tsc --noEmit` | `npm audit` | vitest | `npm i -D eslint prettier vitest typescript typescript-eslint eslint-plugin-sonarjs` |
| Python | ruff format | ruff check, mypy | bandit, pip-audit | pytest | `pip install ruff mypy pytest bandit pip-audit` |
| Go | gofmt, goimports | golangci-lint (errcheck, staticcheck, gosec enabled) | govulncheck | go test | `go install github.com/golangci/golangci-lint/cmd/golangci-lint@latest` |
| Terraform | terraform fmt | tflint, terraform validate | trivy config or checkov | terraform test | `brew install tflint trivy` / `pip install checkov` |
| KQL | — | — (none widely adopted) | secretlint only | validate against a cluster or the Kusto emulator | `az extension add -n log-analytics` |
| PowerShell | Invoke-Formatter | PSScriptAnalyzer (PSGallery rules incl. security) | in analyzer | Pester | `Install-Module PSScriptAnalyzer, Pester` |
| Shell | shfmt | shellcheck | in shellcheck | bats-core | `apt install shellcheck shfmt` / `brew install …` |
| Docker | — | hadolint | trivy image | `compose config` | `brew install hadolint trivy` |
| Rust | rustfmt | clippy `-D warnings` | cargo audit | cargo test | `cargo install cargo-audit` |
| Java / Kotlin | spotless | checkstyle / detekt, SpotBugs, PMD | OWASP dependency-check | JUnit 5 | gradle plugins |
| C# / .NET | dotnet format | Roslyn analyzers, `TreatWarningsAsErrors` | `dotnet list package --vulnerable` | xUnit | NuGet `Microsoft.CodeAnalysis.NetAnalyzers` |
| SQL | sqlfluff fix | sqlfluff lint | secretlint | migration tool's tests | `pip install sqlfluff` |

## Cross-cutting, every project

| Concern | Tool | Where it runs |
| --- | --- | --- |
| Secrets in commits | **secretlint** (`@secretlint/secretlint-rule-preset-recommend`) | pre-commit on staged files; pre-push on the tree |
| Commit messages | **commitlint** (`@commitlint/config-conventional`) | commit-msg hook |
| Work tracking | **Backlog.md** | `backlog` CLI |
| Task runner | **go-task** (`Taskfile.yml`) — one file, one name per check; make/just are fine if you keep the task names | everywhere |
| Deeper static analysis (optional) | **SonarQube / SonarCloud** with the language's analyzer — the SonarJS rules are already in eslint-plugin-sonarjs for TS | CI |
| Code review | `/code-review`, `/security-review` (Claude Code) on the PR | after push |
| Self-review while coding | **security-guidance** plugin (Anthropic) — Claude checks its own changes for vulnerabilities in-session | every session; installed by `/setup` |
| Codebase security scan | **Claude Security** plugin (Anthropic) — scans the tree, turns findings into patches | on adoption, then periodically |
| Automated PR review (claude.ai Team/Enterprise only; on Bedrock use GitHub Actions) | **Code Review** GitHub app (Anthropic) — multi-agent review over the whole codebase on every PR; `/code-review ultra` for a verified deep review | once there is a team or unattended PRs |

## What was considered and not adopted

- **husky** — git's own `core.hooksPath` is the standard; `task repo:prepare` sets it.
  A wrapper over one setting adds a dependency and deletes nothing.
- **A home-grown secret scanner** — secretlint covers published credential formats.
  For project-private identifiers (hostnames, internal names) add a custom secretlint
  rule or a `.secretlintrc` pattern rather than a script.
- **A text matcher over shell commands as a Claude hook** — measured in a prior project:
  four hardening rounds, each with a new hole, 21 false refusals, zero catches. What must
  never run is a `permissions.deny` entry, not a regex.
