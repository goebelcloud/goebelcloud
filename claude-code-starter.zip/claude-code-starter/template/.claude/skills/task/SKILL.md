---
name: task
description: Work one Backlog.md task as one unit — verify its premise, branch, implement, test, open the PR, review. Use with a task id ("/task 12") or "next" for the next eligible task.
disable-model-invocation: true
---
Task: $ARGUMENTS

1. **Pick.** If the argument is `next`: `backlog task list -s "To Do" --plain`, take the
   first whose dependencies are done and that is not labelled `owner-decision`. Otherwise
   `backlog task <id> --plain`.
2. **Verify the premise before doing any of the work.** Does the file it names exist? Is
   the defect still there? Was it already fixed? If the premise is false: correct the task
   (`backlog task edit <id> --append-notes "premise: ..."`), say so, and stop.
3. **Start.** `backlog task edit <id> -s "In Progress"`. Create the branch alone in its own
   call: `git checkout -b task/<id>-<slug>`; read the result before the next command.
   For parallel work use a worktree instead: `claude -w task-<id>`.
4. **Plan, then build.** Write a short implementation plan into the task
   (`--plan`), then implement. Write or extend the test that proves the acceptance
   criteria; run `task test` and `task lint`. Commit after each sub-step lands, explicit
   paths only, conventional message.
5. **Self-found defects** become new tasks (`backlog task create ... --dep <this>`), not
   inline fixes — unless they block this task.
6. **Finish.** Check each acceptance criterion only when it is actually met
   (`--check-ac N`). Push. `gh pr create` from the session. Run `/code-review` and
   `/security-review` on the PR; fix each finding or refuse it in one written line in the
   PR. Then `/closeout`.
