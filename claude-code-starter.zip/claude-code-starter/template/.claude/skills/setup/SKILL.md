---
name: setup
description: Set up a new project from the template in three phases — understand it in conversation, build and prove the toolchain, then hand over to /task. Run once, in an empty repository. Say what you want to build; the stack is optional.
disable-model-invocation: true
argument-hint: "<what you want to build> [with <stack>]"
---
Set up this project: $ARGUMENTS

Three phases, in order. **No project code is written before phase 2 is accepted.**
Ask questions **one at a time**, each with a recommended answer. Look up what can be
looked up (the tree, installed tools) instead of asking. Keep the user informed in one
line per step; do not narrate tool calls.

---

## Phase 1 — Understand the project (produces the project spec)

### 1.1 Pre-flight
`git rev-parse --git-dir` must succeed. If `CLAUDE.md` has no 🔧 markers, ask whether to
re-run; stop on no.

Detect the **provider**: `CLAUDE_CODE_USE_BEDROCK`, `CLAUDE_CODE_USE_VERTEX`,
`CLAUDE_CODE_USE_FOUNDRY` or a non-Anthropic `ANTHROPIC_BASE_URL` in the environment or in
`~/.claude/settings.json` means a third-party provider. Say which one you found in one
line. It changes phase 2 (see 2.5) and nothing in phase 1.

### 1.2 Interview
Apply the `grilling` skill's method to the project: one question at a time, with a
recommended answer, walking the decision tree until the spec below can be written
without guessing. Cover, in this order, skipping anything the argument already answers:

1. **Goal** — what exists when this is done, in one sentence a stranger understands.
2. **Users** — who uses it, and what they do with it on a normal day.
3. **Done for the first milestone** — the smallest thing that is useful end to end.
4. **Non-goals** — what this project deliberately does not do (at least two).
5. **Stack** — language(s), runtime, cloud, data stores. Match against `presets/*.json`
   keywords; confirm the match instead of asking open-ended.
6. **Constraints** — must-use tools or platforms, compliance, offline/online, budget of
   time or money.
7. **Data** — what data flows in and out, what is sensitive, where secrets live.
8. **Irreversible actions in this project** — deploy, delete, spend, send. These become
   deny rules and a task label; suggest the preset's default.
9. **Team** — solo or several people; branch and release policy (suggest: trunk `main`,
   PR per task, release by tag).
10. **Quality bar** — what must never ship broken (the paths the tests must cover).

Stop as soon as every heading of the spec can be filled. Typically 8–12 questions.
If the user says "just decide", take the recommended answer and mark it `(assumed)`.

### 1.3 Write the project spec
`backlog doc create "Project spec" -t spec`, then fill the created file from
`docs/SPEC_TEMPLATE.md` with the answers. Every `(assumed)` stays visible. Show the
spec and ask for one confirmation: "Is this the project?" Edit until yes.

### 1.4 Derive decisions, features, tasks
- Each choice in the spec that is expensive to reverse (stack, data store, hosting,
  auth model): `backlog decision create "<title>"` with the four ADR parts
  (`/decide` method). Include options turned down.
- The first milestone becomes one feature: `backlog task create "<milestone>"
  --type feature --ac "<criterion>"...` — criteria as stated in the spec, at least one
  naming the proof (a test, a screenshot, a measurement).
- Break the feature into 3–7 tasks in vertical slices (`-p <feature-id>`, `--dep` where
  ordered). Do not create tasks for later milestones — list them in the spec instead.

### 1.5 Phase 1 acceptance
Show: the spec path, the decision ids, the feature id with its criteria, the task ids.
Ask: "Phase 1 done — proceed to the toolchain?" Do not continue without a yes.

---

## Phase 2 — Build and prove the toolchain (produces the harness)

The set is fixed by the stack and the spec. Nothing is added beyond it in this phase —
a control needs an incident to justify it, and there is none yet.

### 2.1 Derive
From the primary preset and any additional ones: formatter, linter, security scanner,
test runner, install/dev/build commands, allow-list entries, gitignore lines, rules.
From the spec: deny rules for the irreversible actions (question 8), protected paths,
secret locations. Write the list to the chat as a table: tool · purpose · command.
Ask once: "Install and wire these?" Missing tools are installed only after that yes;
never install anything globally without saying so.

### 2.2 Write the configuration
- `CLAUDE.md`: fill every 🔧 from the spec and the preset; add the spec's non-goals
  and the irreversible actions under "Rules that are not derivable from the code".
  Keep under 100 lines; delete any 🔧 you cannot fill and say which.
- `.claude/settings.json`: append preset `allow` entries; append the irreversible
  actions as `Bash(...)` deny entries. Validate with `jq . .claude/settings.json`.
- `.gitignore`: merge `.gitignore.snippet` with preset lines.
- `Taskfile.yml`: `fmt`, `fmt:file`, `lint`, `test`, `build`, `security`, `dev` from the
  primary preset; additional presets as namespaced tasks included in `lint` and `chain`.
  A preset with `echo` placeholders keeps them — an honest "no linter exists" beats a
  fake one.
- `.claude/hooks/protected-paths.txt`: from the spec.
- Backlog.md definition of done via `backlog config` (advanced) or the config file:
  `lint green · tests green · code-review run · security-review run · final summary`.

### 2.3 Wire
`task repo:prepare` — installs the git hooks and reads the setting back. Show the output.
`npm install` for secretlint/commitlint/Backlog.md if `node_modules` is absent.
Install Anthropic's **security-guidance** plugin (`/plugins` → search "security-guidance",
project scope) so Claude reviews its own changes for vulnerabilities in-session. Mention,
do not install: the **Claude Security** plugin (whole-codebase scan) and the **Code Review**
GitHub app (automated multi-agent PR review) — both are the owner's call, and the GitHub
app needs repository admin rights.

### 2.4 Prove — every station is driven red once
This is the acceptance test of the toolchain. For each station, create a throwaway
defect on a scratch branch, run the station, confirm it goes RED, remove the defect,
confirm GREEN. Record each result in one line.

| Station | Red-defect to plant |
| --- | --- |
| `task lint` | a file that violates the linter (an unused variable, a bad format) |
| `task test` | one failing test |
| `task secrets` (secretlint) | a fake AWS-style key `AKIA…` in a scratch file, unstaged |
| commit-msg hook | `git commit -m "bad message"` on a scratch change → must be refused |
| pre-commit hook | stage a file with the fake key → must be refused |
| `protect-generated.sh` | `bash scripts/qa/repro/hooks-fire.sh` |
| `task build` | only if the stack has a build: a syntax error |
| `/code-review`, `/security-review` | open a scratch PR with one obvious defect; both must report it; then close the PR |

Then `git checkout main`, delete the scratch branch, run `task chain` clean: it must be
GREEN and print its runtime.

### 2.5 Provider-specific adjustments (third-party providers only)
If phase 1.1 found Bedrock, Vertex, Foundry or a gateway:
- Sessions start in **Manual** mode there. Tell the user, and offer to set
  `permissions.defaultMode: "auto"` in `~/.claude/settings.json` (user scope — it does not
  take effect from project files). Auto mode needs Sonnet 5, Opus 4.7+ or Fable 5.
- `WebSearch` is unavailable on Bedrock; do not write rules or skills that rely on it.
  `WebFetch` with a URL works.
- Do not mention Remote Control, `/schedule` routines, the Code Review GitHub app,
  `/code-review ultra`, the Advisor or Channels as options — they need a claude.ai
  account. For scheduling name `/loop` or a cron job with `claude -p`; for cloud review
  name GitHub Actions or GitLab CI.
- Put the provider env in `.claude/settings.local.json` (`env` block), never in the
  committed `settings.json`, so the repository stays provider-neutral.
- Note in CLAUDE.md under "Rules that are not derivable from the code": one line naming
  the provider and that `WebSearch` is unavailable, if so.

### 2.6 Phase 2 acceptance
Show the station table with red/green results and the chain runtime. Anything that
could not be driven red is listed as **NOT PROVEN**, not as passed. Ask: "Toolchain
stands — start the first task?" Do not continue without a yes.

---

## Phase 3 — Hand over

- Commit everything: `chore: set up project from template` — explicit paths.
- Delete `.claude/skills/setup/` (this skill and its presets).
- Report in five lines: spec path · decisions · first feature and tasks · toolchain
  stations proven · what is NOT proven or not installed.
- Next command for the user: `/task next`.

## What this skill does not do
It does not write project code. It does not add controls beyond the fixed set. It does
not decide anything marked `owner-decision`. If the interview stalls on a question the
user cannot answer, that question becomes a Backlog.md task labelled `owner-decision`
and the setup continues with the recommended answer marked `(assumed)`.
