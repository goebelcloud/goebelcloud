---
name: grilling
description: Stress-test a plan, decision or idea by interviewing the user one question at a time until a shared understanding is reached. Use on request ("grill me") or before committing to a non-trivial design or plan change.
---
<!-- Ported from mattpocock/skills (skills/productivity/grilling), with attribution:
     https://github.com/mattpocock/skills -->
Interview me relentlessly about every aspect of this until we reach a shared understanding.
Walk down each branch of the decision tree, resolving dependencies between decisions one by
one. For each question, provide your recommended answer.

Ask the questions one at a time, waiting for feedback on each before continuing.

If a *fact* can be found by exploring the environment, look it up rather than asking me.
The *decisions* are mine — put each to me and wait.

Do not act until I confirm we have reached a shared understanding. Then offer `/decide` to
record the outcome.
