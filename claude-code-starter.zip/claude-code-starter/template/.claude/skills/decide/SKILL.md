---
name: decide
description: Record a decision as a Backlog.md decision entry (an Architecture Decision Record). Use whenever something was just decided that is expensive to reverse or that a future session would otherwise re-litigate — taken OR turned down.
disable-model-invocation: true
---
Record this decision: $ARGUMENTS

Write it with `backlog decision create "<one-sentence title a reader can act on>"` and put
the ADR body into the created file using the standard four parts:

1. **Context** — the situation and the forces at play, in a few sentences.
2. **Options considered** — each with its main trade-off. Include the one taken.
3. **Decision** — what we do, stated so it can be checked. Say "turned down" if that is
   the outcome; a rejected option written down is worth as much as an accepted one.
4. **Consequences** — what becomes easier, what becomes harder, what would make us revisit.

Then: if the decision changes a rule in `CLAUDE.md`, `.claude/rules/` or `docs/`, change
that rule in the same commit. If it implies work, offer `/feature` or `/task`.

Source for the ADR shape: Michael Nygard, "Documenting Architecture Decisions" (2011).
