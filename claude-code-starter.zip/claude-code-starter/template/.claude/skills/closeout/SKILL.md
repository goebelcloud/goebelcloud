---
name: closeout
description: Close the current task honestly — acceptance criteria verified one by one, gates named, what was not checked stated, final summary written to Backlog.md. Use when a task or PR is being declared done.
disable-model-invocation: true
---
Close the current task: $ARGUMENTS

1. **Enumerate, then verdict.** List every acceptance criterion and every file touched;
   give each a verdict. An item without a verdict is NOT CHECKED, never "fine".
2. **Which gates ran, by name** (`task chain` stations, `/code-review`, `/security-review`)
   and **what was not checked**. "All green" without both is not a closeout.
3. **What the reviews do not deliver:** `/code-review` sees the diff, not the repository,
   and drops low-scored findings — it is a second pair of eyes, not a gate. Say so if the
   change is risky.
4. **Simplify.** Now that the task is done you know more than when you started: is there a
   simpler shape? Remove dead code, unused params, layers added "just in case".
5. Write the final summary: `backlog task edit <id> --final-summary "<claim · evidence · gaps>"`,
   check the definition-of-done items that are met, set `-s Done`. Link the PR.
6. If a decision was taken along the way that is not recorded: `/decide`.
