---
name: feature
description: Turn a request into a Backlog.md feature — a parent task with acceptance criteria and a proof — and break it into tasks. Use when the user wants something built that is more than one pull request, or says "feature".
disable-model-invocation: true
---
Feature request: $ARGUMENTS

1. **Understand before writing.** Look up what can be looked up (existing code, docs,
   backlog). Ask only what cannot be derived — one question at a time, with a recommended
   answer each. Stop asking as soon as the acceptance criteria below can be written.
2. **Create the feature** as a parent task:
   `backlog task create "<title>" --type feature -d "<what and why, 3–6 lines>" --ac "<criterion>" --ac "<criterion>"`
   Every acceptance criterion is stated so it can be checked, not "works well". At least
   one criterion names the **proof**: the test, screenshot or measurement that shows it
   behaves.
3. **If a decision is embedded** (a library, a data model, an API shape that is expensive
   to reverse), run `/decide` first and reference the decision id in the description.
4. **Break it into tasks** in vertical slices — each task touches every layer it needs and
   is demonstrable on its own, rather than "all of the database, then all of the API":
   `backlog task create "<title>" -p <feature-id> --ac "<criterion>" --dep <previous-task-if-ordered>`
   Each task is one pull request. Three to seven tasks is typical; more means the feature is
   two features.
5. Show the feature and its tasks (`backlog task <feature-id> --plain`) and stop. Do not
   start implementing — that is `/task`.
