---
paths:
  - "**/*{test,spec,_test}.*"
  - "**/tests/**"
  - "**/test/**"
  - "**/__tests__/**"
---
# Rules for tests

- **Test behaviour, not implementation.** A test that breaks on a refactor is a tax.
- **Prefer in-memory fakes over call-level mocks.** Isolate at the boundary with a real
  in-memory implementation; mock only what is unavailable in-process.
- **Every feature owes a proof that it behaves** — a test that drives the real path and
  asserts the result. A green compile is not that proof.
- **Coverage is a diagnostic, not a target.** A threshold as the only gate produces tests
  written to satisfy the threshold.
- **No snapshot tests for anything a human cannot review in a diff.**
- **An intermittent failure is diagnosed, never re-run until green.** Exactly one repeat,
  both results reported, the flake counted.
- Write the failing test first when fixing a bug; it proves the loop works.
