---
paths:
  - "**/*.{ts,tsx,js,jsx,mjs,cjs,py,go,rs,java,kt,cs,rb,php,swift,c,cpp,h}"
---
# Rules for source code (loads only when a source file is touched)

Full rules: `docs/ENGINEERING_GUIDELINES.md`. The ones that decide most reviews:

- **KISS > YAGNI > DRY.** No config flag without a consumer, no abstraction over a library
  nobody plans to replace, no plugin system with one plugin. Extract on the third
  occurrence, not the second.
- **Errors:** never swallow. An empty `catch` is a defect. A catch that does not rethrow
  carries a comment saying why. Fail early with guard clauses; fail closed, never degrade
  silently.
- **Boundaries:** domain logic does not import I/O (HTTP, filesystem, DB, browser APIs)
  directly — inject it, so the logic is testable without a network.
- **Naming reveals intent.** Booleans read as predicates (`isReady`, `hasPending`).
  Comments explain WHY, not what.
- **Nesting ≤ 3, functions ~30 lines as a smell threshold.** The linter's complexity rule is
  the real gate.
- **Formatting is not a discussion.** The formatter runs after every edit; zero style
  comments in review.
- **Generated code is contributed code.** It passes every gate unmodified and is reviewed
  for invented signatures, plausible constants, swallowed errors and unneeded dependencies.
- **A dependency suggested by a model is verified to exist and be maintained** before it is
  added.
