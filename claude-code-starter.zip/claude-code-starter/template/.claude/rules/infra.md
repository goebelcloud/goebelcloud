---
paths:
  - "**/*.{tf,tfvars,hcl,bicep,yml,yaml}"
  - "**/Dockerfile*"
  - "**/*.kql"
  - "**/*.ps1"
  - "**/*.sh"
---
# Rules for infrastructure, pipelines, queries and scripts

- **Every change is planned before it is applied.** `terraform plan`, `--what-if`,
  `--dry-run`, `-WhatIf` — read the plan output before the apply, and never apply in an
  unattended session.
- **Anything irreversible needs a human:** deploys to production, deleting resources,
  rotating credentials, force-pushes. Reversible work runs freely — and almost everything
  else is reversible.
- **No secrets in code, variables files or query text.** Reference a secret store; the
  secretlint gate at commit is the backstop, not the policy.
- **Scripts are linted like code:** shellcheck for shell, PSScriptAnalyzer for PowerShell,
  hadolint for Dockerfiles, tflint + trivy/checkov for Terraform (`docs/TOOLS.md`).
- **Queries against live data are read-only by default.** A query that mutates, ingests or
  deletes is a task with an explicit acceptance criterion naming the target.
- **A state change runs alone in its own call** (create branch, change directory, switch
  context/subscription) and its result is read before the next command.
