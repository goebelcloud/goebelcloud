#!/usr/bin/env bash
# format-after-edit.sh — PostToolUse (Edit|Write).
# Runs the project formatter on the file Claude just changed. A formatter is the canonical
# hook example in the Claude Code docs: deterministic, cheap, and exactly the step a human
# forgets. It formats ONE file, not the tree, so it stays fast on every edit.
# The formatter command per stack comes from `task fmt:file -- <path>` (Taskfile.yml),
# written by /setup. If no such task exists, the hook does nothing.
command -v jq >/dev/null 2>&1 || exit 0
P=$(jq -r '.tool_input.file_path // .tool_input.path // empty' 2>/dev/null) || exit 0
[ -n "$P" ] && [ -f "$P" ] || exit 0
cd "${CLAUDE_PROJECT_DIR:-.}" 2>/dev/null || exit 0
command -v task >/dev/null 2>&1 || exit 0
task --list-all 2>/dev/null | grep -q '^\* fmt:file' || exit 0
task fmt:file -- "$P" >/dev/null 2>&1 || true
exit 0
