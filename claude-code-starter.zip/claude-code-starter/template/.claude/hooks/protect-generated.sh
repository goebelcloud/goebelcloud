#!/usr/bin/env bash
# protect-generated.sh — PreToolUse (Edit|Write). Exit 2 blocks the tool call.
# Refuses hand edits to committed GENERATED files so they change only through their
# generator. The list is in .claude/hooks/protected-paths.txt (one path or glob per line,
# relative to the repo root). Paths are canonicalised before comparison so `a/../gen/x`
# cannot slip past. Scope: the Edit/Write lane. A shell redirect does not pass through
# this tool — that case belongs to the commit hook, not to a text matcher over Bash.
set -u
command -v jq >/dev/null 2>&1 || { echo "Refused: jq is required by protect-generated.sh. Install jq." >&2; exit 2; }
ROOT="${CLAUDE_PROJECT_DIR:-$(pwd)}"
LIST="$ROOT/.claude/hooks/protected-paths.txt"
[ -f "$LIST" ] || exit 0
P=$(jq -r '.tool_input.file_path // .tool_input.path // empty' 2>/dev/null) || exit 0
[ -z "$P" ] && exit 0
ABS=$(realpath -m "$P" 2>/dev/null || echo "$P")
REL="${ABS#"$ROOT"/}"
while IFS= read -r pat; do
  [ -z "$pat" ] || [ "${pat#\#}" != "$pat" ] && continue
  # shellcheck disable=SC2254
  case "$REL" in $pat)
    echo "Refused: $REL is generated (matches '$pat' in protected-paths.txt). Change its source and run the generator." >&2
    exit 2 ;;
  esac
done < "$LIST"
exit 0
