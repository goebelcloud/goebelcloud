#!/usr/bin/env bash
# hooks-fire.sh — drives both Claude Code hooks with harness-shaped payloads and asserts
# the exit codes. A guard that has never been red is not known to work.
set -u
ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)
export CLAUDE_PROJECT_DIR="$ROOT"
H="$ROOT/.claude/hooks"; LIST="$H/protected-paths.txt"
pass=0; fail=0
expect() { local want=$1 label=$2 hook=$3 json=$4 rc
  rc=$(printf '%s' "$json" | bash "$hook" >/dev/null 2>&1; echo $?)
  if [ "$rc" = "$want" ]; then pass=$((pass+1)); echo "  ok   $label (rc=$rc)"; else fail=$((fail+1)); echo "  FAIL $label (rc=$rc, expected $want)"; fi; }

echo "protect-generated.sh"
cp "$LIST" "$LIST.bak"; printf 'src/generated/*\n**/schema.generated.*\n' > "$LIST"
expect 0 "allows an unlisted file"        "$H/protect-generated.sh" "{\"tool_input\":{\"file_path\":\"$ROOT/src/app.ts\"}}"
expect 2 "refuses a listed glob match"    "$H/protect-generated.sh" "{\"tool_input\":{\"file_path\":\"$ROOT/src/generated/x.ts\"}}"
expect 2 "refuses via ../ traversal"      "$H/protect-generated.sh" "{\"tool_input\":{\"file_path\":\"$ROOT/src/x/../generated/x.ts\"}}"
expect 2 "refuses nested pattern"         "$H/protect-generated.sh" "{\"tool_input\":{\"file_path\":\"$ROOT/a/b/schema.generated.ts\"}}"
mv "$LIST.bak" "$LIST"
expect 0 "no-op with an empty list"       "$H/protect-generated.sh" "{\"tool_input\":{\"file_path\":\"$ROOT/src/generated/x.ts\"}}"

echo "format-after-edit.sh"
expect 0 "exits 0 without a fmt:file task"  "$H/format-after-edit.sh" "{\"tool_input\":{\"file_path\":\"$ROOT/README.md\"}}"
expect 0 "exits 0 on a missing file"        "$H/format-after-edit.sh" "{\"tool_input\":{\"file_path\":\"$ROOT/does-not-exist\"}}"

echo; echo "$pass passed, $fail failed"
echo "NOT PROVEN: that your Claude Code version sends exactly these JSON shapes (check with claude --debug), and that fmt:file actually formats — that depends on the stack command /setup wrote."
[ "$fail" -eq 0 ]
