# Claude Code Starter

Three things are in this folder. At the start you need only the first.

| What | For |
| --- | --- |
| **START.md** / **START.de.md** | This page. Ten minutes to get going. |
| **handbook.html** | The reference. German and English, switchable. 30 chapters in seven levels — read what you need, when you need it. |
| **template/** | The project template. Comes in at step 4. |

---

## Step 0 — What you should bring

Using a terminal, git in outline, knowing what a test and a linter do. If any of that is
missing, it is no obstacle — but read **appendix H** in the handbook first: every term in
three sentences and a link that goes further. Anyone who does not know "exit code" or "red
and green" drops out in chapter 1 otherwise.

## Step 1 — Install (5 minutes)

```bash
# macOS, Linux, WSL
curl -fsSL https://claude.ai/install.sh | bash

# Windows — recommended: Microsoft's package manager
winget install Anthropic.ClaudeCode
```

Then change into any project directory and type `claude`. The browser opens, you sign in
with your Claude account. The login lasts hours to days; when Claude asks for `/login`,
that is normal. Company with AWS Bedrock and SSO? Handbook chapter 2, route D.

**Windows, two more things:** winget does not update itself — Claude Code changes weekly,
so run `winget upgrade Anthropic.ClaudeCode` regularly. And without WSL, install
**Git for Windows** too, or Bash will be missing later. Where winget is unavailable,
`irm https://claude.ai/install.ps1 | iex` in PowerShell also works; it self-updates but
runs a script from the network.

→ Handbook chapter 2 if something is off. If you work through AWS Bedrock: it also lists
what does not work there (Remote Control, web, advisor, web search) and what to use instead.

## Step 2 — Lab exercise: one session on someone else's code (30 minutes)

> **Exercise, no result.** What you do here achieves nothing for your project. You learn how
> Claude Code reads, asks, changes and stops — on code you don't care about. Your own project
> starts in step 4, with a spec instead of code.
>
> ⚠ **Not in a company repository.** Claude Code changes files, in auto mode without asking.
> In the worst case code gets changed and committed before you understand what is happening.
> Use a fresh clone in its own folder, an old private project, or a public repository.

Not in the important repository, but one with code in it — an old project, or a cloned public
repository. An empty folder will not do. Then try:

```
> What does this project do?
> Explain how <some file> works.
> Add a function to <file> that does <something small>.
```

Claude reads what it needs. Before changes it asks — or not, depending on the permission
mode (`Shift+Tab` switches it). Something went wrong? `Esc Esc` opens the rewind menu.

Five things are enough for the first week: `claude` to start · `Shift+Tab` for plan mode ·
`Esc` to interrupt · `/clear` between unrelated tasks · `claude -c` to continue.

→ Handbook chapters 3 to 7. That is level 1. Then just work for a few days.

## Step 3 — Two things to know before it gets serious

**Permissions.** On Pro, Max and Team plans a terminal session starts in auto mode: a
review model decides instead of you. Convenient, but you should know. → Chapter 6.

**Context.** Claude's working memory for one conversation is limited, and answers get
worse as it fills. `/clear` between unrelated tasks is the remedy. → Chapter 7.

## Step 4 — Your own project with the template (an afternoon)

Prerequisites: `git`, `node`, `jq` and `task` (go-task). If anything is missing, the next
step tells you.

```bash
mkdir my-project && cd my-project && git init
cp -r /path/to/claude-code-starter/template/. .
claude
```

```
> /setup I want to build <what you want to build>.
```

That is the whole command. You do not have to name the stack — it asks.

**In the terminal, not in the VS Code extension.** The extension knows only a subset of
commands and skills. If you want to stay in VS Code: open the integrated terminal and run
`claude` there — that needs the CLI install from step 1.

What happens then, in three phases, stopping for your yes before each:

1. **Understand.** It interviews you, one question at a time, each with a suggestion:
   goal, users, what "done" means, what is explicitly out of scope, stack, constraints,
   data, what is irreversible. Eight to twelve questions. At the end it shows you a
   one-page project description and asks: *is this the project?* From that come the
   first decisions, the first feature with criteria, and the first tasks. No code yet — and no `/init`, which is for existing code only; here the CLAUDE.md comes from the spec.
2. **Toolchain.** From your stack it derives formatter, linter, security scanner, test
   runner and hooks, installs and wires them — and then **drives every check red once**
   so you know it really checks. End: `task chain` is green. Still no code.
3. **Hand over.** It removes itself and says: `/task next`.

From here every piece of work runs the same way: `/task next` takes the next task, builds
it on its own branch, tests, opens the pull request, runs code and security review.
`/closeout` closes it honestly. `/feature` creates the next feature, `/decide` records a
decision.

→ Chapter 8 (what a project needs at minimum) and chapter 29 (the template).

## Step 5 — Read on when something bothers you

Not before. The handbook solves problems you do not have yet:

| When… | then… |
| --- | --- |
| Claude writes into generated files or ignores rules | chapters 13–19: harness, hooks, guardrails |
| you want two things running at once | chapters 20–22: worktrees, background sessions |
| you want it to work overnight | chapter 24: unattended |
| the same mistakes keep happening | chapters 25–28: ways of working, failure patterns |

---

What this package is **not**: a tool that thinks for you. The template asks questions
because the answers are yours. If you cannot answer one, it takes the suggestion, marks it
as an assumption and moves on — visibly.

As of September 2026, Claude Code ≈ 2.1. Where anything differs, `/help` and the docs at
code.claude.com take precedence.
