# Architecture

## Scope

- **Azure native Windows VMs only** (`Microsoft.Compute/virtualMachines`).
- Hardening is applied using **Azure Policy Machine Configuration (Guest Configuration)**.
- Each hardening setting is packaged as its own **Machine Configuration package (ZIP)**.
- Packages are hosted in **Azure Storage**.

### Identity model

- **System-assigned managed identity (VM)**
  - Required for the Machine Configuration extension/agent to authenticate to the Machine Configuration service.
- **User-assigned managed identity (VM UAMI)**
  - Used to authenticate to Azure Storage for **private package download**.
  - Implemented via the guest configuration assignment property `contentManagedIdentity`.

## Policy layers

### 1) Prerequisites initiative

Folder: `policies/prereqs/`

Goal: ensure every in-scope VM is capable of receiving Machine Configuration assignments.

Implemented checks/remediation:

- Machine Configuration extension present (`AzurePolicyforWindows`).
- VM has **system-assigned identity** enabled.
- VM has the required **UAMI** attached.

> Remediation is performed via policy remediation tasks on the initiative assignment.

### 2) Hardening initiative

Folder: `policies/packages/`

Goal: apply the 50 hardening settings.

- **One policy definition per setting**.
- Each policy uses `DeployIfNotExists` to deploy a `guestConfigurationAssignments` child resource under the VM.
- Each assignment references:
  - `contentUri` (Storage URL without SAS)
  - `contentHash` (base64 SHA256)
  - `contentManagedIdentity` (UAMI resource ID)

### Prerequisite gating

Each hardening policy includes **explicit prerequisite checks** (extension + identities) before it attempts to deploy the assignment.

This avoids failed deployments when the VM isn't ready yet.

## Runtime flow

1. **Azure Policy evaluation** finds VMs in scope.
2. **Prerequisites initiative** (if assigned) remediates:
   - installs Machine Configuration extension
   - enables system-assigned identity
   - attaches the required UAMI
3. **Hardening policies** deploy `guestConfigurationAssignments` for each setting.
4. The Machine Configuration extension downloads the package from Storage using the **UAMI** and applies the DSC configuration.
5. Compliance results are reported through guest configuration assignment reports and surfaced by Azure Policy.

## Remediation order

For existing VMs, use this order:

1. Run remediation on **Prerequisites initiative**
2. Run remediation on **Hardening initiative**
