# Prerequisites

This repository applies Windows OS hardening settings to **Azure native Windows VMs** using:

- **Azure Policy**
- **Machine Configuration (Guest Configuration)**
- **One Machine Configuration package (ZIP) per setting**
- **User-assigned managed identity (UAMI)** for private package download from **Azure Storage** (no SAS)

---

## 1) Subscription-level prerequisites

### Required resource provider registrations

At minimum, register the following providers in every subscription where you will **assign Machine Configuration policies** and where the target VMs exist:

| Provider namespace | Why it's needed |
|---|---|
| `Microsoft.GuestConfiguration` | Required for Machine Configuration / Guest Configuration resources and policy scenarios. |
| `Microsoft.PolicyInsights` | Required for policy compliance reporting and remediation experiences in many scenarios. |
| `Microsoft.ManagedIdentity` | Required for user-assigned managed identities. |
| `Microsoft.Storage` | Required for hosting packages in Blob Storage. |
| `Microsoft.Compute` | Required for the VM and VM extension resources. |

> Microsoft notes that `Microsoft.GuestConfiguration` is automatically registered in some cases (for example, when assigning guest configuration policies via the portal or if the subscription is enrolled in Microsoft Defender for Cloud). For deterministic enterprise deployments, register it explicitly. 

### How to check / register (Azure CLI)

Check status:

```bash
az provider show --namespace Microsoft.GuestConfiguration --query "registrationState" -o tsv
az provider show --namespace Microsoft.PolicyInsights --query "registrationState" -o tsv
```

Register:

```bash
az provider register --namespace Microsoft.GuestConfiguration
az provider register --namespace Microsoft.PolicyInsights
az provider register --namespace Microsoft.ManagedIdentity
az provider register --namespace Microsoft.Storage
az provider register --namespace Microsoft.Compute
```

Registration permissions: you need `Microsoft.Resources/providers/register/action` for the subscription. This is included in common roles like **Contributor** and **Owner**.

### Can provider registration be enforced via Azure Policy?

**Not directly.**

- Resource provider registration is a **subscription-level management action** (`POST .../providers/{namespace}/register`). It is not a normal Azure resource you can deploy with `DeployIfNotExists`, nor a property you can set with `Modify`.
- Azure Policy effects can **deny**, **audit**, **modify resource properties**, or **deploy resources**. There is no Azure Policy effect that invokes provider registration.

**What you *can* do instead:**

- Register providers as an explicit IaC/bootstrap step (Terraform, pipeline step, etc.).
- Be aware that Azure Resource Manager deployments can **automatically register** some providers referenced by a deployment, if the deploying principal has permission. This may happen indirectly during remediation deployments, but it is not the same as a policy-enforced control and should not be relied on for governance.

---

## 2) VM-level prerequisites

### Machine Configuration extension

Target VMs must have the Machine Configuration extension installed with the required instance name:

- **Windows instance name:** `AzurePolicyforWindows`
- **Publisher:** `Microsoft.GuestConfiguration`
- **Type:** `ConfigurationforWindows`

### Managed identity requirements (Azure native VMs)

Machine Configuration requires:

1. **System-assigned managed identity** on the VM (required for the VM to authenticate to the Machine Configuration service).
2. **User-assigned managed identity (UAMI)** attached to the VM (**this is the identity used to read packages from Azure Storage** without SAS).

### Minimum extension versions

Two distinct minimum versions matter:

- **Apply configurations (AuditAndSet/ApplyAndAutoCorrect):** Azure notes the Azure VM guest configuration extension must be **1.26.24 or later** to apply configurations.
- **UAMI-based package access (no SAS):** UAMI-based private package access for the Windows extension (ConfigurationforWindows) was introduced in **version 1.29.82.0 (September 2024)**.

For deterministic behavior, ensure the extension can auto-upgrade, or pin to an appropriate version.

---

## 3) Storage prerequisites (package hosting)

You need an Azure Storage account and a **private** blob container to host the generated Machine Configuration ZIP packages.

### Data-plane access (required)

Grant the VM **UAMI** at least:

- **Storage Blob Data Reader** on the container or storage account that hosts the packages.

> This is *data plane* RBAC, not just management-plane permissions.

### Networking considerations

The VM must be able to reach:

- the Storage blob endpoint hosting the package content (over HTTPS / 443)
- the Machine Configuration service endpoints (also HTTPS / 443)

If you use private networking, consider Storage private endpoints and any Machine Configuration private networking guidance.

---

## 4) Azure Policy assignment prerequisites (RBAC)

Because this solution relies on `DeployIfNotExists` and `Modify`, **policy assignments must have a managed identity** and that identity must have permissions to remediate:

### Recommended minimum permissions for the *policy assignment managed identity*

| Capability | Typical permissions |
|---|---|
| Deploy/ensure the VM extension | Permissions to write VM extensions (`Microsoft.Compute/virtualMachines/extensions/*`). Practical minimum is **Virtual Machine Contributor** or **Contributor** at the VM scope. |
| Enable system-assigned identity and attach a UAMI | Needs write permissions over the VM (`Microsoft.Compute/virtualMachines/write`) and the ability to assign the UAMI (`Microsoft.ManagedIdentity/userAssignedIdentities/*/assign/action`). |
| Create guestConfigurationAssignments | Permissions to write guest configuration assignment resources under the VM. |

A common pattern is:

- **Contributor** on the scope containing the VMs (subscription/RG)
- **Managed Identity Operator** on the UAMI resource (to allow assigning it)

---

## 5) Build prerequisites (package creation)

Package creation compiles DSC to MOF and builds Guest Configuration packages.

- Use a **Windows build agent**
- PowerShell modules are installed by `build/00-InstallModules.ps1`
- Packages are created by `build/01-Build-GuestConfigurationPackages.ps1`

Uploading ZIPs to Storage is intentionally out-of-scope here (you indicated Terraform will handle that).
