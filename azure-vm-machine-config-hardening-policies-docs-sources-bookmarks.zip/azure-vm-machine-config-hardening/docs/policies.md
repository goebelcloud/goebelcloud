# Policies and initiatives

This repository contains **custom Azure Policy definitions** that:

1. Enforce **VM prerequisites** for Machine Configuration (Guest Configuration)
2. Deploy **guestConfigurationAssignments** for each hardening setting

All policies are designed for **Azure native VMs** only.

---

## 1) Prerequisites initiative

Location: `policies/prereqs/...`

### What it ensures

The prerequisites initiative is intended to be assigned first and remediated before hardening:

- Machine Configuration extension installed with the correct instance name:
  - `AzurePolicyforWindows`
- VM identities configured:
  - **System-assigned managed identity** enabled (required by the Machine Configuration extension)
  - **User-assigned managed identity (UAMI)** attached (used for Storage access)

### Policy definitions

The initiative includes custom policy definitions that use a mix of:

- `DeployIfNotExists` for the extension deployment
- `Modify` for the VM identity enablement/attachment

> The initiative expects a parameter for the **UAMI resource ID**.

### Remediation

Because these policies include deploy/modify effects, remediation is done via:

- A policy assignment **managed identity**
- A **remediation task**

---

## 2) Hardening initiative

Location: `policies/packages/...`

### What it does

- Contains **50** policy definitions (one per setting)
- Each definition uses `DeployIfNotExists` to deploy a child resource:
  - `Microsoft.GuestConfiguration/guestConfigurationAssignments`
- Assignment settings are configured to:
  - download the package from Storage via `contentUri`
  - validate with `contentHash` (base64 SHA256)
  - authenticate to Storage with `contentManagedIdentity` (= the UAMI resource ID)

### Placeholder values you must stamp (via Terraform)

The policy JSON under `policies/packages/policyDefinitions/` contains placeholders:

- `contentUri` placeholder: `https://<storage-account>.blob.core.windows.net/<container>/<PACKAGE>.zip`
- `contentHash` placeholder: `__REPLACE_WITH_BASE64_SHA256__`

You must replace these values after you build and upload the ZIPs (Terraform can do this by:
- uploading each ZIP to a known blob path
- computing the SHA256 and converting to base64
- rendering the policy definition JSON with the correct `contentUri` + `contentHash`)

### Prerequisite checks (explicit)

Each hardening policy definition contains an explicit gate in the `if` clause requiring:

- `AzurePolicyforWindows` extension present
- `identity.type` contains `SystemAssigned`
- `identity.type` contains `UserAssigned`
- `identity.userAssignedIdentities` contains the supplied UAMI resource ID

This prevents the policy from attempting to deploy guest assignments until the VM is ready.

> Operationally: assign the prerequisites initiative and remediate first.

---

## 3) Assignment strategy (recommended)

### New VMs

- Assign the initiatives at the appropriate scope (management group, subscription, or resource group).
- New VMs inherit the policy assignment and become compliant without any per-VM action.

### Existing VMs

- Run remediation tasks:
  1. Prerequisites initiative
  2. Hardening initiative

---

## 4) RBAC requirements summary

### VM UAMI

The UAMI referenced by `contentManagedIdentity` must have at minimum:

- **Storage Blob Data Reader** on the package container/storage account

### Policy assignment managed identity

The managed identity attached to the policy assignment must be able to:

- install/write VM extensions
- enable/modify VM identities and attach the UAMI
- create guestConfigurationAssignments

Common implementation:

- **Contributor** on the VM scope (subscription/RG)
- **Managed Identity Operator** on the UAMI resource

For more detailed prerequisite discussion, see `docs/prerequisites.md`.
