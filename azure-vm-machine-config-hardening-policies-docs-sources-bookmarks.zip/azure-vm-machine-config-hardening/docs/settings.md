# Settings mapping

| Control ID | Configuration Name | Setting | Suggested Value |
|---|---|---|---|
| ACCT-001 | WH_ACCT_001 | Enforce password history | 24 passwords remembered |
| ACCT-002 | WH_ACCT_002 | Maximum password age | 60 days (or org standard 60–90) |
| ACCT-003 | WH_ACCT_003 | Minimum password age | 1 day |
| ACCT-004 | WH_ACCT_004 | Minimum password length | 14 characters |
| ACCT-005 | WH_ACCT_005 | Password must meet complexity requirements | Enabled |
| ACCT-006 | WH_ACCT_006 | Store passwords using reversible encryption | Disabled |
| ACCT-007 | WH_ACCT_007 | Account lockout threshold | 10 invalid logon attempts (WS2025 baseline uses 3; test before lowering) |
| ACCT-008 | WH_ACCT_008 | Account lockout duration | 15 minutes |
| ACCT-009 | WH_ACCT_009 | Reset account lockout counter after | 15 minutes |
| SECO-001 | WH_SECO_001 | Accounts: Limit local account use of blank passwords to console logon only | Enabled |
| SECO-002 | WH_SECO_002 | Accounts: Guest account status | Disabled |
| SECO-003 | WH_SECO_003 | Accounts: Rename administrator account | Rename to non-default (document in CMDB/secret store) |
| SECO-004 | WH_SECO_004 | Accounts: Rename guest account | Rename to non-default (even if disabled) |
| SECO-010 | WH_SECO_010 | Network access: Do not allow anonymous enumeration of SAM accounts | Enabled |
| SECO-011 | WH_SECO_011 | Network access: Do not allow anonymous enumeration of SAM accounts and shares | Enabled |
| SECO-012 | WH_SECO_012 | Network access: Let Everyone permissions apply to anonymous users | Disabled |
| SECO-020 | WH_SECO_020 | Network security: Do not store LAN Manager hash value on next password change | Enabled |
| SECO-021 | WH_SECO_021 | Network security: LAN Manager authentication level | Send NTLMv2 response only. Refuse LM & NTLM |
| SECO-022 | WH_SECO_022 | Network security: Minimum session security for NTLM SSP based (including secure RPC) clients | Require NTLMv2 session security; Require 128-bit encryption |
| SECO-023 | WH_SECO_023 | Network security: Minimum session security for NTLM SSP based (including secure RPC) servers | Require NTLMv2 session security; Require 128-bit encryption |
| SECO-030 | WH_SECO_030 | Microsoft network client: Digitally sign communications (always) | Enabled (SMB signing required for outbound SMB client traffic) |
| SECO-031 | WH_SECO_031 | Microsoft network server: Digitally sign communications (always) | Enabled (SMB signing required for inbound SMB server traffic) |
| SECO-040 | WH_SECO_040 | Interactive logon: Do not display last user name | Enabled |
| SECO-041 | WH_SECO_041 | Interactive logon: Do not require CTRL+ALT+DEL | Disabled (require CTRL+ALT+DEL) |
| SECO-042 | WH_SECO_042 | Interactive logon: Machine inactivity limit | 900 seconds (15 minutes) |
| SECO-043 | WH_SECO_043 | Shutdown: Allow system to be shut down without having to log on | Disabled |
| UAC-001 | WH_UAC_001 | User Account Control: Run all administrators in Admin Approval Mode | Enabled |
| UAC-002 | WH_UAC_002 | User Account Control: Switch to the secure desktop when prompting for elevation | Enabled |
| UAC-003 | WH_UAC_003 | User Account Control: Behavior of the elevation prompt for administrators in Admin Approval Mode | Prompt for consent on the secure desktop |
| AUD-001 | WH_AUD_001 | Audit Account Logon (Success/Failure) | Enable Success and Failure |
| AUD-002 | WH_AUD_002 | Audit Logon/Logoff (Success/Failure) | Enable Success and Failure |
| AUD-003 | WH_AUD_003 | Audit Account Management (Success/Failure) | Enable Success and Failure |
| AUD-004 | WH_AUD_004 | Audit Policy Change (Success/Failure) | Enable Success and Failure |
| AUD-005 | WH_AUD_005 | Audit Privilege Use (Failure) | Enable Failure (and Success if required) |
| AUD-006 | WH_AUD_006 | Audit System (Success/Failure) | Enable Success and Failure |
| FW-001 | WH_FW_001 | Enable firewall for all profiles | Enabled (Domain/Private/Public) + default inbound = Block |
| FW-002 | WH_FW_002 | Enable firewall logging | Log dropped packets = Yes; Log successful connections = (Optional); Log size >= 16,384 KB |
| RDP-001 | WH_RDP_001 | Require user authentication for remote connections by using Network Level Authentication | Enabled |
| RDP-002 | WH_RDP_002 | Set client connection encryption level | High |
| RDP-003 | WH_RDP_003 | Do not allow passwords to be saved | Enabled |
| WINRM-001 | WH_WINRM_001 | Allow unencrypted traffic | Disabled |
| WINRM-002 | WH_WINRM_002 | Disallow Basic authentication | Basic = Disabled (use Kerberos/cert) |
| DEF-001 | WH_DEF_001 | Real-time protection | Enabled (do not disable real-time monitoring) |
| DEF-002 | WH_DEF_002 | Cloud-delivered protection | Enabled |
| DEF-003 | WH_DEF_003 | Potentially Unwanted Application (PUA) protection | Enabled (Block) |
| LOG-001 | WH_LOG_001 | PowerShell Script Block Logging | Enabled |
| LOG-002 | WH_LOG_002 | Increase Security log maximum size | >= 196,608 KB (192 MB) (tune for environment) |
| NET-001 | WH_NET_001 | Disable SMBv1 (Client and Server) | Disable/remove SMBv1 |
| NET-002 | WH_NET_002 | Turn off AutoPlay / AutoRun | Enabled (All drives) |
| LSA-001 | WH_LSA_001 | Enable LSA protection (RunAsPPL) | Enabled (Audit first if possible) |
