# Machine Configuration package assignment policies (Azure native Windows VMs)

This folder contains **custom Azure Policy definitions (JSON)** that deploy **Machine Configuration (Guest Configuration) assignments** to **Azure native Windows VMs**.

## What these policies do

- **One policy definition per hardening setting** (matching the repo structure `src/dsc/<CONTROL_ID>`).
- Each policy uses **DeployIfNotExists** to deploy a child resource:
  - `Microsoft.Compute/virtualMachines/providers/guestConfigurationAssignments` (API version `2024-04-05`)
- Each policy configures the assignment to fetch the package from Azure Storage using:
  - `guestConfiguration.contentManagedIdentity` = **your UAMI resource ID** (no SAS token)

## Important: content URI and hash placeholders

The policy definitions under `policyDefinitions/` contain placeholders:

- `contentUri`: `https://<storage-account>.blob.core.windows.net/<container>/<PACKAGE>.zip`
- `contentHash`: `__REPLACE_WITH_BASE64_SHA256__`

**Terraform** (or your chosen IaC tooling) should:

1. Upload each package ZIP to Blob Storage
2. Compute the base64-encoded SHA256 hash of each ZIP
3. Render/stamp the final `contentUri` and `contentHash` into each policy definition

## Prerequisite checks (explicit)

Each policy definition includes checks to ensure the VM is ready *before* deploying the assignment:

- Machine Configuration extension exists on the VM (`AzurePolicyforWindows`)
- VM has **SystemAssigned** identity (required by Machine Configuration)
- VM has **UserAssigned** identity and the specified UAMI is attached

> The prerequisite **remediation** itself is handled by the initiative in `policies/prereqs/`.

## Initiative

- `policySetDefinitions/wh-windows-hardening-initiative.json` groups all 50 package policies so you can assign once.

## Permissions

For remediation, the **policy assignment managed identity** must have permissions to:

- create/write guest configuration assignments (under the VM)
- deploy VM extensions

The VM's **UAMI** must have:

- **Storage Blob Data Reader** on the container or storage account hosting the package ZIPs.
