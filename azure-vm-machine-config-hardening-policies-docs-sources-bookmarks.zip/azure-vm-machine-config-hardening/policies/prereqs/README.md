# Machine Configuration prerequisites (Azure native Windows VMs)

This folder contains **Azure Policy artifacts (JSON)** to enforce prerequisites for **Azure Machine Configuration (Guest Configuration)** on **Azure native Windows VMs**:

- Deploy the **Machine Configuration extension** (`AzurePolicyforWindows`)
- Ensure the VM has:
  - **System-assigned managed identity** (required by the Machine Configuration extension for service authentication)
  - A **specific user-assigned managed identity (UAMI)** (used for **identity-based access** to Machine Configuration packages stored in Azure Storage, instead of SAS)

## Contents

- `policyDefinitions/`
  - `mc-deploy-extension-windows.json`
  - `mc-ensure-identities-uami.json`
- `policySetDefinitions/`
  - `mc-prereqs-initiative.json`

## Deploy (Azure CLI - example)

> You will create the **policy definitions**, then create/assign the **initiative**.
>  
> When assigning *DeployIfNotExists* / *Modify* policies, use a **managed identity** on the assignment and grant it the roles referenced in the policy definitions.

Create policy definitions:

```bash
az policy definition create \
  --name mc-deploy-extension-windows \
  --rules ./policyDefinitions/mc-deploy-extension-windows.json \
  --mode Indexed \
  --display-name "Deploy Azure Machine Configuration extension for Windows VMs"

az policy definition create \
  --name mc-ensure-identities-uami \
  --rules ./policyDefinitions/mc-ensure-identities-uami.json \
  --mode Indexed \
  --display-name "Ensure Machine Configuration identities on Windows VMs (System + specified UAMI)"
```

Create the initiative:

```bash
az policy set-definition create \
  --name mc-prereqs-initiative \
  --definitions ./policySetDefinitions/mc-prereqs-initiative.json \
  --display-name "Machine Configuration prerequisites for Windows Azure VMs (UAMI-enabled)"
```

Assign the initiative (example parameters):

- `userAssignedIdentityResourceId`: resourceId of your UAMI that will be attached to the VM and later used to access packages in Storage.

## Notes / Assumptions

- The **UAMI must already exist**.
- **RBAC for Storage** is **out of scope** for these policies. The UAMI needs at least **Storage Blob Data Reader** on the container or storage account hosting the Machine Configuration package ZIPs.
- These policies only target `Microsoft.Compute/virtualMachines` where `osType == Windows`.
