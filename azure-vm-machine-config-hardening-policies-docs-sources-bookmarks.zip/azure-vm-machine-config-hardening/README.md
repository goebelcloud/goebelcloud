# Azure VM Windows Hardening via Machine Configuration (Azure Policy Guest Configuration)

This repository is generated from `windows_server_os_hardening_suggestions_common_table_only.xlsx`.

## Scope and constraints

- **Target**: **Azure native Windows VMs only** (`Microsoft.Compute/virtualMachines`).
- **Delivery mechanism**: **Azure Policy + Machine Configuration (Guest Configuration)**.
- **Packaging model**: **one DSC/Machine Configuration package per setting** (50 settings total).
- **Package download auth**: **User-assigned managed identity (UAMI)** for Storage access (**no SAS**).

> Note: The Machine Configuration extension on Azure VMs still requires a **system-assigned managed identity** for service authentication. The **UAMI** is used specifically for Storage package download.

## Repository layout

### DSC source (one configuration per setting)

- `src/dsc/<CONTROL_ID>/Configuration.ps1`
  - One DSC `Configuration` that enforces exactly one setting.
- `src/dsc/<CONTROL_ID>/metadata.json`
  - Control metadata: configuration name, description, and DSC module dependencies.

### Build (package creation only)

These scripts are intended to run on a **Windows build agent** (because DSC compilation is Windows-based).

- `build/00-InstallModules.ps1`
  - Installs required PowerShell modules (GuestConfiguration + DSC resources).
- `build/01-Build-GuestConfigurationPackages.ps1`
  - Compiles DSC → MOF
  - Creates **one Guest Configuration package ZIP per setting**

> Uploading packages to Storage is intentionally **not** included here (you stated you will handle upload with Terraform).

### Azure Policy artifacts

- `policies/prereqs/`
  - Custom policy definitions + initiative to enforce **prerequisites** on Azure VMs:
    - Machine Configuration extension installed (`AzurePolicyforWindows`)
    - System-assigned identity enabled
    - Required UAMI attached

- `policies/packages/`
  - Custom policy definitions + initiative that deploy **guestConfigurationAssignments** (one per setting)
  - Each policy definition includes explicit **prerequisite checks** (extension + identities) before deploying the assignment.

### Documentation

- `docs/prerequisites.md`
- `docs/policies.md`
- `docs/settings.md`
- `docs/architecture.md`
- `docs/links-used.txt`

## High-level usage flow (Terraform/IaC oriented)

1. **Subscription prerequisites**
   - Register required resource providers (notably `Microsoft.GuestConfiguration`).
   - Ensure the assignment principal has the needed permissions.

2. **Build packages**
   - Run `build/00-InstallModules.ps1`
   - Run `build/01-Build-GuestConfigurationPackages.ps1`

3. **Upload packages to Storage (Terraform)**
   - Upload each ZIP to a private blob container.
   - Compute the **base64-encoded SHA256** content hash.

4. **Deploy policies (Terraform)**
   - Import/assign the **Prereqs initiative**.
   - Run remediation.
   - Import/assign the **Hardening initiative**.
   - Run remediation.

For details, see `docs/prerequisites.md` and `docs/policies.md`.
