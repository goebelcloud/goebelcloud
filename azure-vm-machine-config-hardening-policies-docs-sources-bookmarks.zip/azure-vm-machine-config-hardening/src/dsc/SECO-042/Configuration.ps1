<#
Control ID: SECO-042
Setting: Interactive logon: Machine inactivity limit
Suggested value: 900 seconds (15 minutes)
Generated: 2026-02-12

DSC resource: SecurityPolicyDsc/SecurityOption
#>
Configuration WH_SECO_042
{
    Import-DscResource -ModuleName SecurityPolicyDsc

    Node localhost
    {
        SecurityOption SecurityOption_SECO_042
        {
            Name = 'SECO-042'
            Interactive_logon_Machine_inactivity_limit = '900'
        }
    }
}
