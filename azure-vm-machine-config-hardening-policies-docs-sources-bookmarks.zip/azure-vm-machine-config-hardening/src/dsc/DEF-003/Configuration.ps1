<#
Control ID: DEF-003
Setting: Potentially Unwanted Application (PUA) protection
Suggested value: Enabled (Block)
Generated: 2026-02-12

Implementation: Microsoft Defender cmdlets (Get/Set-MpPreference)
Note: If Defender cmdlets are not present, this configuration returns Compliant.
#>
Configuration WH_DEF_003
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    Node localhost
    {
        Script Defender_DEF_003
        {
            GetScript = {
                if (-not (Get-Command -Name Get-MpPreference -ErrorAction SilentlyContinue)) {
                    return @{ Result = 'DefenderCmdletsNotFound' }
                }
                return @{ Result = (Get-MpPreference).PUAProtection }
            }

            TestScript = {
                if (-not (Get-Command -Name Get-MpPreference -ErrorAction SilentlyContinue)) {
                    return $true
                }
                return ((Get-MpPreference).PUAProtection -eq 1)
            }

            SetScript = {
                if (-not (Get-Command -Name Set-MpPreference -ErrorAction SilentlyContinue)) {
                    return
                }
                Set-MpPreference -PUAProtection Enabled
            }
        }
    }
}
