<#
Control ID: FW-001
Setting: Enable firewall for all profiles
Suggested value: Enabled (Domain/Private/Public) + default inbound = Block
Generated: 2026-02-12

DSC resource: NetworkingDsc/FirewallProfile
#>
Configuration WH_FW_001
{
    Import-DscResource -ModuleName NetworkingDsc

    Node localhost
    {
        FirewallProfile Firewall_Domain
        {
            Name = 'Domain'
            Enabled = 'True'
        }

        FirewallProfile Firewall_Private
        {
            Name = 'Private'
            Enabled = 'True'
        }

        FirewallProfile Firewall_Public
        {
            Name = 'Public'
            Enabled = 'True'
        }
    }
}
