<#
Control ID: NET-002
Setting: Turn off AutoPlay / AutoRun
Suggested value: Enabled (All drives)
Generated: 2026-02-12

DSC resource: PSDesiredStateConfiguration/Registry
#>
Configuration WH_NET_002
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    Node localhost
    {
        Registry Registry_NET_002_1
        {
            Ensure = 'Present'
            Key = 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer'
            ValueName = 'NoDriveTypeAutoRun'
            ValueType = 'Dword'
            ValueData = '255'
        }
    }
}
