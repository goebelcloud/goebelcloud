<#
Control ID: ACCT-007
Setting: Account lockout threshold
Suggested value: 10 invalid logon attempts (WS2025 baseline uses 3; test before lowering)
Generated: 2026-02-12

DSC resource: SecurityPolicyDsc/AccountPolicy
#>
Configuration WH_ACCT_007
{
    Import-DscResource -ModuleName SecurityPolicyDsc

    Node localhost
    {
        AccountPolicy AccountPolicy_ACCT_007
        {
            Name = 'AccountPolicy'
            Account_lockout_threshold = 10
        }
    }
}
