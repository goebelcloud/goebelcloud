<#
Control ID: ACCT-004
Setting: Minimum password length
Suggested value: 14 characters
Generated: 2026-02-12

DSC resource: SecurityPolicyDsc/AccountPolicy
#>
Configuration WH_ACCT_004
{
    Import-DscResource -ModuleName SecurityPolicyDsc

    Node localhost
    {
        AccountPolicy AccountPolicy_ACCT_004
        {
            Name = 'AccountPolicy'
            Minimum_Password_Length = 14
        }
    }
}
