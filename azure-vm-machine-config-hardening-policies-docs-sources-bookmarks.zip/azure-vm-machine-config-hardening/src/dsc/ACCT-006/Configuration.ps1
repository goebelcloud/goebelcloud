<#
Control ID: ACCT-006
Setting: Store passwords using reversible encryption
Suggested value: Disabled
Generated: 2026-02-12

DSC resource: SecurityPolicyDsc/AccountPolicy
#>
Configuration WH_ACCT_006
{
    Import-DscResource -ModuleName SecurityPolicyDsc

    Node localhost
    {
        AccountPolicy AccountPolicy_ACCT_006
        {
            Name = 'AccountPolicy'
            Store_passwords_using_reversible_encryption = 'Disabled'
        }
    }
}
