<#
Control ID: SECO-031
Setting: Microsoft network server: Digitally sign communications (always)
Suggested value: Enabled (SMB signing required for inbound SMB server traffic)
Generated: 2026-02-12

DSC resource: SecurityPolicyDsc/SecurityOption
#>
Configuration WH_SECO_031
{
    Import-DscResource -ModuleName SecurityPolicyDsc

    Node localhost
    {
        SecurityOption SecurityOption_SECO_031
        {
            Name = 'SECO-031'
            Microsoft_network_server_Digitally_sign_communications_always = 'Enabled'
        }
    }
}
