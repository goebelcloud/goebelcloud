<#
Control ID: SECO-010
Setting: Network access: Do not allow anonymous enumeration of SAM accounts
Suggested value: Enabled
Generated: 2026-02-12

DSC resource: SecurityPolicyDsc/SecurityOption
#>
Configuration WH_SECO_010
{
    Import-DscResource -ModuleName SecurityPolicyDsc

    Node localhost
    {
        SecurityOption SecurityOption_SECO_010
        {
            Name = 'SECO-010'
            Network_access_Do_not_allow_anonymous_enumeration_of_SAM_accounts = 'Enabled'
        }
    }
}
