<#
Control ID: ACCT-008
Setting: Account lockout duration
Suggested value: 15 minutes
Generated: 2026-02-12

DSC resource: SecurityPolicyDsc/AccountPolicy
#>
Configuration WH_ACCT_008
{
    Import-DscResource -ModuleName SecurityPolicyDsc

    Node localhost
    {
        AccountPolicy AccountPolicy_ACCT_008
        {
            Name = 'AccountPolicy'
            Account_lockout_duration = 15
        }
    }
}
