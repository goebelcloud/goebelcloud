<#
Control ID: LOG-001
Setting: PowerShell Script Block Logging
Suggested value: Enabled
Generated: 2026-02-12

DSC resource: PSDesiredStateConfiguration/Registry
#>
Configuration WH_LOG_001
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    Node localhost
    {
        Registry Registry_LOG_001_1
        {
            Ensure = 'Present'
            Key = 'HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging'
            ValueName = 'EnableScriptBlockLogging'
            ValueType = 'Dword'
            ValueData = '1'
        }
    }
}
