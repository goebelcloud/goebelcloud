<#
Control ID: SECO-022
Setting: Network security: Minimum session security for NTLM SSP based (including secure RPC) clients
Suggested value: Require NTLMv2 session security; Require 128-bit encryption
Generated: 2026-02-12

DSC resource: SecurityPolicyDsc/SecurityOption
#>
Configuration WH_SECO_022
{
    Import-DscResource -ModuleName SecurityPolicyDsc

    Node localhost
    {
        SecurityOption SecurityOption_SECO_022
        {
            Name = 'SECO-022'
            Network_security_Minimum_session_security_for_NTLM_SSP_based_including_secure_RPC_clients = 'Both options checked'
        }
    }
}
