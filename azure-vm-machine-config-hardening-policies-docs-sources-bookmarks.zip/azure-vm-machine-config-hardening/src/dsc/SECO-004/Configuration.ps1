<#
Control ID: SECO-004
Setting: Accounts: Rename guest account
Suggested value: Rename to non-default (even if disabled)
Generated: 2026-02-12

Implementation: rename built-in local account (SID ends with -501)
Note: Adjust the default name to your org standard before packaging.
#>
Configuration WH_SECO_004
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    Node localhost
    {
        Script RenameBuiltinGuest
        {
            GetScript = {
                $acct = Get-CimInstance -ClassName Win32_UserAccount -Filter "LocalAccount=True AND SID LIKE '%-501'" | Select-Object -First 1
                return @{ Result = $acct.Name }
            }

            TestScript = {
                $desired = 'LocalGuest_Org'
                $acct = Get-CimInstance -ClassName Win32_UserAccount -Filter "LocalAccount=True AND SID LIKE '%-501'" | Select-Object -First 1
                if (-not $acct) { return $true } # account not present
                return ($acct.Name -ieq $desired)
            }

            SetScript = {
                $desired = 'LocalGuest_Org'
                $acct = Get-CimInstance -ClassName Win32_UserAccount -Filter "LocalAccount=True AND SID LIKE '%-501'" | Select-Object -First 1
                if (-not $acct) { return }

                # If another local account already uses the desired name, fail explicitly.
                $existing = Get-CimInstance -ClassName Win32_UserAccount -Filter ("LocalAccount=True AND Name='LocalGuest_Org'") -ErrorAction SilentlyContinue
                if ($existing -and ($existing.SID -ne $acct.SID)) {
                    throw "Cannot rename built-in account ($($acct.SID)) to 'LocalGuest_Org' because that name is already in use."
                }

                $currentName = $acct.Name

                if ($currentName -ieq $desired) { return }

                if (Get-Command -Name Rename-LocalUser -ErrorAction SilentlyContinue) {
                    Rename-LocalUser -Name $currentName -NewName $desired
                }
                else {
                    # WMIC is deprecated but provides broad compatibility for renaming local accounts.
                    & wmic useraccount where name="$currentName" rename "$desired" | Out-Null
                }
            }
        }
    }
}
