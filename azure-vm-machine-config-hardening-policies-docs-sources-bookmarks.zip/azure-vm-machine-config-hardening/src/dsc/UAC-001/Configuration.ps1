<#
Control ID: UAC-001
Setting: User Account Control: Run all administrators in Admin Approval Mode
Suggested value: Enabled
Generated: 2026-02-12

DSC resource: SecurityPolicyDsc/SecurityOption
#>
Configuration WH_UAC_001
{
    Import-DscResource -ModuleName SecurityPolicyDsc

    Node localhost
    {
        SecurityOption SecurityOption_UAC_001
        {
            Name = 'UAC-001'
            User_Account_Control_Run_all_administrators_in_Admin_Approval_Mode = 'Enabled'
        }
    }
}
