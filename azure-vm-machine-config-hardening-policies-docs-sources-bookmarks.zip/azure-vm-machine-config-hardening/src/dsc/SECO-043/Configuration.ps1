<#
Control ID: SECO-043
Setting: Shutdown: Allow system to be shut down without having to log on
Suggested value: Disabled
Generated: 2026-02-12

DSC resource: SecurityPolicyDsc/SecurityOption
#>
Configuration WH_SECO_043
{
    Import-DscResource -ModuleName SecurityPolicyDsc

    Node localhost
    {
        SecurityOption SecurityOption_SECO_043
        {
            Name = 'SECO-043'
            Shutdown_Allow_system_to_be_shut_down_without_having_to_log_on = 'Disabled'
        }
    }
}
