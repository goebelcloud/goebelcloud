<#
Control ID: ACCT-001
Setting: Enforce password history
Suggested value: 24 passwords remembered
Generated: 2026-02-12

DSC resource: SecurityPolicyDsc/AccountPolicy
#>
Configuration WH_ACCT_001
{
    Import-DscResource -ModuleName SecurityPolicyDsc

    Node localhost
    {
        AccountPolicy AccountPolicy_ACCT_001
        {
            Name = 'AccountPolicy'
            Enforce_password_history = 24
        }
    }
}
