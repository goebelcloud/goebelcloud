<#
Control ID: SECO-021
Setting: Network security: LAN Manager authentication level
Suggested value: Send NTLMv2 response only. Refuse LM & NTLM
Generated: 2026-02-12

DSC resource: SecurityPolicyDsc/SecurityOption
#>
Configuration WH_SECO_021
{
    Import-DscResource -ModuleName SecurityPolicyDsc

    Node localhost
    {
        SecurityOption SecurityOption_SECO_021
        {
            Name = 'SECO-021'
            Network_security_LAN_Manager_authentication_level = 'Send NTLMv2 responses only. Refuse LM & NTLM'
        }
    }
}
