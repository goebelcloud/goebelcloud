<#
Control ID: RDP-002
Setting: Set client connection encryption level
Suggested value: High
Generated: 2026-02-12

DSC resource: PSDesiredStateConfiguration/Registry
#>
Configuration WH_RDP_002
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    Node localhost
    {
        Registry Registry_RDP_002_1
        {
            Ensure = 'Present'
            Key = 'HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services'
            ValueName = 'MinEncryptionLevel'
            ValueType = 'Dword'
            ValueData = '3'
        }
    }
}
