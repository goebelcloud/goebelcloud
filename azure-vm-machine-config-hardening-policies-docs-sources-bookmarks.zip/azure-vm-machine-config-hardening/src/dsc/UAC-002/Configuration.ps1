<#
Control ID: UAC-002
Setting: User Account Control: Switch to the secure desktop when prompting for elevation
Suggested value: Enabled
Generated: 2026-02-12

DSC resource: SecurityPolicyDsc/SecurityOption
#>
Configuration WH_UAC_002
{
    Import-DscResource -ModuleName SecurityPolicyDsc

    Node localhost
    {
        SecurityOption SecurityOption_UAC_002
        {
            Name = 'UAC-002'
            User_Account_Control_Switch_to_the_secure_desktop_when_prompting_for_elevation = 'Enabled'
        }
    }
}
