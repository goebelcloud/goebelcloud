<#
Control ID: SECO-041
Setting: Interactive logon: Do not require CTRL+ALT+DEL
Suggested value: Disabled (require CTRL+ALT+DEL)
Generated: 2026-02-12

DSC resource: SecurityPolicyDsc/SecurityOption
#>
Configuration WH_SECO_041
{
    Import-DscResource -ModuleName SecurityPolicyDsc

    Node localhost
    {
        SecurityOption SecurityOption_SECO_041
        {
            Name = 'SECO-041'
            Interactive_logon_Do_not_require_CTRL_ALT_DEL = 'Disabled'
        }
    }
}
