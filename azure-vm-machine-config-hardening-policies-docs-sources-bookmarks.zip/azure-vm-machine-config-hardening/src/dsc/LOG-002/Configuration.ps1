<#
Control ID: LOG-002
Setting: Increase Security log maximum size
Suggested value: >= 196,608 KB (192 MB) (tune for environment)
Minimum size (KB): 196608
Minimum size (bytes): 201326592
Generated: 2026-02-12

Implementation: wevtutil.exe sl Security /ms:<bytes>
#>
Configuration WH_LOG_002
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    Node localhost
    {
        Script SecurityLogMaxSize_LOG_002
        {
            GetScript = {
                $out = & wevtutil.exe gl Security 2>$null
                $line = ($out | Where-Object { $_ -match '^maxSize:' } | Select-Object -First 1)
                $current = if ($line) { [int64]($line -replace '^maxSize:\s*', '') } else { -1 }
                return @{ Result = $current }
            }

            TestScript = {
                $minBytes = [int64]201326592
                $out = & wevtutil.exe gl Security 2>$null
                $line = ($out | Where-Object { $_ -match '^maxSize:' } | Select-Object -First 1)
                if (-not $line) { return $false }
                $current = [int64]($line -replace '^maxSize:\s*', '')
                return ($current -ge $minBytes)
            }

            SetScript = {
                $minBytes = [int64]201326592
                & wevtutil.exe sl Security /ms:$minBytes | Out-Null
            }
        }
    }
}
