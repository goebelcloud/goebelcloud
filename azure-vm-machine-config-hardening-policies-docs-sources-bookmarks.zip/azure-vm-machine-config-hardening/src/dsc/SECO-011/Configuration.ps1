<#
Control ID: SECO-011
Setting: Network access: Do not allow anonymous enumeration of SAM accounts and shares
Suggested value: Enabled
Generated: 2026-02-12

DSC resource: SecurityPolicyDsc/SecurityOption
#>
Configuration WH_SECO_011
{
    Import-DscResource -ModuleName SecurityPolicyDsc

    Node localhost
    {
        SecurityOption SecurityOption_SECO_011
        {
            Name = 'SECO-011'
            Network_access_Do_not_allow_anonymous_enumeration_of_SAM_accounts_and_shares = 'Enabled'
        }
    }
}
