<#
Control ID: ACCT-003
Setting: Minimum password age
Suggested value: 1 day
Generated: 2026-02-12

DSC resource: SecurityPolicyDsc/AccountPolicy
#>
Configuration WH_ACCT_003
{
    Import-DscResource -ModuleName SecurityPolicyDsc

    Node localhost
    {
        AccountPolicy AccountPolicy_ACCT_003
        {
            Name = 'AccountPolicy'
            Minimum_Password_Age = 1
        }
    }
}
