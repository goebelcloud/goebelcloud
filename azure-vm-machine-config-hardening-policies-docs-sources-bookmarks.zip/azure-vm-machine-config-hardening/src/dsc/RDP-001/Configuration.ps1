<#
Control ID: RDP-001
Setting: Require user authentication for remote connections by using Network Level Authentication
Suggested value: Enabled
Generated: 2026-02-12

DSC resource: PSDesiredStateConfiguration/Registry
#>
Configuration WH_RDP_001
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    Node localhost
    {
        Registry Registry_RDP_001_1
        {
            Ensure = 'Present'
            Key = 'HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services'
            ValueName = 'UserAuthentication'
            ValueType = 'Dword'
            ValueData = '1'
        }
    }
}
