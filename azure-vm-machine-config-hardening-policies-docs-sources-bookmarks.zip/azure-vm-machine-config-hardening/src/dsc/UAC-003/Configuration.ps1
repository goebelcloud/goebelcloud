<#
Control ID: UAC-003
Setting: User Account Control: Behavior of the elevation prompt for administrators in Admin Approval Mode
Suggested value: Prompt for consent on the secure desktop
Generated: 2026-02-12

DSC resource: SecurityPolicyDsc/SecurityOption
#>
Configuration WH_UAC_003
{
    Import-DscResource -ModuleName SecurityPolicyDsc

    Node localhost
    {
        SecurityOption SecurityOption_UAC_003
        {
            Name = 'UAC-003'
            User_Account_Control_Behavior_of_the_elevation_prompt_for_administrators_in_Admin_Approval_Mode = 'Prompt for consent on the secure desktop'
        }
    }
}
