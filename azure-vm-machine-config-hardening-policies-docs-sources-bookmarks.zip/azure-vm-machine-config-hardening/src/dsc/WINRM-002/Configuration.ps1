<#
Control ID: WINRM-002
Setting: Disallow Basic authentication
Suggested value: Basic = Disabled (use Kerberos/cert)
Generated: 2026-02-12

DSC resource: PSDesiredStateConfiguration/Registry
#>
Configuration WH_WINRM_002
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    Node localhost
    {
        Registry Registry_WINRM_002_1
        {
            Ensure = 'Present'
            Key = 'HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WinRM\Service\Auth'
            ValueName = 'Basic'
            ValueType = 'Dword'
            ValueData = '0'
        }

        Registry Registry_WINRM_002_2
        {
            Ensure = 'Present'
            Key = 'HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WinRM\Client\Auth'
            ValueName = 'Basic'
            ValueType = 'Dword'
            ValueData = '0'
        }
    }
}
