<#
Control ID: ACCT-005
Setting: Password must meet complexity requirements
Suggested value: Enabled
Generated: 2026-02-12

DSC resource: SecurityPolicyDsc/AccountPolicy
#>
Configuration WH_ACCT_005
{
    Import-DscResource -ModuleName SecurityPolicyDsc

    Node localhost
    {
        AccountPolicy AccountPolicy_ACCT_005
        {
            Name = 'AccountPolicy'
            Password_must_meet_complexity_requirements = 'Enabled'
        }
    }
}
