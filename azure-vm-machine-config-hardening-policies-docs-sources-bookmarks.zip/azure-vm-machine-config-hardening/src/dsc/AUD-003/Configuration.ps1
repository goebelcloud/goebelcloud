<#
Control ID: AUD-003
Setting: Audit Account Management (Success/Failure)
Suggested value: Enable Success and Failure
Audit category: Account Management
Category GUID (Ntsecapi.h): {6997984E-797A-11D9-BED3-505054503030}
Generated: 2026-02-12

Implementation: auditpol.exe (category GUIDs avoid localization issues)
#>
Configuration WH_AUD_003
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    Node localhost
    {
        Script AuditPolicy_AUD_003
        {
            GetScript = {
                $guid = '{6997984E-797A-11D9-BED3-505054503030}'
                $lines = & auditpol.exe /get /category:$guid /r 2>$null
                $headerIndex = ($lines | Select-String -Pattern '^Machine Name,' | Select-Object -First 1).LineNumber
                if (-not $headerIndex) {
                    return @{ Result = 'Unknown' }
                }
                $csvLines = $lines[($headerIndex-1)..($lines.Length-1)]
                $rows = $csvLines | ConvertFrom-Csv
                # Return a compact summary (counts by Inclusion Setting)
                $summary = $rows | Group-Object -Property 'Inclusion Setting' | ForEach-Object { "$($_.Name)=$($_.Count)" }
                return @{ Result = ($summary -join ';') }
            }

            TestScript = {
                $guid = '{6997984E-797A-11D9-BED3-505054503030}'
                $lines = & auditpol.exe /get /category:$guid /r 2>$null
                $headerIndex = ($lines | Select-String -Pattern '^Machine Name,' | Select-Object -First 1).LineNumber
                if (-not $headerIndex) {
                    return $false
                }
                $csvLines = $lines[($headerIndex-1)..($lines.Length-1)]
                $rows = $csvLines | ConvertFrom-Csv

                # We require: Success and Failure
                $nonCompliant = $rows | Where-Object { $_.'Inclusion Setting' -ne 'Success and Failure' }
                return (-not $nonCompliant)
            }

            SetScript = {
                auditpol.exe /set /category:"{6997984E-797A-11D9-BED3-505054503030}" /success:enable /failure:enable | Out-Null
            }
        }
    }
}
