<#
Control ID: DEF-002
Setting: Cloud-delivered protection
Suggested value: Enabled
Generated: 2026-02-12

Implementation: Microsoft Defender cmdlets (Get/Set-MpPreference)
Note: If Defender cmdlets are not present, this configuration returns Compliant.
#>
Configuration WH_DEF_002
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    Node localhost
    {
        Script Defender_DEF_002
        {
            GetScript = {
                if (-not (Get-Command -Name Get-MpPreference -ErrorAction SilentlyContinue)) {
                    return @{ Result = 'DefenderCmdletsNotFound' }
                }
                return @{ Result = (Get-MpPreference).MAPSReporting }
            }

            TestScript = {
                if (-not (Get-Command -Name Get-MpPreference -ErrorAction SilentlyContinue)) {
                    return $true
                }
                return ((Get-MpPreference).MAPSReporting -eq 2)
            }

            SetScript = {
                if (-not (Get-Command -Name Set-MpPreference -ErrorAction SilentlyContinue)) {
                    return
                }
                Set-MpPreference -MAPSReporting Advanced
            }
        }
    }
}
