<#
Control ID: ACCT-002
Setting: Maximum password age
Suggested value: 60 days (or org standard 60–90)
Generated: 2026-02-12

DSC resource: SecurityPolicyDsc/AccountPolicy
#>
Configuration WH_ACCT_002
{
    Import-DscResource -ModuleName SecurityPolicyDsc

    Node localhost
    {
        AccountPolicy AccountPolicy_ACCT_002
        {
            Name = 'AccountPolicy'
            Maximum_Password_Age = 60
        }
    }
}
