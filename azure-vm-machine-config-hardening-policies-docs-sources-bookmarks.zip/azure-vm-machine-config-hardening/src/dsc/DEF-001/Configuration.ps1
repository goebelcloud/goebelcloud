<#
Control ID: DEF-001
Setting: Real-time protection
Suggested value: Enabled (do not disable real-time monitoring)
Generated: 2026-02-12

Implementation: Microsoft Defender cmdlets (Get/Set-MpPreference)
Note: If Defender cmdlets are not present, this configuration returns Compliant.
#>
Configuration WH_DEF_001
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    Node localhost
    {
        Script Defender_DEF_001
        {
            GetScript = {
                if (-not (Get-Command -Name Get-MpPreference -ErrorAction SilentlyContinue)) {
                    return @{ Result = 'DefenderCmdletsNotFound' }
                }
                return @{ Result = (Get-MpPreference).DisableRealtimeMonitoring }
            }

            TestScript = {
                if (-not (Get-Command -Name Get-MpPreference -ErrorAction SilentlyContinue)) {
                    return $true
                }
                return ((Get-MpPreference).DisableRealtimeMonitoring -eq $false)
            }

            SetScript = {
                if (-not (Get-Command -Name Set-MpPreference -ErrorAction SilentlyContinue)) {
                    return
                }
                Set-MpPreference -DisableRealtimeMonitoring $false
            }
        }
    }
}
