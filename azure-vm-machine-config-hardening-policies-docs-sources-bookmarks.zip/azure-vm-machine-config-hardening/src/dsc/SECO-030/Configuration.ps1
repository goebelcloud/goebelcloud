<#
Control ID: SECO-030
Setting: Microsoft network client: Digitally sign communications (always)
Suggested value: Enabled (SMB signing required for outbound SMB client traffic)
Generated: 2026-02-12

DSC resource: SecurityPolicyDsc/SecurityOption
#>
Configuration WH_SECO_030
{
    Import-DscResource -ModuleName SecurityPolicyDsc

    Node localhost
    {
        SecurityOption SecurityOption_SECO_030
        {
            Name = 'SECO-030'
            Microsoft_network_client_Digitally_sign_communications_always = 'Enabled'
        }
    }
}
