<#
Control ID: SECO-023
Setting: Network security: Minimum session security for NTLM SSP based (including secure RPC) servers
Suggested value: Require NTLMv2 session security; Require 128-bit encryption
Generated: 2026-02-12

DSC resource: SecurityPolicyDsc/SecurityOption
#>
Configuration WH_SECO_023
{
    Import-DscResource -ModuleName SecurityPolicyDsc

    Node localhost
    {
        SecurityOption SecurityOption_SECO_023
        {
            Name = 'SECO-023'
            Network_security_Minimum_session_security_for_NTLM_SSP_based_including_secure_RPC_servers = 'Both options checked'
        }
    }
}
