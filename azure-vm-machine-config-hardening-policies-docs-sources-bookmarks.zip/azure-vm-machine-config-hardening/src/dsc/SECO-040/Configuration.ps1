<#
Control ID: SECO-040
Setting: Interactive logon: Do not display last user name
Suggested value: Enabled
Generated: 2026-02-12

DSC resource: SecurityPolicyDsc/SecurityOption
#>
Configuration WH_SECO_040
{
    Import-DscResource -ModuleName SecurityPolicyDsc

    Node localhost
    {
        SecurityOption SecurityOption_SECO_040
        {
            Name = 'SECO-040'
            Interactive_logon_Do_not_display_last_user_name = 'Enabled'
        }
    }
}
