<#
Control ID: ACCT-009
Setting: Reset account lockout counter after
Suggested value: 15 minutes
Generated: 2026-02-12

DSC resource: SecurityPolicyDsc/AccountPolicy
#>
Configuration WH_ACCT_009
{
    Import-DscResource -ModuleName SecurityPolicyDsc

    Node localhost
    {
        AccountPolicy AccountPolicy_ACCT_009
        {
            Name = 'AccountPolicy'
            Reset_account_lockout_counter_after = 15
        }
    }
}
