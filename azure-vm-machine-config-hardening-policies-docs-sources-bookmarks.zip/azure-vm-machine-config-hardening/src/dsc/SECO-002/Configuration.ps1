<#
Control ID: SECO-002
Setting: Accounts: Guest account status
Suggested value: Disabled
Generated: 2026-02-12

DSC resource: SecurityPolicyDsc/SecurityOption
#>
Configuration WH_SECO_002
{
    Import-DscResource -ModuleName SecurityPolicyDsc

    Node localhost
    {
        SecurityOption SecurityOption_SECO_002
        {
            Name = 'SECO-002'
            Accounts_Guest_account_status = 'Disabled'
        }
    }
}
