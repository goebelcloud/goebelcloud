<#
Control ID: NET-001
Setting: Disable SMBv1 (Client and Server)
Suggested value: Disable/remove SMBv1
Windows Feature: FS-SMB1
Generated: 2026-02-12

DSC resource: PSDesiredStateConfiguration/WindowsFeature
Note: Removing SMBv1 may require a reboot.
#>
Configuration WH_NET_001
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    Node localhost
    {
        WindowsFeature Feature_NET_001
        {
            Ensure = 'Absent'
            Name = 'FS-SMB1'
        }
    }
}
