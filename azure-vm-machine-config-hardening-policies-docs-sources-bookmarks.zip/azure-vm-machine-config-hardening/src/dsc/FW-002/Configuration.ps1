<#
Control ID: FW-002
Setting: Enable firewall logging
Suggested value: Log dropped packets = Yes; Log successful connections = (Optional); Log size >= 16,384 KB
Generated: 2026-02-12

DSC resource: NetworkingDsc/FirewallProfile
#>
Configuration WH_FW_002
{
    Import-DscResource -ModuleName NetworkingDsc

    Node localhost
    {
        FirewallProfile FirewallLogging_Domain
        {
            Name = 'Domain'
            LogBlocked = 'True'
            LogAllowed = 'False'
            LogFileName = '%systemroot%\system32\LogFiles\Firewall\pfirewall.log'
            LogMaxSizeKilobytes = 16384
        }

        FirewallProfile FirewallLogging_Private
        {
            Name = 'Private'
            LogBlocked = 'True'
            LogAllowed = 'False'
            LogFileName = '%systemroot%\system32\LogFiles\Firewall\pfirewall.log'
            LogMaxSizeKilobytes = 16384
        }

        FirewallProfile FirewallLogging_Public
        {
            Name = 'Public'
            LogBlocked = 'True'
            LogAllowed = 'False'
            LogFileName = '%systemroot%\system32\LogFiles\Firewall\pfirewall.log'
            LogMaxSizeKilobytes = 16384
        }
    }
}
