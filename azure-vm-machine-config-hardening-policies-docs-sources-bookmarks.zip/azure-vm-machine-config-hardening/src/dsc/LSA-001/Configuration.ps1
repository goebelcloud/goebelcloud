<#
Control ID: LSA-001
Setting: Enable LSA protection (RunAsPPL)
Suggested value: Enabled (Audit first if possible)
Generated: 2026-02-12

DSC resource: PSDesiredStateConfiguration/Registry
#>
Configuration WH_LSA_001
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration

    Node localhost
    {
        Registry Registry_LSA_001_1
        {
            Ensure = 'Present'
            Key = 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Lsa'
            ValueName = 'RunAsPPL'
            ValueType = 'Dword'
            ValueData = '1'
        }
    }
}
