<#
Control ID: SECO-012
Setting: Network access: Let Everyone permissions apply to anonymous users
Suggested value: Disabled
Generated: 2026-02-12

DSC resource: SecurityPolicyDsc/SecurityOption
#>
Configuration WH_SECO_012
{
    Import-DscResource -ModuleName SecurityPolicyDsc

    Node localhost
    {
        SecurityOption SecurityOption_SECO_012
        {
            Name = 'SECO-012'
            Network_access_Let_Everyone_permissions_apply_to_anonymous_users = 'Disabled'
        }
    }
}
