#requires -Version 7.0
<#
    EAGP Tenant Assessment — READ ONLY
    ---------------------------------
    Erhebt App-/Service-Principal-/Credential-/Consent-/Policy-/Agent-Posture eines
    Microsoft-Entra-Tenants, um den Bestand in die EAGP-Tier-Taxonomie (M/A/P/E) zu
    klassifizieren und den Guardrail-/Risiko-Stand zu ermitteln.

    Fuehrt KEINE Aenderungen durch — nur Get-* / GET (Invoke-MgGraphRequest).
    Microsoft Graph gibt niemals Secret-*Werte* zurueck, nur Metadaten.

    Rolle (Least Privilege): Global Reader.
    Erster Lauf auf grossem Tenant: -SkipRiskScan (Schritt 5 = 1 Graph-Call pro SP).

    Ausgabe: Ordner mit 00_SUMMARY.json (Kurzfassung) + CSV/JSON-Detaildateien.
#>
param(
    [string]$OutDir = "./eagp-assessment-$(Get-Date -Format 'yyyyMMdd-HHmmss')",
    [switch]$SkipRiskScan
)
$ErrorActionPreference = 'Stop'
$agentErr = $null
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

foreach ($m in @('Microsoft.Graph.Authentication','Microsoft.Graph.Applications',
                 'Microsoft.Graph.Identity.DirectoryManagement')) {
    if (-not (Get-Module -ListAvailable -Name $m)) {
        Write-Host "Installing $m ..." -ForegroundColor Yellow
        Install-Module $m -Scope CurrentUser -Force -AllowClobber
    }
}

Connect-MgGraph -Scopes 'Directory.Read.All','Application.Read.All',
                        'Policy.Read.All','Organization.Read.All' -NoWelcome
$ctx = Get-MgContext; $tenantId = $ctx.TenantId
Write-Host "Connected to $tenantId as $($ctx.Account)" -ForegroundColor Green

$MicrosoftOwners = @('f8cdef31-a31e-4b4a-93e4-5f571e91255a','72f988bf-86f1-41af-91ab-2d7cd011db47')
$HighRisk = @('Directory.ReadWrite.All','Application.ReadWrite.All','AppRoleAssignment.ReadWrite.All',
              'RoleManagement.ReadWrite.Directory','User.ReadWrite.All','Group.ReadWrite.All',
              'Mail.ReadWrite','Files.ReadWrite.All','Sites.FullControl.All')
$GraphAppId = '00000003-0000-0000-c000-000000000000'
$now = Get-Date; $sum = [ordered]@{}

# 1 — Licenses (SKUs)
Write-Host "[1/7] SKUs ..." -ForegroundColor Cyan
Get-MgSubscribedSku -All | Select-Object SkuPartNumber, SkuId,
    @{n='Enabled';e={$_.PrepaidUnits.Enabled}}, @{n='Consumed';e={$_.ConsumedUnits}} |
    Sort-Object SkuPartNumber | Export-Csv "$OutDir/01_skus.csv" -NoTypeInformation -Encoding UTF8

# 2 — App management policies
Write-Host "[2/7] App management policies ..." -ForegroundColor Cyan
try { $def = Invoke-MgGraphRequest GET 'v1.0/policies/defaultAppManagementPolicy' -OutputType PSObject }
catch { $def = [pscustomobject]@{ error = $_.Exception.Message } }
$def | ConvertTo-Json -Depth 12 | Out-File "$OutDir/02_default_policy.json" -Encoding UTF8
try { $cust = (Invoke-MgGraphRequest GET 'v1.0/policies/appManagementPolicies' -OutputType PSObject).value }
catch { $cust = @() }
$cust | ConvertTo-Json -Depth 12 | Out-File "$OutDir/02_custom_policies.json" -Encoding UTF8
$sum['DefaultAppMgmtPolicyEnabled'] = [bool]($def.isEnabled)
$sum['CustomAppMgmtPolicies']       = @($cust).Count

# 3 — Application registrations (Definitionen, die wir potenziell besitzen)
Write-Host "[3/7] Applications ..." -ForegroundColor Cyan
$apps = Get-MgApplication -All -Property id,appId,displayName,signInAudience,createdDateTime,passwordCredentials,keyCredentials
$apps | ForEach-Object {
    $pw=@($_.PasswordCredentials); $kc=@($_.KeyCredentials); $all=@($pw+$kc)
    [pscustomobject]@{
        DisplayName=$_.DisplayName; AppId=$_.AppId; SignInAudience=$_.SignInAudience
        Created=$_.CreatedDateTime; Secrets=$pw.Count; Certs=$kc.Count
        ExpiringSoon60d=@($all|?{$_.EndDateTime -and $_.EndDateTime -gt $now -and $_.EndDateTime -lt $now.AddDays(60)}).Count
        Expired=@($all|?{$_.EndDateTime -and $_.EndDateTime -le $now}).Count
        MultiTenant=($_.SignInAudience -ne 'AzureADMyOrg')
    }
} | Export-Csv "$OutDir/03_applications.csv" -NoTypeInformation -Encoding UTF8
$sum['AppRegistrations']  = $apps.Count
$sum['AppsWithSecrets']   = @($apps|?{@($_.PasswordCredentials).Count -gt 0}).Count

# 4 — Service principals (Tier-Klassifikation)
Write-Host "[4/7] Service principals ..." -ForegroundColor Cyan
$sps = Get-MgServicePrincipal -All -Property id,appId,displayName,servicePrincipalType,accountEnabled,appOwnerOrganizationId,verifiedPublisher,tags,passwordCredentials,keyCredentials
$spRows = $sps | ForEach-Object {
    $o=$_.AppOwnerOrganizationId
    $tier = if ($o -eq $tenantId) {'Internal (Tier M/P)'}
            elseif ($MicrosoftOwners -contains $o) {'Microsoft first-party'}
            elseif ($o) {'External / Marketplace (Tier E)'} else {'Unknown'}
    [pscustomobject]@{
        DisplayName=$_.DisplayName; AppId=$_.AppId; Type=$_.ServicePrincipalType
        Enabled=$_.AccountEnabled; OwnerTenant=$o; TierGuess=$tier
        VerifiedPublisher=$_.VerifiedPublisher.DisplayName
        Secrets=@($_.PasswordCredentials).Count; Certs=@($_.KeyCredentials).Count
        Tags=($_.Tags -join ';')
    }
}
$spRows | Export-Csv "$OutDir/04_service_principals.csv" -NoTypeInformation -Encoding UTF8
$sum['ServicePrincipals']     = $sps.Count
$sum['SP_External_TierE']     = @($spRows|?{$_.TierGuess -like 'External*'}).Count
$sum['SP_ExternalUnverified'] = @($spRows|?{$_.TierGuess -like 'External*' -and -not $_.VerifiedPublisher}).Count

# 5 — High-risk app-only Graph permissions (langsam bei vielen SPs)
if (-not $SkipRiskScan) {
    Write-Host "[5/7] High-risk app permissions (kann dauern) ..." -ForegroundColor Cyan
    $g = Get-MgServicePrincipal -Filter "appId eq '$GraphAppId'" -Property id,appRoles
    $map=@{}; $g.AppRoles | ForEach-Object { $map[$_.Id]=$_.Value }
    $risky = New-Object System.Collections.Generic.List[object]; $i=0
    foreach ($s in $sps) {
        if ((++$i)%200 -eq 0){ Write-Host "   $i/$($sps.Count)" }
        try { $as = Get-MgServicePrincipalAppRoleAssignment -ServicePrincipalId $s.Id -All } catch { continue }
        foreach ($a in $as) {
            if ($a.ResourceId -eq $g.Id -and $HighRisk -contains $map[$a.AppRoleId]) {
                $risky.Add([pscustomobject]@{ SP=$s.DisplayName; AppId=$s.AppId
                    Type=$s.ServicePrincipalType; OwnerTenant=$s.AppOwnerOrganizationId
                    GraphAppPermission=$map[$a.AppRoleId] })
            }
        }
    }
    $risky | Export-Csv "$OutDir/05_highrisk_permissions.csv" -NoTypeInformation -Encoding UTF8
    $sum['SPs_HighRiskGraphPerms'] = (@($risky)|Select-Object -Unique AppId).Count
} else { Write-Host "[5/7] Risk scan SKIPPED" -ForegroundColor DarkYellow }

# 6 — Delegated consent grants (OAuth2)
Write-Host "[6/7] Delegated consent grants ..." -ForegroundColor Cyan
$grants = Get-MgOauth2PermissionGrant -All
$grants | Select-Object ClientId,ResourceId,ConsentType,PrincipalId,
    @{n='Scopes';e={$_.Scope.Trim()}} | Export-Csv "$OutDir/06_consent_grants.csv" -NoTypeInformation -Encoding UTF8
$sum['DelegatedGrants']         = $grants.Count
$sum['TenantWideAdminConsents'] = @($grants|?{$_.ConsentType -eq 'AllPrincipals'}).Count

# 7 — Agent ID (GA 2026) — best effort
Write-Host "[7/7] Agent identities & blueprints ..." -ForegroundColor Cyan
try { $ag = (Invoke-MgGraphRequest GET 'v1.0/servicePrincipals/microsoft.graph.agentIdentity?$select=id,displayName,createdByAppId,agentIdentityBlueprintId,accountEnabled' -OutputType PSObject).value }
catch { $ag=@(); $agentErr=$_.Exception.Message }
try { $bp = (Invoke-MgGraphRequest GET 'v1.0/applications/microsoft.graph.agentIdentityBlueprint?$select=id,appId,displayName,createdDateTime,publisherDomain' -OutputType PSObject).value }
catch { $bp=@() }
$ag | ConvertTo-Json -Depth 8 | Out-File "$OutDir/07_agent_identities.json" -Encoding UTF8
$bp | ConvertTo-Json -Depth 8 | Out-File "$OutDir/07_agent_blueprints.json" -Encoding UTF8
$sum['AgentIdentities'] = @($ag).Count
$sum['AgentBlueprints'] = @($bp).Count
if ($agentErr){ $sum['AgentIdNote']="cast nicht lesbar: $agentErr (Agent ID evtl. nicht aktiviert / Rolle fehlt)" }

# Summary
$sum['TenantId']=$tenantId; $sum['GeneratedAt']=$now.ToString('u')
$sum | ConvertTo-Json -Depth 5 | Out-File "$OutDir/00_SUMMARY.json" -Encoding UTF8
Write-Host "`n==== SUMMARY ====" -ForegroundColor Green
$sum.GetEnumerator() | ForEach-Object { "{0,-30} {1}" -f $_.Key,$_.Value } | Write-Host
Write-Host "`nOutput: $OutDir" -ForegroundColor Green
Disconnect-MgGraph | Out-Null
