# POC.md — Erster Proof of Concept

> Ziel des POC: **Architektur, Sicherheit und Kernnutzen beweisen** — mit minimalem Surface,
> ausschließlich im **Dev-Wegwerf-Tenant**. Der POC ist **nicht** das MVP; er de-risked die
> teuren/riskanten Annahmen früh. Er kann **parallel** zu den Management-Entscheidungen
> starten (nur die hochprivilegierten Grant-Pfade hängen an ADR-008).

## Was der POC beweisen muss (Hypothesen)
1. **Privilege Separation funktioniert:** die API hat keine Graph-Write-Rechte; nur der Executor mutiert Entra.
2. **Secretless Executor funktioniert:** App Registration + Workload Identity Federation, kein gespeichertes Secret.
3. **Kein Secret in State/Log:** Secret-Erzeugung out-of-band via Graph → Key Vault; State/Log bleiben sauber.
4. **Approval-Gate + Immutable Audit greifen:** eine gegatete Aktion erzeugt einen WORM-Nachweis.
5. **Governance-Nutzen ist real:** mind. ein Report deckt eine echte Non-Compliance auf (z. B. `AssignmentRequired=false`).
6. **Autonomer Build-Loop trägt:** Claude Code baut den POC im Loop grün, Mensch merged an Checkpoints.

## Scope (bewusst schmal)

```mermaid
flowchart LR
    A["Admin"] --> API["EAGP API (read-only Graph)"]
    API --> POL["Policy Engine (4 Invarianten)"]
    POL --> SB["Service Bus"]
    SB --> EX["Executor (WIF, secretless)"]
    EX --> G["Graph (DEV-Tenant)"]
    EX --> KV["Key Vault"]
    API --> AUD["Immutable Audit (WORM)"]
    RPT["Report: AssignmentRequired-Compliance + Credential-Expiry"] --> G
```

**Drin:**
- Plattform-IaC-Minimum im Dev-Tenant (ACA, PostgreSQL, KV, Storage, Service Bus, PE, Split-Sink-Log).
- **Ein Tier-M-App-Flow:** create aus Template → declare → **approve** → apply via Executor → **audit**.
- **Credentials:** FIC + Cert anlegen, KV-Storage, Expiry-Report, One-time-Reveal (TTL).
- **Zwei Reports:** (R1) Credential-Expiry, (ADR-019) `AssignmentRequired`/Security-Gruppen-Compliance.
- **Die 4 Sicherheits-Invarianten** als Tests (das Orakel).

**Draußen (bewusst):** SCIM, SSO-Tiefe, Tier-A/P/E-Governance, Brownfield-Import, Bulk,
Drift-Breite, ServiceNow, hochprivilegierte Grants (ADR-008), Prod-Anbindung.

## Ablauf (Tasks aus TASKS.md)
Welle 0 (**T00–T04**) → Welle 1 (**T10–T11**) → aus Welle 2: **T20, T21, T22, T23, T24** + Report R1.
Alles gegen den **Dev-Tenant**; Loop-Betrieb nach `OPERATING_MODEL.md`.

## Exit-Kriterien (POC bestanden, wenn alle grün)
- [ ] E2E: Tier-M-App create→approve→apply→verify läuft reproduzierbar gegen Dev-Tenant.
- [ ] Scrubbing-Test: **kein** Secret-Wert in State/Plan/Log/DB (CI-Check grün).
- [ ] Die **4 Invarianten-Tests** sind grün; eine bewusst verletzende Aktion wird abgelehnt.
- [ ] Eine gegatete (H2) Aktion erzeugt einen WORM-Audit-Eintrag (fehlt er → Fail).
- [ ] Compliance-Report findet in den Fixtures die `AssignmentRequired=false`-App.
- [ ] Executor besitzt **kein** gespeichertes Secret (WIF verifiziert); API hat **keine** Graph-Write-Scopes.
- [ ] Der Build lief überwiegend **autonom** (Claude Code), Mensch nur an PR-Checkpoints.

## Voraussetzungen für den POC-Start (📥)
- **Dev-Wegwerf-Tenant** verfügbar (nicht Prod).
- **Azure-Dev-Subscription** in `germanywestcentral`.
- **Container/Firewall** für den Loop (VPS oder Pipeline) — siehe OPERATING_MODEL.
- **Entra ID P2** ist für den POC-Scope **nicht** zwingend (nur für den späteren Weg-A-Grant-Pfad).

## Nach dem POC
Bei bestandenem POC → Ausbau Richtung MVP entlang `ROADMAP.md`/`TASKS.md`. Management-
Entscheidungen (M1–M6) sollten bis dahin vorliegen, insb. **ADR-008** (schaltet die
hochprivilegierten Grant-Pfade frei) und **M4/M5** (Betriebsrat/Art.30, Pentest = Go-Live-Gates).
