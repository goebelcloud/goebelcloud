# DECISIONS.md — EAGP Architecture Decision Log

> **Autoritatives Entscheidungsregister.** Jede Design-Entscheidung + ihr *Warum* + ihr
> Status. Dieses File ist die Übergabe-Grundlage: eine frische Claude-Code-Session (oder ein
> Mensch) liest hier, was entschieden ist, was offen ist und warum — **ohne in einen Chat
> zurückzumüssen**. Bei Detailwidersprüchen gilt `SPEC.md`; für den Entscheidungs-*Status*
> gilt dieses File.

## Status-Legende
- ✅ **DECIDED** — getroffen, umsetzbar.
- 🟡 **RECOMMENDED / OPEN** — Empfehlung steht, finale Entscheidung offen (Person/Environment).
- ⏸️ **DEFERRED** — bewusst später (Bau-Welle), nicht blockierend.
- 🔴 **MANAGEMENT** — nur Management/Chef/andere Ebene kann entscheiden.
- 📥 **NEEDS FACT** — hängt an einem Fakt, den nur das Environment liefern kann.

## Zwei übergreifende Prinzipien (erledigen die meisten Einzelfragen)
- **ADR-021 Vollständigkeit:** EAGP bildet den *gesamten* App-Registration-/Enterprise-App-Surface ab und **verwaltet** ihn (nicht nur reporten). Pro Fähigkeit offen ist nur noch **Bau-Welle** + **Härte** — nie das „Ob". Referenz-Surface = `FEATURE_PARITY.md` (MVP-Abnahme-Gate).
- **ADR-022 Härte-Klassifikator (H0–H3):** *Wie viel* Gate eine Aktion braucht, ergibt sich aus ihrem Blast-Radius, nicht aus der Feature-Kategorie. Höchste zutreffende Stufe gewinnt; Ambiguität → höher; Least Privilege = nur H0 stehend, Rest JIT/approved.

---

## Teil A — Architektur-Grundlagen (ADR-001 … 017)

| ADR | Entscheidung | Status |
|---|---|---|
| 001 | Secret-Reveal **Hybrid** (KV-Referenz + auditierter One-time-Reveal, TTL ~15 min) | ✅ |
| 002 | Region **germanywestcentral** (eastus = MUST NOT) | ✅ |
| 003 | **Kein CMK** (platform-managed Keys; GDPR-07) | ✅ |
| 004 | Generierte TF-Config als **Versioned Blob** (Git-Mirror = Phase-2-Option) | ✅ |
| 005 | Stack: **Terraform + Python** (einsprachige App) — **kein PowerShell in der Runtime, kein .NET**; Frontend TS/React → **REVIDIERT** (Volltext: „ADR-005 (revidiert)“) | ✅ |
| 006 | Frontend **internal-only + Zscaler ZPA**, kein WAF | ✅ |
| 007 | Executor = **App Registration + Workload Identity Federation** (secretless) + CA for Workload Identities; Plattform-Apps auf Deny-List | ✅ |
| **008** | **Executor-Modell für High-Priv-Grants** — gehärtetes Weg B (siehe Volleintrag unten) | 🟡 **RECOMMENDED** — Zielzustand steht, Security-Freigabe offen. Nicht mehr binär A/B |
| 009 | Cert-Modell **3 Klassen** (self-signed EAGP-managed / Custody beigestellt / MS-SAML-Signing orchestriert) | ✅ |
| 010 | Credential-Verwaltung **risiko-gestuft** (subsumiert von ADR-022) | ✅ |
| 011 | Approval-Modell **konfigurierbar** (Approver-Pool + Quorum; Default 2-of-N HIGH-T0) | ✅ (Pool-Besetzung → Management) |
| 012 | Brownfield-Alt-Credentials **gestuft** (Duldung mit überwachter Rotationsfrist) | ✅ |
| 013 | Ticket-Pflicht **optional/konfigurierbar** (subsumiert von ADR-022) | ✅ |
| 014 | Business-ID-Auflösung **ausschließlich über Entra** (Attributname = Config) | ✅ (Attributname → 📥) |
| 015 | Log-Sink **Split-Sink** (Security/Audit → Sentinel; Ops → günstig/Basic; Immutable Audit → WORM) | ✅ |
| 016 | **App-Tier-Taxonomie M/A/P/E** (nur M = Full Lifecycle; A/P/E = Govern) | ✅ |
| 017 | **ServiceNow CMDB Reconciliation** (einseitiger Feed über IRE; optional Phase 3, entkoppelt) | ✅ (Details Phase 3) |

Volltext zu 001–017: `SPEC.md` §3 + zugehörige Kapitel.

### ADR-008 (revised) — Executor-Modell für High-Privilege-Grants · 🟡 RECOMMENDED
**Nicht mehr binär „Weg A vs. Weg B".** Die Frage ist *nicht* Mensch-vs-Maschine-Auth (eine
Workload Identity lässt sich stark härten), sondern **wo tenant-übernahme-fähige Macht *stehend*
liegt** — plus die verifizierte Einschränkung, dass ein Service Principal **nicht PIM-eligible**
sein kann (kein Self-Service-JIT für Maschinen), sondern nur *stehend aktiv* oder *time-limited
active*.

**Zielzustand — gehärtetes Weg B (B-timeboxed):** Executor führt High-Priv-Grants aus, hält aber
**kein stehendes Tier-0**. Ablauf: EAGP-Grant (H3) → **Team-Quorum-Approval** (planHash-gebunden)
→ Team-Mitglied **aktiviert scoped Priv-Rolle via PIM** (2. Team-Mitglied approved + YubiKey +
PAW via CA) → legt dem Executor-SP eine **time-boxed active** Zuweisung an (z. B. 1 h) → Executor
führt aus → Zuweisung **läuft automatisch ab** → WORM-Audit + Anomaly-Alert.

**Executor-Härtung:** App Registration + **FIC (secretless)** · **CA for Workload Identities**
(IP-Lock auf Pipeline-Egress, non-trusted Named Location) · **ID Protection + CAE** (Echtzeit-
Revoke bei Risk/Disable/Delete → 401) · stehend nur `Application.ReadWrite.OwnedBy`. *(Caveat:
Managed Identities sind von CA for Workload Identities ausgeschlossen → App Reg + WIF ist korrekt;
CAE nur gegen Microsoft Graph, CA-Policy muss den SP direkt targeten, nicht via Gruppe.)*

**Tiered Approval (mappt auf H2/H3):**
- **H2** (moderat privilegiert, häufig — hier tut der Bottleneck weh): **Team-Quorum (2 Team-Mitglieder)**.
- **H3** (tenant-übernahme-fähig: `Directory.ReadWrite.All`, `RoleManagement.ReadWrite.Directory`,
  Directory-Rolle an SP): **Team-Quorum + 1 Security/T0-Approver**.
- **Deny-List**: nie per Self-Service — gar nicht.

**Flaschenhals-Fix (unabhängig vom Modell):** Team wird der **PIM-eligible Approver-Pool** (Quorum
≥2) → jedes qualifizierte Team-Paar kann handeln statt eines bestimmten verteilten T0. Autorität
dort ansiedeln, wo die Kompetenz sitzt.

**Fallback** (falls Security „Maschine führt finalen Grant aus" ablehnt): **„Weg A mit Team-Pool"**
— Team-Mitglied führt den Grant im frisch aktivierten Fenster aus; Maschine macht 99 % (Assessment/
Plan/Audit/Rest-Lifecycle). Kleiner Delta, **gleiche No-Standing-Eigenschaft**.

**Verworfen: B-standing** (stehendes `Directory.ReadWrite.All` am Executor) — genau die stehende
Konzentration, die einen Control-Plane-Bug in eine Tenant-Übernahme verwandelt. Kein Grund dafür,
sobald B-timeboxed existiert.

**Was Security freigeben muss (offen, 🔴):** (1) Control-Plane-Blast-Radius akzeptieren — Mitigations:
planHash-Bindung, out-of-band-Approval-Plane, time-boxed statt stehend, CAE-Revoke; (2) SoD
„Team genehmigt sich selbst" via Quorum + Security im H3-Quorum + Access Reviews; (3) Kontrolle des
time-boxed-Assignment-Mechanismus (wer legt an, Auto-Expiry, Alerting). **Security-Rolle = Guardrails
setzen + periodische Audit-Oversight, nicht Per-Transaction-Approval.**

**Verifizierte Grundlage (MS Learn, 2026):** SP nicht PIM-eligible, nur time-limited active; CA for
Workload Identities GA (Workload ID Premium, single-tenant SP, IP/Risk/Auth-Context; token-time
enforcement unabhängig von Auth-Methode); CAE Echtzeit-Revoke gegen Graph; Certificate > Client
Secret. Subsumiert ADR-007/022-H3.

---

## Teil B — Entscheidungen dieser Session (ADR-018 … 028)

### ADR-018 — Autonomer Entwicklungs-Loop (Claude Code) · 🟡 RECOMMENDED, Detail-Calls offen
**Kontext:** Der Chat (Design) wird nach der Übergabe durch Claude Code (Ausführung) ersetzt. Ziel: Agent arbeitet den Backlog weitgehend unbeaufsichtigt ab; Mensch reviewt an Checkpoints.
**Entscheidung (Richtung):** Loop = Backlog → implement → `make check` (Harness inkl. 4 Invarianten) → fix-Loop bis grün → Feature-Branch → PR → **Mensch-Review-Checkpoint**. Die Testsuite ist das Orakel, das menschliches Prompten ersetzt.
**Empfehlungen (finale Calls offen — siehe `MANAGEMENT_DECISIONS.md` / Environment):**
- Autonomiegrad: **Auto mode + strikte `deny` + Enterprise-Managed-Settings-Floor + Container/Firewall**.
- Merge-Gate: **alle PRs mensch-gemerged** (Tier-0, kein Auto-Merge).
- Ausführungsort: VPS-Container (Overnight) vs. Azure-DevOps-Pipeline. `claude-code-action` ist GitHub-only → auf Azure DevOps `claude -p --bare` selbst wrappen. 📥 *Ist der VPS schon Container mit Egress-Kontrolle?*
**Nicht verhandelbar:** Container statt bare metal; kein Pfad zu Prod/echtem Tenant; `deny` für `terraform apply`/Prod/`.env*`/`main`-Edits/**Test-Abschwächung**; PreToolUse-`opsec-guard.sh`. Details: `OPERATING_MODEL.md`.

### ADR-019 — User/Group-Assignment + „Assignment required" · ✅ DECIDED (MVP)
`appRoleAssignmentRequired = true` = Default-Zielzustand (EAGP setzt ihn bei Neuanlage); Zuweisung **über Security-Gruppen** erzwungen/genudged (bestätigt: euer Standard). Öffnen auf `false` = **H2 approval-pflichtig**. **Compliance-Report (MVP), gescoped auf user-facing/SSO-Apps** (app-only-SPs ausgenommen) mit 4-Zustands-Taxonomie: `false`=CRITICAL; `true`+Einzelnutzer/keine Gruppe=GAP(Governance); `true`+keine Zuweisung=GAP(Orphan→R4); `true`+Security-Gruppe=COMPLIANT. Remediation-Kampagne für Alt-Apps (koppelt Brownfield-Import + Drift). 📥 *Gruppen-Lifecycle ggf. extern (IGA)?*

### ADR-020 — SCIM-Provisioning · ✅ DECIDED (volle Verwaltung), Reihenfolge ⏸️
EAGP bildet SCIM **vollständig ab und verwaltet es** (Lifecycle, Health, Credentials, **Attribute-Mappings, Scoping**) via Graph `synchronization`-API. Mappings/Scoping = **H2 approval-pflichtig + What-if-Vorschau** (Blast-Radius Identitäts-Downstream; koppelt R10). SCIM-Credentials wie alle Credentials (Key Vault + Expiry + Rotation). DSGVO: nur nötige Attribute mappen; Residency/Schrems-II der Ziel-SaaS. ⏸️ Bau-Reihenfolge der Mapping-Bearbeitung (1. vs. 2. Welle) → Claude Code anhand `FEATURE_PARITY.md`.

### ADR-021 — Vollständigkeitsprinzip · ✅ DECIDED (übergreifend)
Siehe oben. Governance-Domänen-Grenzen (CA-Authoring, Security-Gruppen-Lifecycle, Azure-RBAC-Authoring, Cross-Tenant-Settings) werden **benannt und begründet** (read/report/handoff), nicht weggelassen.

### ADR-022 — Governance-Härte-Modell (H0–H3) · ✅ DECIDED (übergreifend)
| Härte | Greift, wenn die Aktion… | Gate |
|---|---|---|
| **H0** Autonomous | reversibel, kleiner Radius, in-scope; keine Privileg-/Tenant-/Identitäts-/Credential-Wirkung | App-Group-Admin (auditiert) |
| **H1** Peer-Approval (4-Augen) | mittlerer Radius: potente Credential-Ops, nicht-priv. Permission-/Config-Änderungen, SCIM-Scoping | 2. qualifizierter Approver |
| **H2** Elevated-Approval | öffnet App tenant-weit; Admin Consent (delegated); Delegation/App-Group-Moves; SCIM-Mappings; Delete/Purge; kritische Config-Backend-Änderung; Custom Auth Extension | Security-/T0-Pool + Quorum |
| **H3** T0-Grant-Path | **übernahme-fähig**: Application-type Permissions, Deny-List, Directory-Rolle an SP, priv. Azure-RBAC an SP | T0-Pfad (ADR-008) |
**Regeln:** höchste Stufe gewinnt; Ambiguität → höher; Least Privilege = nur H0 stehend, Rest JIT/approved. **Hart kodiert (config-unabhängig):** die 4 Sicherheits-Invarianten; Deny-List nie über Self-Service-Flow. Subsumiert ADR-010/011/013; H3 = ADR-008.

### ADR-023 — Conditional Access (Domänengrenze) · ✅ DECIDED
CA-Authoring = **IAM-Team-Hoheit**. EAGP erhält **nie** `Policy.ReadWrite.ConditionalAccess` → **Deny-List (H3)**. EAGP ist **CA-aware (read-only)**: Reports „App ohne CA" + „welche CA greift"; **CA-Impact-Check bei H2-Aktionen** (Nebenwirkung sichtbar machen, z. B. `AssignmentRequired`-Wechsel als CA-relevant flaggen — nicht still aushebeln). Optional Phase 2: **CA-Request-Handoff** (Ticket an IAM), keine Ausführung.

### ADR-024 — B2B / Cross-Tenant Access · ✅ DECIDED (offen halten, inaktiv)
Derzeit nicht im Einsatz → **keine Bau-Welle**, kein Ausbau „auf Vorrat" (toter Pfad = Angriffsfläche). **Datenmodell offen halten** (Guest-Assignments, External-Identity-Bezüge) → spätere Aktivierung ohne Redesign. Falls aktiviert: Cross-Tenant-Settings-**Authoring = Domänengrenze** (IAM), EAGP read-only/report — analog ADR-023. 📥 *Falls B2B je in App-Owner-Hoheit fallen soll → andere Härte-Einstufung.*

### ADR-025 — SP-Privileged-Access · ✅ DECIDED
**Read/Report (MVP):** Entra-Directory-Rollen **und** Azure-RBAC-Rollen eines SP + kombinierter **Privileged-Access-Report** (Directory ∨ RBAC ∨ High-Priv-Graph-App-Permission). **Entra-Directory-Rollen:** Entziehen **und** Vergeben in EAGP möglich, aber **H3** (T0-Pfad); Vergabe Self-Service-ausgeschlossen. **Azure-RBAC:** **read/report + Handoff/Request** an Resource-Governance-Domäne; **kein Authoring** in EAGP (Machttrennung Platform/Workload). Der SP der **AWS-SSO-Anbindung** ist ein besonders kritisches Tier-M-Objekt (an ihm hängt der gesamte AWS-Zugriff).

### ADR-026 — DR & Fallback-Governance (right-sized) · ✅ DECIDED
Azure Portal bleibt **immer-verfügbarer Emergency-Fallback** (nur im Notfall ziehen) → DR right-sized statt gold-plated:
- **Service** (API/UI/Executor): Single-Region, **restore-based**, RTO **4–8 h** (Portal deckt Ausfall; kein Multi-Region-Active-Active — sprengt Kostenkorridor).
- **Daten-Durability streng:** Immutable Audit RPO **≈ 0, geo-redundant**; State/DB RPO **≤ 1 h (PITR)**. „Service darf stundenweise ausfallen, Daten nicht."
- **Post-Fallback-Reconciliation (MVP-kritisch):** Portal-Notfalländerung via `directoryAudits`/FR-45 erkennen → in Desired State adoptieren → WORM-Audit + Change-History mit `emergency-fallback`-Tag (kein Audit-Gap, kein Drift).
- **Emergency-Access-Governance (MVP-kritisch):** privilegierte Rollen für Portal-Write **PIM/JIT** (zeitgebunden, approval- + justification-pflichtig, auditiert) — nicht stehend.
- **Zugriffs-Verstärkung:** stehende Portal-App-Reg-Schreibrechte minimieren → EAGP = Pfad des geringsten Widerstands, Portal = bewusst reibungsvoller Notfallpfad. 📥 *Können stehende Portal-Schreibrechte reduziert werden?*
- **TISAX-Availability-Framing:** Nachweis = „Management-Fähigkeit durchgängig (Primär + Fallback) + Daten-Durability + Reconcile-Wirksamkeit", nicht „EAGP 99,99 %".

### ADR-027 — Security-Telemetry & Backup-Integrität · ✅ DECIDED (MVP)
- **Read-Access-Logging (MVP):** wer hat welche App-Config/Credential-*Metadaten* angesehen (Insider-Nachweis, ISO A.8.15/16).
- **Reveal-Anomalie-Alerting (MVP):** Volumen/Muster beim One-time-Secret-Reveal → Alert.
- **Backup-Integrität (MVP, Security-Blocker):** State/DB-Backups sind tenant-takeover-fähig → **immutable + verschlüsselt + Zugriffstrennung**; ein kompromittiertes Backup = kompromittierter Tenant.

### ADR-028 — Compliance-Standards & Audit-Evidenz-Engine · 🟡 RECOMMENDED (Scope → Management)
EAGP wird eine **kontinuierliche Kontroll-/Evidenz-Engine**: die auditierten Workflows erzeugen Nachweise als Nebenprodukt. **Default-Mapping-Ziele:** ISO/IEC 27001:2022 (Annex A), TISAX **VDA ISA 6.0** (inkl. neuem Prüfziel *Availability*), BSI **C5:2020**; NIS2-Awareness. 🔴 *Welche Standards EAGP verpflichtend evidenzieren muss → Management/Compliance.*
**Evidenz-Pakete (Core = MVP; Rest Phase 2):** Change-/Approval-Trail, Privileged-Access-Report, Credential-Rotation-Compliance → **MVP**; Access-Certification/Rezertifizierung, Compliance-Dashboard (% Baseline-Erfüllung), Third-Party/Consent-Register (Tier E), Exception-Register, Availability-/DR-Evidence → Phase 2. **Auditor-Read-Only-Rolle (MVP)**, scoped, selbst auditiert. **Prototype/Data-Klassifikation** als App-Attribut → 📥 *nur falls TISAX-Prototypenschutz/Datenschutz-Prüfziele euch betreffen.*

### ADR-029 — Credential Re-Reveal · ✅ DECIDED
Wiederholter Reveal aus dem Key Vault für **gültige, im KV liegende** Credentials (nicht mehr nur one-time). **Härte H2**: nur der DB-`owner` (+ Secondary), Step-up-MFA + Justification, TTL (~15 min), **jeder Reveal = WORM-Audit-Event** + Reveal-Anomalie-Alerting (ADR-027). **Kein** Re-Reveal bei Custody-/nur-Hash-Fällen (Cert-Klasse 2). Ersetzt die „one-time only"-Einschränkung von ADR-001. Owner-Bindung gilt für **delegierte** Rollen/Chatbot, **nicht** für EAGP-Admins (ADR-034).

### ADR-030 — Rotations-Führung (Source of Truth) · ✅ DECIDED
**Entra ist Source of Truth für Secret-Erzeugung:** Executor ruft Graph `addPassword` **an der App Registration** → Entra generiert, Klartext **einmal** zurück → **direkt in KV ablegen**. Der KV kann ein App-Reg-Secret **nicht** erzeugen und rüberschreiben. **Zertifikat (EAGP-managed, Cert-Klasse 1):** **KV erzeugt** (Private Key bleibt im KV/HSM), Entra bekommt via `addKey` nur den **Public Key**. **FIC bevorzugt** (secretless, kein Geheimnis). **Verboten:** generischer „KV-Auto-Rotation rotiert alle Secrets"-Mechanismus (scheitert bei App-Reg-Secrets). Merksatz: *Secret → Entra erzeugt/KV verwahrt; Cert → KV erzeugt/Entra bekommt Public Key; FIC → nichts davon.*

### ADR-031 — Credential-History & Zero-Downtime-Overlap · ✅ DECIDED
EAGP führt **aktive + historische** Credentials: Metadaten immer (`keyId`, Erstell-/Ablauf-/Entfern-Datum, wer, warum [Rotation/Emergency/Brownfield]); **Klartext nur** für aktive, im KV liegende. **Overlap ist Standard-Rotationspfad:** create-new → **beide gültig** → switch/verify → **retire-old (eigener H2-Schritt nach Verifikation)**. Altes, noch aktives Credential wird **nie automatisch** entfernt. **SAML-Signing-Rollover (Cert-Klasse 3)** erzwingt Overlap, damit SSO (z. B. AWS-Anbindung) nicht bricht.

### ADR-032 — EAGP-API & Chatbot-Zugriff · ✅ DECIDED
Private, Entra-authentifizierte **EAGP-API** (kein Graph-Write, wie die UI). **Chatbot via On-Behalf-Of** (echte Nutzeridentität, nie App-only-„für-alle"). **AuthZ gegen DB-`owner`** (explizit **nicht** `ownedBy`) + Secondary. Low-Sensitive (App-ID/Metadaten) direkt; **Secret-Klartext nur über H2-Reveal** (ADR-029), **nicht** als bequeme Chat-Antwort. **Serverseitige AuthZ** (prompt-injection-resistent — Autorisierung nie im Prompt/Bot), Rate-Limiting, **keine tenant-weite Sicht** (Owner sieht nur eigene Apps). **Kill-Switch/Feature-Flags über Config Backend:** Master-Kill + granulare Flags (Metadaten-Pfad ≠ Secret-Pfad, unabhängig abschaltbar), **fail-safe** (unerreichbar/aus → verweigern), serverseitig, **laufzeit-wirksam ohne Deployment**; **Bot-Secret-Re-Reveal Default AUS**.

### ADR-033 — Configuration Backend als Tier-0-Kontrollpunkt · ✅ DECIDED (MVP-relevant)
Config Backend (FR-70) ist **so mächtig wie die Aktionen, die es steuert** → Tier-0-Schutz. **Config-as-Code** (versioniert/reviewt/diff-bar/rückrollbar), **nicht** mutable DB-Zeile. Änderungen selbst **H1–H3 nach Domäne** + **Selbst-Referenz-Sperre** (Approval-Regeln nicht über sich selbst absenkbar). **Hart kodierte Untergrenzen (nicht konfigurierbar, auch nicht mit Approval):** die 4 Sicherheits-Invarianten + „Deny-List nie via Self-Service". **Fail-safe Defaults** (fehlt/unerreichbar → restriktivste Auslegung). **Zugriff strikt getrennt** (nur Admins/T0; App-Group-Admins nie; Config-Read selbst auditiert). Domänen+Schutzklasse: Security-kritisch (Approval/Härte/Deny-List)=H3+Self-Ref-Sperre · Zugriff/Exposition (Chatbot-Kill/API/stehende-Rechte)=H2 · Compliance/Daten (Retention/Mappings/Log-Level)=H2 · Operativ (Notification/Schedules/Cert-Vorlauf)=H1. **Laufzeit-Flag-Store** für sofort wirksame Kill-Switches; Autorisierung der Flag-Änderung dennoch über EAGP-Approval (kein „jeder mit Portal-Zugriff kippt das Flag").

### ADR-034 — EAGP-Plattform-Admin-Rolle · ✅ DECIDED
Euer Team (EAGP-Admins/Hauptuser) hat **stehenden Voll-Lese- und Schreibzugriff** über den gesamten App-/SP-/Credential-Bestand **aller Tiers**; **Owner-Bindung gilt NICHT für Admins** (nur delegierte App-Group-Admins + Chatbot). H2-Aktionen (Re-Reveal, tenant-weite Öffnung) sind für Admins **ausführbar** — H2 bedeutet **Audit + Anomalie-Alert, keine Zugriffssperre**. **H3-Klasse** (tenant-übernahme-fähig) auch für Admins über den **T0-Pfad** (PIM/JIT + Approval, ADR-008) — stehend minimal. **Ausnahme für alle, auch Admins:** die 4 Invarianten + Deny-List-Self-Service-Verbot nicht umgehbar (ADR-033). Prinzip: Least Privilege = stehende Rechte minimal + Elevation nachvollziehbar → schützt das Team selbst vor Account-Kompromittierung (kein Single Point of Total Compromise).

### ADR-035 — Klartext-Geheimnis-Hygiene · ✅ DECIDED
Klartext-Secrets werden **niemals persistiert** (Disk/State/DB/Queue/Log/Trace/Error/Telemetrie) und **niemals im Klartext übertragen** (nur TLS; nie in URL/Query-Parametern). **Zertifikate:** Private Key **entsteht im KV und verlässt ihn nie** (EAGP hinterlegt nur Public Key). **Client Secrets:** Entra erzeugt (unvermeidbar), Klartext existiert **nur flüchtig im Executor-Speicher** → **direkt in KV** → Speicher verworfen; das unvermeidbare In-Memory-Fenster wird minimiert/gehärtet, nicht ignoriert. **Rangfolge (Default erzwungen): FIC > Zertifikat > Client Secret.** **Re-Reveal:** direkt KV → Aufrufer, flüchtig, No-Store-Header, TTL, kein Zwischenspeicher/Log. Erzwungen durch: Log- & Exception-Scrubbing + CI-Secret-Scan, TLS-only, Private Endpoints, HSM-backed KV, **Terraform-Secret-Verbot (`azuread_application_password`)**, Memory-Hygiene, No-Store-Reveal. Verschärft SEC-02.

---

### ADR-036 — Admin & Configuration Console · ✅ DECIDED
Baut ADR-033 aus. **UI over Config-as-Code** (GitOps mit UI — keine Konsolen-/Flatfile-Edits; jede UI-Änderung wird zu versioniertem, reviewtem, rückrollbarem Config, nicht mutable DB-Zeile). **Toggles schalten Features, niemals Controls** — elementar & nicht abschaltbar (in UI „locked by policy"): WORM-Audit, 4 Invarianten, AuthZ/Owner-Bindung, Deny-List-Enforcement, Fail-safe-Defaults, Kill-Switch-Mechanismus selbst. **Config-Domänen + Schutzklasse:** Approval/Governance inkl. **Vertretung-bei-Abwesenheit** (H3+Self-Ref-Sperre) · Härte-/Risk-Kalibrierung + Deny-List-Pflege (H3+Self-Ref) · Credential-Policy (H2) · Reports & Delivery (H1/H2) · Notifications/Alerting (H1–H2) · Feature-Flags/Kill-Switches (H2, laufzeit-wirksam) · Integrationen (H2) · Retention nur **oberhalb Legal-Floor** (H2) · operative Parameter (H1–H2) · Compliance-Mappings (H2). **Report-Delivery 4 Modi:** Dashboard-only / On-Demand / Scheduled-Push (Frequenz+Timezone+Empfänger) / Event-Triggered — + RBAC je Report + Point-in-Time-Snapshots (Audit-Evidenz) + Self-Service-Subscriptions im Scope. **Two-Tier Config Plane:** Config-as-Code Store (deklarativ, PR-gated) + Runtime-Flag-Store für sofort wirksame Kill-Switches (Kandidat Azure App Configuration; Flag-Änderung dennoch über EAGP-Approval). Zugriff: nur Admins/T0, MFA, private-first, Config-Read selbst auditiert. **Anti-Pattern:** direkt editierbare Settings-Tabelle, die Sicherheitsregeln live ändert.

### ADR-037 — Backup & Restore · ✅ DECIDED
Konkretisiert ADR-026/027. **Data-Durability nach Datenklasse** (Compute aus IaC reproduzierbar): Config-as-Code (Git+Blob-Versioning) · **Operational DB (PITR + täglicher Full-Snapshot)** · Audit/WORM (append-only, geo-redundant) · Key Vault (Soft-Delete + Purge Protection + KV-Backup, verschlüsselt) · Runtime-Flag-Store (mit DB-Snapshot). **Drei Tier-0-Kontrollen (verifiziert, MS Learn 2026):** **Immutable Vault** (Enabled+Locked → WORM, irreversibel, kein Override; GA seit März 2023, alle Regionen für RSV; WORM-Storage für germanywestcentral via Auto-Transition oder Immutable-Kopie in **Germany North**) · **Soft Delete** (14–180 Tage) · **Multi-User Authorization / Resource Guard** (anderer Owner/Subscription → kompromittiertes EAGP-Admin-Konto kann Backups nicht löschen = Access-Trennung ADR-027). **Daily-Default + PITR, Config-Backend-steuerbar (H2); hart kodierte Floors** (Backup = Control, nicht abschaltbar): Mindest-Retention, Immutability+Lock, Encryption, MUA, Geo-Redundanz Audit. **Restore-Pfad** (IaC-Deploy → DB PITR/Snapshot → Config einspielen → Post-Fallback-Reconciliation) + **automatisierte Restore-Drills**. EU-Residency (germanywestcentral primär); **keine Klartext-Secrets in Backups** (ADR-035). **Anti-Pattern:** Backup mit App-Identität/Storage (Ransomware löscht beides); Retention falsch/zu lang locken (irreversibel).

### ADR-038 — Deployment-Pattern (data-driven Module + State je App) · ✅ DECIDED
Bestätigt ADR-004/005/007/010/035. **Ein gehärtetes, generalisiertes Module + Parameter-Datensatz je App** — das Tool schreibt **Daten** (validierte `tfvars.json`) + **State-Key als Init-Parameter**, **nie per-App-HCL**. Module + Root-Template werden 1× geschrieben/gehärtet. **State je App** (backend-key `apps/<appId>.tfstate`) → minimaler Blast Radius, Parallelität. Provider `hashicorp/azuread` v3.x (`azuread_application` monolithisch + `azuread_service_principal` + FIC via `azuread_application_federated_identity_credential`). **Secrets-Split:** App/SP/App-Roles/Redirect-URIs/`required_resource_access`/Optional Claims = **Terraform**; **FIC = Terraform** (secretless; `Application.ReadWrite.OwnedBy` genügt wenn SP Owner); **Client Secret NIE Terraform** (`azuread_application_password` verboten → Wert im State) → Graph `addPassword`→KV; **Certificate** = KV-native + Graph `addKey`; **High-Priv Grants** = gegateter PIM-Pfad, kein stiller TF-Apply. **State-Backend:** azurerm, Private Endpoint, Versioning+Soft-Delete+**Immutable/Locked** (koppelt ADR-037), Blob-Lease-Lock, keine Klartext-Secrets. **Drift** = `terraform plan`; **Brownfield** = tfvars + `import`-Block (ADR-012). **Executor-Auth** = WIF/OIDC. **planHash-Bindung:** `plan -out=tfplan` → Approval → `apply tfplan` (kein Re-Plan). **Anti-Pattern:** Monolith-ein-State; Tool erzeugt HCL (Codegen-Sprawl); Secret in TF; Hand-Edits an Tool-Daten.

### ADR-039 — Business Application Registry & Identity-Mapping + CMDB-Federation · ✅ DECIDED
Erweitert ADR-014/017, nutzt ADR-034. **Business Application = First-Class-Entity** mit pluggable System of Record; **EAGP-native ist im Betrieb führend** (kein MVP-Blocker). **1:n-Mapping** Business App ↔ App Identities mit **Funktion an der Beziehung** (SSO/SCIM/Automation/API/Integration) + Environment; m:n nur mit Begründung+Multi-Owner. **Zwei-Ebenen-Ownership:** Business-App-Owner (Service-Owner, **als Entra-Gruppe** + Deputy) + per-Identity `db_owner` (technisch, steuert Reveal, ADR-029/034). **CMDB-Federation = optional, zuschaltbar, DEFENSIV** (Qualität unbekannt/lückenhaft angenommen): **ServiceNow führend/bindend, EAGP schreibt NIE zurück** (read-only, `cmdb_read`, OAuth, IP-Allowlist, kein Private Link → kompensiert; Table API `cmdb_ci_business_app` + CMDB Instance API für Relationships, `sysparm_display_value=true`). **Provenance je Record** (`eagp-native` / `match-proposed` / `cmdb-linked` / `cmdb-sourced`). **Feld-Ownership:** gematchte Records → ServiceNow überschreibt die dort **gefüllten** Stammdaten (**kein Blank-Overwrite**); Identity-Mapping/Funktion/technischer Owner = **immer EAGP**. **Nichts auto-linken** (hohe Confidence-Schwelle → Vorschlag → Mensch bestätigt; Auto-Link nur über Schwelle, konfigurierbar). **Primärnutzen bei schlechter CMDB = Coverage-Gap-Reporting** (Identitäten ohne CI / CIs ohne Identitäten) → EAGP als Qualitäts-Spiegel. Sync scharf erst **Phase 3** (ADR-017). **Anti-Pattern:** bidirektional/EAGP schreibt CMDB; CMDB blind als alleinige Quelle; Fuzzy-Auto-Overwrite; keine Provenance; N+1-Referenzauflösung.

### ADR-040 — Drift Control & Reconciliation · ✅ DECIDED
Formalisiert ADR-026/027. **Duale Detektion, korreliert:** State-Diff (`terraform plan`, autoritatives **Was**) + Event-Log (Entra `directoryAudits`, täglich, **Wer/Wann/Wie**, fängt „geändert-und-zurück"). **Severity via Change-Klassifikator (ADR-022)** → Default-Aktion. **Zwei Wege:** **A) Revert** (Soll re-applyen; Approval = Härte des Revert-Diffs; Fast-Path bei Security-Containment) · **B) Adopt** (Ist als neues Soll in Config-as-Code, PR-gated ADR-038; **Justification: Ticket OPTIONAL + Grund PFLICHT**; Approval = Härte der übernommenen Änderung) · Acknowledge (temporär). **Adopt-Laundering-Guardrails (hart):** Adopt erbt Härte; **Deny-List nie adoptierbar**; **kein Selbst-Adopt** (4-Augen bei Security-Drift); volle Provenance (Verursacher aus `directoryAudits` + Adoptierer) im WORM-Audit. **Emergency-Fallback-Routing:** Drift mit `emergency-fallback`-Tag = erwartet → Richtung Adopt (kein Alarm); Queue trennt erwartet/unerwartet. **Auto-Revert konservativ:** Default detect+alert+Queue, **nie Auto-Adopt**; enge Allowlist nur eindeutig (z. B. `appRoleAssignmentRequired=true`); Security-kritisch → eher **Auto-Contain** (Disable). Latenz nicht Echtzeit; NRT-Enhancement = Audit-Streaming/SIEM + Graph Change Notifications (falls unterstützt — beim Bau verifizieren). Drift-Board je App **und Business App**, Recurring-Eskalation, Change-Mgmt-Trail. **Anti-Pattern:** alles auto-reverten; Adopt ohne Change-Mgmt (Laundering); Drift ohne Attribution; flache Queue; Recurring ignorieren; Verursacher adoptiert selbst.

### ADR-041 — Target-System Entitlement Management & Verification · ✅ DECIDED
Upgradet ADR-025 (von read/report+Handoff → **Manage+Verify**). **Identity- → Authorization-Plane.** **Capability-Tiers:** Manage = **Azure RBAC (Schritt 1)** + Graph-App-Perms + Key Vault; Verify+Declare = Power BI (Admin REST API), SharePoint (Graph **`Sites.Selected`**); Declare-only = Fallback. **Verification-first** (real gegen API, kein Textfeld). **Azure RBAC verify:** Azure Resource Graph `AuthorizationResources` (roleAssignments join roleDefinitions, `principalType == ServicePrincipal`, `AuthorizationScopeFilter`; zeigt **aktive**, nicht PIM-**eligible** → PIM-Eligibility-APIs zusätzlich). **Assign:** ARM `Microsoft.Authorization/roleAssignments` (braucht User Access Administrator/Owner → gegatet). **Write-Korridor = at-and-below der Governance-MG unter Root, NIE auf `/`** (exakte MG-ID = Environment-Fakt). EAGP führt selbst aus, über **eigenen, eng gebounded RBAC-Executor** (ADR-042). **Guardrails (ADR-022):** Reader H1 · Contributor H2 · Owner/UAA H3+Security · **Owner/UAA auf MG-/Sub-Root = Deny-List**; Least-Privilege + engster Scope + **time-bound bevorzugt** (SP nicht eligible-fähig → time-limited active). **Connector-Architektur** (pluggable, normalisiertes Entitlement-Modell). **Intent-vs-Actual-Reports:** Over-Privileged/Undeklariert/Fehlt/Standing-High-Priv/Expiring/Orphaned/Scope-zu-breit; **Rollup je Business App** (ADR-039). Kontext: LZ-Terraform-SP vergibt bereits breit RBAC (etabliert); EAGPs Executor ist das Least-Privilege-Gegenmodell (LZ-SP selbst = Tier-M-Objekt für Verifikation). **Anti-Pattern:** Textfeld-only; breite Standing-Rollen; Owner/UAA an SP; keine Re-Verifikation; alles managen (IGA-Sprawl); PIM-eligible ignorieren; unbounded Write-Scope für EAGPs Identität.

### ADR-042 — Executor Decomposition / Separation of Powers · ✅ DECIDED
Verfeinert ADR-007, verstärkt ADR-008, komplettiert ADR-041. **Mehrere Least-Privilege-Executors statt eines Super-SP** (Dogfooding: kein Single Point of Total Compromise). **Zerlegung nach Plane (Read vs. Write) + Capability-Domäne + Sensitivität**, gemappt auf Härte-Tiers. **Referenz-Set (~5):** Verifier (Graph-Read + ARG-Reader + read-only extern; **breit+stehend, low risk**) · Lifecycle (`Application.ReadWrite.OwnedBy`, H0–H1) · Credential (KV + Graph auf owned; KV **nur hier**; H1–H2) · Azure-RBAC (ARM roleAssignments, **bounded auf Korridor**, H2–H3) · High-Priv Grant (**nichts stehend**, time-boxed via PIM, H3). **Read breit+stehend / Write eng+gated.** **Isolation je Executor:** eigene App Reg + eigene FIC (secretless) + eigene **CA for Workload Identities** (IP-Lock; MI ausgeschlossen → App Reg + FIC + **NAT-Egress-IP**) + eigene Anomaly-Baseline; KV-Zugriffstrennung. **Orchestrator hält KEINE Resource-Permissions** (routet nur; kompromittierter Orchestrator kann High-Priv nicht missbrauchen — Gating out-of-band, planHash, ADR-008). **Runtime = Azure Container Apps (Jobs), kein AKS:** die zwei Tier-0-Write-Executors in **separater, gehärteter Environment + ephemerem Job** (Token nur während des Jobs, High-Priv nur im PIM-Fenster); Read/Lifecycle/Credential teilen sich einen gehärteten Runner. **Graph kein Private Link** → CA-IP-Lock+CAE+ID-Protection kompensieren; KV/Storage/DB/ARM via **Private Endpoints**. Alles IaC (ADR-038). Build-Runtime (Claude Code) bleibt isolierter Container ohne Prod-Pfad (ADR-018). **Anti-Pattern:** ein Super-SP; Über-Fragmentierung; Orchestrator wird Monolith; geteilte Runtime (1 Kompromittierung = alle Tokens); breiter Standing-Write.

---

### ADR-005 (revidiert) — Tech-Stack: Terraform + Python (einsprachige App) · ✅ DECIDED
Revidiert die ursprüngliche 3-Sprachen-Wahl. **Terraform + Python; PowerShell NICHT in der Runtime.** Deklaratives Provisioning = Terraform (`azuread`/`azurerm`); die gesamte Anwendung **und** die imperativen Graph-/Credential-/Verifikations-Ops = Python (FastAPI, `msgraph-sdk` [GA], Azure-SDK, `azure-identity` mit `WorkloadIdentityCredential` für secretless FIC). Frontend = TypeScript/React. Begründung: msgraph-sdk-Python (GA, async, „Pythonic-Äquivalent zum PowerShell-SDK") deckt die Entra-/Graph-Ops ab; Graph ist REST → alles Unabgedeckte per Direktaufruf aus Python. Vorteil: **einsprachige App** = kleinere, auditierbare Tier-0-Codebasis, ein Testframework (pytest), ein Container-Baseimage, keine Prozessgrenze/Shell-out. **Welle-0-Spike** validiert die kritischen Ops (addPassword/addKey, Admin-Consent, PIM-Schedule, directoryAudits-/Resource-Graph-Query) gegen msgraph-sdk vor dem Commit; Lücken → dünner Direct-REST-Wrapper, nicht PowerShell zurück in die Runtime. PowerShell nur optionales Standalone-Assessment. **Verworfen:** PowerShell als zweite Runtime-Säule (Dual-Runtime-Nachteil); Terraform-only (kann keine App hosten); .NET.

### ADR-043 — CI/CD & Multi-Tenant-Promotion (Azure DevOps) · ✅ DECIDED
**CI/CD-Plattform = Azure DevOps Pipelines**, secretless via **Workload Identity Federation** (GA; Microsoft-Entra-Issuer; je Tenant eine Service Connection, unterstützt externe-Tenant-Auth). **„Umgebung" = eigener Entra-Tenant:** deploy/test zuerst gegen einen separaten **Dev-Tenant**, dann **Prod-Tenant** (nicht nur separate Subscriptions — EAGP verändert das Directory). Zwei Ebenen: Pipeline **deployt EAGP** (App + Executors via IaC) Dev→Prod; EAGP-Runtime (ACA Jobs) führt die Governance-Ops aus. **Test-Pyramide:** Unit (viele, gemockt) · Contract · Policy (`tfsec`/`checkov`/`conftest`: Deny-List-Gate, keine Secrets im State, `prevent_destroy`) · Security (SAST/SCA/Secret-/Container-Scan) · echte **Integration im Dev-Tenant** · E2E-Smoke · manuelle Freigabe (Environments + Approvals) → Prod. **State/Identität je Environment** getrennt (ADR-038). **Parität-Handling:** Dev ≠ Prod-Config ist real → **Capability-/Parität-Detection**; parität-abhängige Tests (PIM, CA-for-WI, App-Mgmt-Policy) nur wenn Dev die Config hat, sonst **Prod-Canary** (report-only, enger Scope, Ring-Rollout) statt False-Green; parität-kritische Dev-Config per IaC; **Pre-Flight-Readiness-Check** vor jeder Op. **Netzwerk:** private Ressourcen → **Self-hosted Agents / Managed DevOps Pool mit VNet-Injection** (Microsoft-hosted erreichen keine Private Endpoints). **Lizenz/FinOps:** **P2 per-User** nur Approver-Pool (PIM) + **Workload ID Premium per-SP** nur Executor-SPs (CA-for-WI; separater SKU, nicht in E5/Suite; MI ausgeschlossen) — **nicht tenant-weit**; Dev via 90-Tage-Trials; EAGP FinOps-aware, **reportet CA-Coverage** → High-Risk-Targeting. Bestätigt ADR-007/018/038/042; ergänzt ADR-005. **Anti-Pattern:** gegen Prod testen (kein Dev-Tenant); Secret-Service-Connections; geteilter State/Identität Dev↔Prod; apply ohne Plan-Gate; Dev==Prod annehmen (False-Green); tenant-weit P2/WI-Premium.

---

## Teil C — 🔴 Offen für Management (siehe `MANAGEMENT_DECISIONS.md`)
1. **ADR-008 Executor-Modell (revised)** — **gehärtetes Weg B (B-timeboxed)** als Zielzustand freigeben (Executor führt aus, kein stehendes Tier-0; Grant-Privileg JIT time-boxed via Team-PIM-Aktivierung). Tiered Approval: H2 = Team-Quorum, H3 = Team-Quorum + Security. Security-Rolle = Guardrails + Audit-Oversight, nicht Per-Transaction. Fallback: „Weg A mit Team-Pool".
2. **ADR-018 Loop-Detail-Calls** — Autonomiegrad, Merge-Gate, Ausführungsort (teils Environment).
3. **Approver-Pool-Besetzung + Quorum-Defaults** (ADR-011) — wer ist qualifizierter T0-Approver?
4. **Compliance-Scope** (ADR-028) — welche Standards sind verpflichtend?
5. **Betriebsrat-Beteiligung + Art.-30-Verzeichnis-Eintrag** (Business-Owner-PII, Read-Access-Logs).
6. **Pentest-Ressource** (intern/extern) — Release-Gate vor Go-Live.

## Teil D — 📥 Offen: Fakten, die nur das Environment liefert
Führe **`eagp-assessment.ps1`** (Global Reader, read-only) aus → deckt (a)+(c)+(d) direkt ab:
- (a) **Lizenzen**: Entra ID P2? Defender for Cloud Apps App Governance?
- (b) **Power-Platform-Governance**: Managed Environments, DLP, Tenant Isolation — Stand nach Challenge beim PP-Team?
- (c) **App-Management-Policy-Stand**: `GET /policies/appManagementPolicies` (Default = „keine Restriktion" = Risiko).
- (d) **Agent-ID-Enablement**: Copilot Studio pro Environment / Agent Registry.
- (e) **`ownerBusinessId`**: Attributname + Typ (Directory-Extension vs. Custom Security Attribute)?
- (f) **Konditionale Surfaces genutzt?** App Proxy · RemoteDesktop · Native Auth · Custom Auth Extensions (steuert nur Bau-Welle).
- (g) **VPS/Runtime**: erledigt → **Azure Container Apps (Jobs)** (ADR-042); Build-Runtime = isolierter Container (ADR-018).
- (h) **Chatbot-OBO**: ✅ als Annahme gesetzt → **neue App Registration mit On-Behalf-Of** einrichten (ADR-032).
- (i) **Owner-Scope der API/Reveal**: nur Primary-Owner oder auch Secondary/Deputy? (ADR-029/032/034) — kleiner offener Punkt.
- (j) **Exakte Governance-MG-ID** unter Root für den Azure-RBAC-Write-Korridor (at-and-below, nie `/`, ADR-041).
- (k) **Feste Egress-IP / NAT Gateway** je Executor-Runtime für den CA-IP-Lock (MI ist von CA ausgeschlossen → App Reg + FIC + fester Egress, ADR-042).
- (l) **P2 im Dev-Tenant?** verfügbar/aktivierbar — sonst laufen PIM-/CA-for-WI-Tests als Prod-Canary (ADR-043).

**Nun als Annahme gesetzt (bestätigen, kein Blocker):**
- **DB-Engine** = Azure Database for **PostgreSQL Flexible Server** (PITR, Immutable-Backup, Private Endpoint) — ADR-037/038.
- **Ticketing/Change-Mgmt** = **manuelle Ticket-/Change-Nummer** als Feld **+ optionale API**; **keine** Live-ServiceNow-ITSM-Verdrahtung im MVP; **Begründung Pflicht** — ADR-013/040.
- **Runtime** = Azure Container Apps (Jobs) — ADR-042.
- **CI/CD** = Azure DevOps Pipelines, secretless WIF, Dev-Tenant → Prod-Tenant — ADR-043.
- **Lizenzmodell** = P2 per-User (Approver-Pool) + Workload ID Premium per-SP (Executors), **nicht tenant-weit**; Dev via Trials — ADR-043.
- **Approver-Pool** = euer Team (PIM-eligible + Quorum) — Management-Bestätigung offen (M2).

## Teil E — ⏸️ Deferred (Bau-Welle, nicht blockierend)
SCIM-Mapping-Editor-Reihenfolge · Decommissioning-Workflow (disable→soak→delete→purge, H2) · Bulk-Operationen (Härte je Aktion) · Git-Mirror der TF-Config · ITSM/ServiceNow-CMDB (Phase 3) · Custom Security Attributes / Custom Auth Extensions (Phase 2). Alle governt durch ADR-021 (im Produkt) + ADR-022 (Härte); gelistet in `FEATURE_PARITY.md`.
