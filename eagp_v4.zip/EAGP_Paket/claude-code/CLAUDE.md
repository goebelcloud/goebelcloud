# CLAUDE.md — EAGP Project Context & Handoff

> **Read this first, in full, before writing any code.** This file is the seamless
> handoff from the architecture/design phase. It captures the decisions, the model, the
> guardrails, and where we are. The exhaustive spec is `SPEC.md`; the phasing is
> `ROADMAP.md`. When those conflict with this file, `SPEC.md` wins on detail, this file
> wins on "what matters most".

---

## 1. What EAGP is

**Entra App Governance Platform (EAGP)** — an internal, enterprise-grade, GDPR-compliant
platform to **govern all app identities in the Microsoft Entra tenant**: App Registrations
and Enterprise Applications (Service Principals). Lifecycle, permissions, credentials,
SSO/SAML/OIDC, delegation, reporting, drift & out-of-band detection — through an audited,
approval-gated workflow.

**Reframe (important):** EAGP is **not** an "app lifecycle manager". It is a
**governance platform with a managed subset**. Most app identities in the tenant are
*not* ours to lifecycle — they are governed, not managed (see the Tier model in §4).

## 2. Non-negotiable constraints (Tier-0)

EAGP is a **Tier-0 system**: its executing identity can potentially take over the tenant.
Design for *containment*, not features. These are hard rules:

- **Identity separation.** The web/API layer holds **zero** Graph write permissions. Only
  a segregated **Executor** mutates Entra. If the UI/API is compromised, the tenant stays
  safe.
- **Secretless Executor.** App Registration + **Workload Identity Federation** — no stored
  secret exists. Hardened with Conditional Access for Workload Identities.
- **Secrets never in Terraform state, plan, logs, telemetry, DB, or queue.** Secrets are
  created via **direct Graph call** (`addPassword`) and written straight to Key Vault;
  only the `keyId`/metadata is persisted. **Never** via the Terraform `azuread` provider
  (it persists the value in state).
- **Four security invariants** (unit-tested, not negotiable): (1) deny-list permission is
  never grantable via the delegated app-group flow; (2) approver ≠ requester, always;
  (3) `planHash` ≠ executed action → always rejected; (4) an app-group admin can never
  touch an app outside their group.
- **Private-first.** All data-plane services behind Private Endpoints; access only
  internal via Zscaler ZPA + Entra SSO with MFA. Nothing public.
- **Immutable audit** (WORM append blobs) separate from operational logs.

## 3. Tech stack (DECIDED, revised — ADR-005 revised)

Final stack: **Terraform + Python** for the application. **PowerShell is NOT part of the
runtime.** The msgraph Python SDK (GA) covers the Graph/credential/verification operations, so
the app stays **single-language** — a smaller, auditable Tier-0 codebase, one test framework,
one container base image, no cross-process shell-out.

| Component | Language / Tool | Notes |
|---|---|---|
| Declarative provisioning (Entra app/SP/FIC, Azure RBAC) | **Terraform** (`azuread`/`azurerm`, pinned) | one state file per app; drift-detectable |
| App + imperative Graph / credential / verification ops | **Python** (FastAPI, `msgraph-sdk`, Azure SDK, `azure-identity`) | Container Apps; `WorkloadIdentityCredential` for secretless FIC |
| Internal admin console | **TypeScript / React** | internal-only + Zscaler (ADR-006) |
| Assessment / ops runbooks | **Python** (PowerShell variant optional, standalone — not runtime) | |

**HARD RULES:** Never emit legacy **AzureAD / MSOnline** code (retired) — Graph via `msgraph-sdk`
or direct Graph REST. **No .NET. No PowerShell in the runtime.** Client Secrets never via
Terraform (`azuread_application_password` forbidden) → Graph `addPassword` → Key Vault (ADR-035).
A Welle-0 spike validates the critical Graph ops against `msgraph-sdk` before committing.

## 4. The App Tier Taxonomy (core model)

Everything hinges on the Entra object model: **App Registration** (the definition, lives
in the home tenant) vs. **Service Principal** (the local instance in our tenant).

| Tier | Examples | App Reg in our tenant? | EAGP role | Primary controls |
|---|---|---|---|---|
| **M — Managed** | our own line-of-business apps | yes | **Full lifecycle** (CRUD, credentials, permissions via Terraform) | Terraform, approval, WORM audit |
| **A — Agent** | Copilot Studio / Foundry AI agents | via Agent Identity (SP subtype) | **Govern** via **Entra Agent ID** + ID Governance | Blueprints, sponsors, access packages, access reviews, blueprint-level CA |
| **P — Platform-created** | Power Platform connectors, D365 app users, Power BI SPs, other automation NHIs | partly (first-party SP / app reg) | **Govern** (discover, attribute owner, guardrail, recertify) — **no lifecycle** | App Management Policies, Power Platform managed environments/DLP, access reviews |
| **E — External / Consented** | marketplace / multi-tenant SaaS, gallery apps | **no** (SP only; definition owned by vendor) | **Govern** (consent, access, OAuth risk) — **no lifecycle** | Consent policies, publisher verification, Defender for Cloud Apps App Governance, CA |

**Consequences for code:**
- Only **Tier M** goes through the Terraform executor lifecycle.
- Tiers A/P/E are **discover + classify + attribute owner + guardrail + report + route
  high-risk to approval** — never lifecycle-managed. Do not try to Terraform-import
  platform/agent-created objects; you will fight the platform and it breaks on recreation.
- **Entra Agent ID** (GA April 2026) is the identity plane for Tier A — EAGP orchestrates
  and reports on top; it does not reinvent agent identity.
- **App Management Policies** (Entra ID Free; `applicationRestrictions` vs.
  `servicePrincipalRestrictions`) are the highest-leverage preventive guardrail for
  credential sprawl across Tiers P/E. Caveats: block only *new* create/update ops
  (existing creds keep working); cert-lifetime restriction also affects SAML signing certs.
- **Consent Approval Center** is the governance surface for Tier E (marketplace/SaaS).

## 5. Architecture (summary)

Fully **PaaS / serverless**, private-first, region `germanywestcentral`.

- **Frontend** (React admin console) → **Management API (Python/FastAPI, low-priv, Graph read-only)** →
  **Service Bus (session per app)** → **Executors (~5, least-privilege; Container Apps Jobs, App Reg +
  FIC)** → **Microsoft Graph**.
- **Metadata** in PostgreSQL Flexible Server (Entra-only auth). **TF-state** per app in Storage
  (Entra-only, shared-key disabled). **Secrets/certs** in Key Vault (RBAC, purge
  protection, PE). **Immutable audit** in append blobs.
- **Logging split-sink** (ADR-015): security/audit signals → central CDOC/**Sentinel**
  workspace; operational/diagnostic logs → cheap dedicated workspace or **Basic Logs**,
  short retention; immutable audit → WORM storage (separate). Never dump operational logs
  into a Sentinel workspace — Sentinel bills on all ingested data.

## 6. Repository layout (target)

```
/api               Management API (Python / FastAPI)
/executor          Terraform runner + Graph/credential ops (container; Python)
/modules/          Terraform module: entra-application (Tier M)
/platform-iac      Terraform for the platform itself (networking, identities, data)
/scripts           Python: discovery, classification, recert, assessment (optional standalone PowerShell)
/policies          App Management Policy definitions, consent policies, config-as-code
/frontend          React/TypeScript admin console (internal + Zscaler)
/docs              docs-as-code, ADRs, diagrams
CLAUDE.md          this file
SPEC.md            full specification
ROADMAP.md         phasing
```

## 7. Guardrails for code generation (hard rules)

- Never invent Graph endpoints or Terraform attributes — verify against docs; if unsure,
  stub and mark `// VERIFY`.
- Never log request/response bodies that may contain credentials.
- Never widen an identity's permissions "to make it work" — fail loudly instead.
- Identity only via `azure-identity` / `msgraph-sdk` (Python); never hand-roll token
  validation / claims parsing.
- All Azure resource names via a naming module; enforce mandatory tags (Owner,
  Criticality, Environment, Cost Center).
- Every privileged code path emits an audit event; missing audit = bug.
- Changes to identities / data flows / permissions require an ADR reference.
- Comments explain **intent/constraints** ("why"), never restate the code.
- Dev-tenant isolation guard: the executor verifies target tenant = dev tenant in test
  contexts.
- **No .NET. No legacy AzureAD/MSOnline. No PowerShell in the runtime — the app is Python-only (ADR-005 revised).**

## 8. Build order

1. Repo scaffold + this `CLAUDE.md` (guardrails as hard rules).
2. **Harness first**: CI gates (SAST/SCA/IaC/secret-scan/doc-drift), synthetic brownfield
   fixtures, policy-engine test suite (the 4 invariants), dev-tenant isolation guard.
   **Before any feature.**
3. Platform-IaC skeleton (networking, identities, PostgreSQL, Storage, KV, Service Bus, ACA) —
   plan-only until review.
4. Data model + migrations (apps, app_groups, delegations, approvals, runs,
   drift_findings, audit_refs, owners, change_records, permission_requests, config,
   **app_tier**, **agent_refs**).
5. AuthN/AuthZ + policy engine (the 4 invariants) — **unit tests first**.
6. Terraform module + Executor job (happy path: create Tier-M app from template).
7. Approval workflow + Consent Approval Center + audit pipeline.
8. Credentials (FIC / cert / secret; Key Vault; expiry monitoring; rotation).
9. Drift + out-of-band + emergency-revoke (kill-switch).
10. **Tier governance**: discovery/classification (M/A/P/E), owner attribution, App
    Management Policy management, Agent ID integration, Tier-E consent/risk reporting.
11. Brownfield import (Tier M) + reporting breadth + notifications + Configuration Backend.

> **ADR-008 (Executor model for high-priv grants) needs Security sign-off before steps 6/7**
> — it sets the executor permission model and the Consent Center execution path.

## 9. Open decisions & pending inputs

**Needs Security sign-off (not blocking the POC):**
- **ADR-008 (revised) — Executor model for high-privilege grants.** No longer binary A/B. The
  axis is *where standing tenant-takeover privilege lives* + the verified fact that a service
  principal **cannot be PIM-eligible** (no machine self-JIT), only standing-active or
  time-limited-active. **Recommended target: hardened Weg B (B-timeboxed)** — executor holds
  **no standing Tier-0**; for the rare high-priv grant, a **team-quorum approval** triggers a
  team member's **PIM activation** which grants the executor SP a **time-boxed active**
  assignment (auto-expiry), then it executes and reverts. Executor hardening: FIC (secretless)
  + CA for Workload Identities (IP-lock) + ID Protection/CAE. **Tiered approval:** H2 = team
  quorum (2); H3 (tenant-takeover-capable) = team quorum + 1 Security; Deny-List = never
  self-service. **Fallback** if Security rejects machine-executed grants: "Weg A with team
  pool" (a team member performs the grant in the activated window). **Rejected: B-standing.**
  Security role = guardrails + periodic audit oversight, not per-transaction approval. See
  `SPEC.md` §7 and `DECISIONS.md` ADR-008 (revised).

**Extended capabilities — DECIDED (ADR-036–042, full text in `DECISIONS.md`):**
- **ADR-036 Admin & Configuration Console** — UI over Config-as-Code; toggles switch *features*, never *controls*; Report-Delivery 4 modes; Two-Tier Config Plane (Config-as-Code + Runtime-Flag-Store).
- **ADR-037 Backup & Restore** — data-durability by data class; Immutable Vault (Enabled+Locked/WORM) + Soft Delete + MUA/Resource-Guard; Daily+PITR, config-steerable with hard floors; restore drills.
- **ADR-038 Deployment** — one hardened data-driven module + per-app data (`tfvars.json`) + state-per-app; tool writes **data, never per-app HCL**; secrets-split (FIC in TF, Client Secret/Cert via Graph/KV).
- **ADR-039 Business Registry + CMDB-Federation** — Business App as first-class entity, 1:n mapping with function; CMDB **read-only, opt-in, defensive** (ServiceNow authoritative, never write back, no blank-overwrite, coverage-gap reporting as primary value).
- **ADR-040 Drift Control** — dual detection (`terraform plan` + `directoryAudits`), Revert/Adopt with change-management (ticket optional + reason mandatory), adopt-laundering guardrails.
- **ADR-041 Entitlements** — identity→authorization plane; Azure RBAC verify (Resource Graph `AuthorizationResources` + PIM-eligibility) + assign (bounded corridor at-and-below governance MG, Owner/UAA = Deny-List); Power BI/SharePoint verify+declare; verification-first (not a text field).
- **ADR-042 Executor Decomposition** — ~5 least-privilege executors (read broad+standing / write narrow+gated, High-Priv JIT); per-executor App Reg+FIC+CA; **runtime = Azure Container Apps Jobs**, isolated+ephemeral for the 2 Tier-0 write executors; orchestrator holds no resource rights.
- **ADR-043 CI/CD & Multi-Tenant** — Azure DevOps, **Dev-Tenant → Prod-Tenant** promotion, secretless WIF service connections, test pyramid, parity/capability detection (Prod-canary vs. false-green), VNet agents, license/FinOps (P2 per-user approvers + WI-Premium per-SP executors, not tenant-wide).

**Pending inputs (run the assessment, then confirm):**
1. **Licenses** — Entra ID P2 (PIM, access reviews, Agent-ID governance)? Defender for
   Cloud Apps "App Governance" add-on? (Assessment dumps subscribed SKUs.)
2. **Power Platform governance** — Managed Environments on? DLP policies? Who can create
   environments/connectors/agents? Tenant isolation?
3. **App Management Policy state** — `GET /policies/appManagementPolicies` (anything set?
   default is "no restrictions" = risk).
4. **Agent ID enablement** — per-environment agent identity creation on in Copilot Studio?
   Agents/blueprints in the Entra Agent Registry?
5. **DR** (NFR-01), `ownerBusinessId` attribute name/type, pentest resource, GDPR Art. 30
   + works-council status for the business owner.
   *Resolved assumptions (confirm, non-blocking):* DB = **PostgreSQL Flexible Server**;
   ticketing = **manual ticket/change number + optional API** (no live ServiceNow ITSM
   wiring, reason mandatory); runtime = **ACA Jobs**; chatbot = **new App Registration + OBO**;
   Azure-RBAC write-corridor = **at-and-below the governance MG under root** (exact MG-ID +
   fixed NAT egress IP = environment facts).
6. **ServiceNow CMDB (optional, Phase 3, ADR-039)** — **read-only inbound** (ServiceNow →
   EAGP), EAGP **never writes** the CMDB. Defensive by default (quality unknown/assumed
   sparse): high confidence threshold, nothing auto-linked, **no blank-overwrite**, per-field
   provenance; primary value = **coverage-gap reporting**. Decoupled from the control loop
   (kill-switch/approvals never depend on CMDB). Confirm at build: CSDM maturity, `cmdb_read`
   integration user, IP-allowlist vs. MID Server.

## 10. Key commands

**Read-only tenant assessment** (produces the classification/posture input above):

```powershell
# Run as Global Reader (least privilege). First run on a large tenant: -SkipRiskScan
pwsh ./scripts/eagp-assessment.ps1
# Output: ./eagp-assessment-<timestamp>/00_SUMMARY.json + CSV/JSON detail
```

**Terraform discipline (executor):** always `plan -out` → policy checks on the plan JSON
(deny-list gate, destroy protection) → `apply` the saved plan → post-apply verify via
Graph → audit. `prevent_destroy` on the application resource.

## 10a. Two overarching principles (settle most per-feature questions)

- **ADR-021 Completeness:** EAGP covers and **manages** the *entire* App-Registration /
  Enterprise-Application surface (not just reports). Per capability, only the **build wave**
  and the **hardness** are open — never the "whether". Reference surface + MVP acceptance
  gate: `FEATURE_PARITY.md`.
- **ADR-022 Hardness classifier (H0–H3):** how much gate an *action* needs follows from its
  blast radius, not the feature category. Highest applicable tier wins; ambiguity → higher;
  least privilege = only H0 is standing, the rest is JIT/approved. Hard-coded regardless of
  config: the 4 security invariants; deny-list never grantable via the self-service flow.
- **Domain boundaries (read/report/handoff, never authoring):** Conditional Access → IAM
  team; Azure RBAC → resource governance; Cross-Tenant/B2B → IAM (inactive, kept open);
  security-group lifecycle → possibly IGA. See ADR-023/024/025.
- **Scope note:** Entra is the leading system; AWS is a downstream SP (SAML/SSO). No
  cross-cloud mapping in this project. The AWS-SSO integration is itself a critical Tier-M
  object in EAGP.

## 11. Reference docs

- `DECISIONS.md` — **authoritative ADR log** (ADR-001…043 + open items). Read this for
  decision status; `SPEC.md` wins on detail.
- `SPEC.md` — full specification (threat model, ADRs, FR/SEC/GDPR, Terraform + import,
  test & security strategy, build order, prerequisites).
- `FEATURE_PARITY.md` — complete App-identity surface + hardness + wave = the MVP gate.
- `ROADMAP.md` — phasing (0 foundation+harness → 1 security core/MVP → 2 governance
  build-out → 3 extension).
- `TASKS.md` — agent-sized backlog with machine-checkable DoD (what Claude Code executes).
- `POC.md` — the first proof of concept: scope + exit criteria.
- `OPERATING_MODEL.md` + `.claude/settings.json` + `.claude/opsec-guard.sh` — the autonomous
  dev loop and its guardrails.
- `MANAGEMENT_DECISIONS.md` — the open points for management (M1–M6).
- `scripts/eagp-assessment.ps1` — read-only tenant assessment (run first).
- Management deck (`EAGP_Management_Vorlage.docx` / `.pptx`) — the A/B decision basis.

## 12. Where we are (handoff state)

The **design is complete and collaboratively hardened**, and the handoff is self-contained:
architecture, PaaS/serverless + private-first, the executor/containment model, the 4-tier
taxonomy, the Terraform + Python stack (single-language app), split-sink logging, the completeness +
hardness principles, the domain boundaries, right-sized DR with portal-fallback governance,
security telemetry + backup integrity, and the compliance/audit-evidence direction. A second
design round added and **decided** the extended capabilities **ADR-036–042** (admin/config
console, backup & restore, data-driven deployment, business registry + defensive CMDB
federation, drift control, target-system entitlements, executor decomposition) — all logged in
`DECISIONS.md`. All decisions are logged there; the open ones are either **management** (see
`MANAGEMENT_DECISIONS.md`, esp. ADR-008 executor model) or **environment facts** (run the assessment).

**Next concrete action (POC-first):**
1. Run `scripts/eagp-assessment.ps1` (Global Reader) → classify the estate (M/A/P/E) + read
   the guardrail/risk baseline; fill the 📥 facts in `DECISIONS.md` Part D.
2. Stand up the loop per `OPERATING_MODEL.md` (container + firewall + `.claude/` guardrails).
3. Execute `TASKS.md` **Welle 0 first (harness) — never skip it**, then the POC slice per
   `POC.md`.
4. In parallel, take `MANAGEMENT_DECISIONS.md` to management (ADR-008 unblocks the
   high-privilege grant paths; M4/M5 are go-live gates).
Do not skip the harness. Do not give the loop a path to prod or the real tenant.
