# OPERATING_MODEL.md — Autonomer Entwicklungs-Loop (Claude Code)

> Wie EAGP **gebaut** wird, nicht was es tut (das ist `SPEC.md`). Entwurf für einen
> weitgehend unbeaufsichtigten, agentischen Build durch Claude Code mit Mensch-Checkpoints.
> Grundlage: ADR-018. Für ein **Tier-0-System** gilt: Autonomie **nur** bei harter
> Containment + maschinell prüfbarem Orakel.

## Rollen
- **Design (dieser Chat / Mensch):** Ideen, Entscheidungen, ADRs, Backlog. Fällt nach Übergabe weg.
- **Ausführung (Claude Code):** liest `CLAUDE.md` + `SPEC.md` + `TASKS.md`, arbeitet den Backlog im Loop ab.
- **Review (Mensch):** merged PRs an Checkpoints, entscheidet ADR-Level-Fragen.

## Der Loop

```mermaid
flowchart LR
    B["TASKS.md (agent-sized, je mit machine-checkable DoD)"] --> I["Task implementieren"]
    I --> C["make check\nruff · mypy · pytest (inkl. 4 Invarianten)\ntflint · checkov · gitleaks · doc-drift"]
    C -->|rot| F["Fehler lesen → fixen"]
    F --> C
    C -->|grün| PR["Commit → Feature-Branch → PR → STOP"]
    PR --> H["Mensch reviewt PRs gebündelt"]
    H -->|merge| B
    STOP{{"Stop-Conditions"}} -.-> H
```

**Kernidee:** Die Testsuite ist das **Orakel**. Weil der Agent grün/rot selbst prüft, wird der
Mensch nicht zum Test-Orakel → kein ständiges Prompten.

## Autonomiegrad (Empfehlung: Auto mode)
Statt „alles bestätigen" (zu viel Reibung) oder YOLO (zu gefährlich): **Auto mode** —
Classifier gated jede Aktion, eskaliert bei wiederholten Denials (Stop nach 3 in Folge / 20
gesamt). Harte `deny`-Regeln bleiben **immer** wirksam (auch in bypass). Enterprise
**managed-settings.json** ist der Policy-Floor — CLI-Flags können ihn nicht lockern.

## Containment (Tier-0, nicht verhandelbar)
| Kontrolle | Umsetzung |
|---|---|
| Ausführung | **Container/Devcontainer mit Firewall** (Egress-Allowlist) — nie bare metal |
| Netz | **kein Pfad** zu Prod / echtem Tenant / Graph-Prod. Loop nur gegen **Dev-Wegwerf-Tenant** + Mocks |
| Secrets | keine im Container; `.env*` per deny; secretless Design |
| Grenze | `deny` = die echte Grenze (siehe `.claude/settings.json`) + PreToolUse `opsec-guard.sh` |
| Policy-Floor | Enterprise `managed-settings.json` (CLI kann nicht lockern) |
| Home | `~/.claude/` **nicht** mounten (Session-State-Korruption); npm-Version pinnen |

## Subagenten (Kosten-/Rollen-Routing)
Explorer (günstig, liest/plant) → Implementer (mittel, schreibt) → Architect (Top, ADR/Design).
**Warnung:** Subagenten erben den Permission-Mode und können ihn **nicht pro Subagent**
überschreiben → die **`deny`-Regeln + managed-settings sind das, was sie wirklich begrenzt**.

## Human-Checkpoints & Stop-Conditions
Der Agent loopt weiter, **außer** bei:
1. **Alle geplanten Tasks fertig** → Report + Stop.
2. **Merge/Deploy-Gate** → Mensch merged (Tier-0: **alle** PRs mensch-gemerged).
3. **ADR-Level-Entscheidung** taucht auf (z. B. das High-Priv-Grant-Modell) → **Agent entscheidet NICHT**, flaggt & stoppt.
4. **Bounded retries erschöpft** (Turn-Limits: Dev ~40, Review/Fix ~15).
5. **Guardrail getript / wiederholte Denials** → eskaliert an Mensch.

## Observability
Jeder Run wird erfasst: Prompt, Tool-Calls, Diff, structured output (`stream-json`), Kosten
(JSONL-Transcripts). „Was nicht erfasst ist, ist für das Incident-Review nicht passiert."
Dieser Run-Log ist zugleich Meta-Audit des Bau-Prozesses.

## Anti-Patterns
| Anti-Pattern | Warum Teams reinlaufen | Konsequenz |
|---|---|---|
| YOLO auf bare metal | Reibung nervt | Agent erreicht alles, was der Account kann (`rm -rf ~/`-Klasse) |
| Kein machine-checkable DoD | Harness fühlt sich langsam an | Mensch wird wieder Test-Orakel → ständiges Prompten |
| **Test-Reward-Hacking** | rot→grün durch Abschwächen der Invarianten-Tests | bei EAGP fatal — die 4 Invarianten *sind* die Garantie; Testdateien schützen + Test-Diffs reviewen |
| Auto-Merge security-relevant | „CI ist grün" | kein Mensch im Loop für Tier-0-Änderungen |
| Unbounded Runs | „lass laufen" | Context-Drift; Turn-Limits + Re-Grounding in `CLAUDE.md` |

## Azure-DevOps-Hinweis
Die offizielle `anthropics/claude-code-action` ist **GitHub-Actions-spezifisch** → auf Azure
DevOps `claude -p --bare` selbst in einen Pipeline-Step/Cron wrappen (`--bare` ist für
scripted Runs empfohlen und wird künftig Default für `-p`). Für Overnight-Batches ist ein
Container auf dem VPS pragmatisch.

## Referenz-Setup (bewährte Bausteine)
`cmAIdx/headless-claude-automation-template`: Branch-Protection-Hook (keine Edits an `main`),
Destructive-Command-Blocker (force-push, `rm -rf`, DB-Drop), Credential-Deny (`.env*`),
Turn-Limits, Concurrency-Groups. Als Vorlage adaptieren.

## Offene Calls (📥/🔴, siehe DECISIONS.md)
Autonomiegrad-Bestätigung · Merge-Gate-Bestätigung · Ausführungsort (VPS-Container vs. Azure
DevOps) · ist der VPS schon Container mit Egress-Kontrolle?
