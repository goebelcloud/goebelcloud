# EAGP — Offene Entscheidungen für Management

> Zweck: Punkte, die **nicht** das Architektur-/Umsetzungsteam allein entscheiden kann,
> weil sie Risiko-Appetit, Verantwortlichkeiten, Budget oder Recht berühren. Jede
> Entscheidung ist so aufbereitet, dass sie in einem Management-Termin **direkt getroffen**
> werden kann: Kontext → Optionen → Empfehlung → Auswirkung. Reihenfolge = Wichtigkeit.

---

## M1 — Executor-Modell für hochprivilegierte Grants (Security-Freigabe)

**Worum es geht.** EAGP kann hochprivilegierte Berechtigungen erteilen (z. B. Application-
Permissions à la `Directory.ReadWrite.All`, Directory-Rollen an Apps). Die Kernfrage ist **nicht**
„Mensch oder Maschine" (die Executor-Identität lässt sich technisch stark absichern — secretless,
IP-gebunden, mit Echtzeit-Sperre bei Auffälligkeit), sondern: **Wo liegt tenant-übernahme-fähige
Macht *dauerhaft*?** Ein technischer Fakt rahmt die Optionen: eine Maschinen-Identität kann sich
**nicht** selbst „on demand" elevieren — sie hat Rechte entweder dauerhaft oder nur in einem
**zeitlich begrenzten, von einem Menschen freigegebenen Fenster**.

| | **Gehärtetes Modell (Empfehlung)** | **Verworfen: dauerhafte Maschinen-Macht** |
|---|---|---|
| Prinzip | Executor hält **keine** dauerhaften Tier-0-Rechte. Für den seltenen Grant aktiviert **ein Team-Mitglied** (mit Freigabe eines zweiten) ein zeitlich begrenztes Fenster; darin führt EAGP den Grant aus, danach erlischt das Recht automatisch. | Executor hält die gefährlichste Macht dauerhaft; nur Software genehmigt die Nutzung. |
| Sicherheit | Kein dauerhaftes Tier-0 im Werkzeug; jede Elevation zeitlich begrenzt + protokolliert. | Ein Fehler/Angriff im Werkzeug reicht potenziell zur Tenant-Übernahme. |
| Least Privilege | ✅ optimal | ❌ dauerhafte Tier-0-Rechte |
| Flaschenhals | **gelöst** (s. u.) | „gelöst", aber teuer erkauft |

**Der eigentliche Nutzen — Flaschenhals auflösen.** Heute ist das Erteilen solcher Rechte an
einen bestimmten Tier-0 gebunden (oft den Teamleiter → Engpass bei Urlaub/Krankheit). **Lösung:
Unser Team wird der freigebende Pool** (mind. zwei Personen, Vier-Augen). Da die fachliche
Bewertung von App-Berechtigungen ohnehin im Team liegt, wird damit **Autorität dort angesiedelt,
wo die Kompetenz ist** — ohne Einzelperson als Engpass.

**Gestufte Freigabe (nach Gefährlichkeit):**

| Klasse | Beispiel | Freigabe |
|---|---|---|
| Moderat privilegiert (häufig) | die meisten App-Berechtigungen | **Team-Vier-Augen** (2 Team-Mitglieder) |
| Tenant-übernahme-fähig (selten) | `Directory.ReadWrite.All`, Directory-Rolle an App | **Team-Vier-Augen + 1 Security** |
| Verbotene Klasse (Deny-List) | definierte Kill-Berechtigungen | **nie per Self-Service** |

So läuft der **häufige** Fall (wo der Engpass weh tut) allein über das Team; nur die **seltene**
katastrophale Klasse zieht Security hinzu.

**Was Security freigeben/festlegen muss:** (a) Akzeptanz des Modells inkl. der eingebauten
Schutzmaßnahmen (Aktion nach Freigabe nicht austauschbar, zeitlich begrenzte statt dauerhafte
Rechte, Echtzeit-Sperre); (b) Bestätigung, dass **Vier-Augen + Security-in-der-Top-Klasse** die
Trennung der Verantwortlichkeiten ausreichend wahrt; (c) **Security-Rolle = Guardrails setzen +
regelmäßige Prüfung der Protokolle**, statt jede einzelne Freigabe mitzuzeichnen.

**Empfehlung:** gehärtetes Modell freigeben. **Fallback**, falls Security die maschinelle
Ausführung des finalen Grants ablehnt: das Team-Mitglied führt den Grant im aktivierten Fenster
selbst aus (Werkzeug macht den Rest) — gleiche Kern-Eigenschaft (keine dauerhaften Rechte).
**Auswirkung:** legt Berechtigungsmodell, Lizenzen (P2 / Workload ID Premium) und den Grant-Pfad
fest — blockiert den Bau der Grant-Wege, bis freigegeben.

---

## M2 — Wer darf freigeben? **Approver-Pool + Quorum**

**Worum es geht.** Kritische Aktionen (H2/H3, siehe Härte-Modell) brauchen Freigabe. Das Tool
setzt das technisch um — aber **wer** in diesen Pool gehört und **wie viele** zustimmen
müssen, ist eine Organisations-/Security-Entscheidung.

**Empfehlung (konfigurierbar, das sind die Defaults):**
- **Approver-Pool** = klar benannte, qualifizierte Teilmenge (Security + Senior Platform), **nicht** jeder Admin.
- **Quorum** = **2-of-N** für HIGH/Tier-0-Aktionen; 1 Peer für mittlere.
- **Grundregel (hart):** Approver ≠ Requester, immer.

**Zu entscheiden:** Namen/Rollen des Pools, Quorum-Höhe. **Auswirkung:** definiert die reale
Wirksamkeit des 4-Augen-Prinzips.

---

## M3 — Verbindliche **Compliance-Standards**

**Worum es geht.** EAGP kann Audit-Nachweise als Nebenprodukt erzeugen und Kontrollen auf
Standards mappen. Das Team hat als Default **ISO 27001:2022, TISAX (VDA ISA 6.0), BSI C5:2020**
angesetzt. Management bestätigt/ergänzt, **welche verpflichtend** sind.

| Standard | Relevanz | Aufwand in EAGP |
|---|---|---|
| ISO/IEC 27001:2022 | Basis-ISMS | Control-Mapping (gering, Nebenprodukt) |
| TISAX / VDA ISA 6.0 | Automotive-Lieferkette; neu: Prüfziel *Availability* | + Availability-/BCM-Evidence |
| BSI C5:2020 | Cloud-Nachweis (DE) | Mapping (gering) |
| SOC 2 / NIS2 | falls einschlägig | zusätzlicher Scope |

**Zu entscheiden:** verbindliche Menge + ob **TISAX-Prototypenschutz/Datenschutz-Prüfziele**
euch betreffen (→ Prototype/Data-Klassifikation als App-Attribut). **Auswirkung:** steuert die
Report-/Evidenz-Anforderungen (Core im MVP, Rest Phase 2).

---

## M4 — **Betriebsrat & Datenschutz (Art. 30)**

**Worum es geht.** EAGP verarbeitet personenbezogene Daten (App-**Owner**, Approver, und via
**Read-Access-Logging** wer was ansah). Das ist Governance-notwendig, berührt aber
Mitbestimmung und DSGVO.

**Empfehlung / To-do (Management/Legal/DPO):**
- **Art.-30-Verzeichnis**-Eintrag für die Verarbeitung anlegen (Zweck, Datenarten, Retention).
- **Betriebsrat** frühzeitig einbinden (Logging von Mitarbeiter-Aktionen).
- Datenminimierung ist eingebaut (Object-IDs statt UPN; Namen nur zur Anzeige).

**Auswirkung:** **Go-Live-Voraussetzung** — ohne geklärte Mitbestimmung/Art.-30 kein
Produktivbetrieb.

---

## M5 — **Pentest-Ressource**

**Worum es geht.** Für ein Tier-0-System ist ein bestandener Penetrationstest ein
**Release-Gate** vor Produktivnahme (auch Audit-relevant).

**Zu entscheiden:** interne vs. externe Ressource + Budget/Termin. **Auswirkung:** Gate vor
Go-Live; früh terminieren, um den Rollout nicht zu blockieren.

---

## M6 — **Betriebsmodell des autonomen Entwicklungs-Loops** (teils Environment)

**Worum es geht.** EAGP wird von einem KI-Agenten (Claude Code) weitgehend autonom gebaut.
Das Sicherheitsmodell dafür ist entworfen; drei Kalibrierungs-Entscheidungen bleiben.

| Frage | Empfehlung |
|---|---|
| Autonomiegrad | **Auto mode + strikte Deny-Regeln + Enterprise-Policy-Floor + Container/Firewall** (Autonomie ohne blindes Vertrauen) |
| Merge-Gate | **Alle Pull-Requests von Menschen gemerged** (Tier-0, kein Auto-Merge) |
| Ausführungsort | Container auf VPS (Overnight) **oder** Azure-DevOps-Pipeline |

**Nicht verhandelbar (unabhängig davon):** Container statt Produktiv-Maschine; **kein Zugriff
des Agenten auf den echten Tenant oder Prod**; harte Sperren für gefährliche Aktionen.
**Auswirkung:** legt fest, wie schnell/unbeaufsichtigt gebaut wird — bei voller Sicherheit.
Details: `OPERATING_MODEL.md`.

---

## Entscheidungs-Übersicht (für das Protokoll)

| # | Entscheidung | Empfehlung | Blockiert… |
|---|---|---|---|
| M1 | Executor-Modell (High-Priv-Grants) | Gehärtetes Modell + Tiered Approval | Grant-Bau |
| M2 | Approver-Pool + Quorum | benannter Pool, 2-of-N HIGH | Approval-Wirksamkeit |
| M3 | Compliance-Standards | ISO 27001:2022 + TISAX 6.0 + C5 | Report-Scope |
| M4 | Betriebsrat + Art. 30 | einbinden / eintragen | **Go-Live** |
| M5 | Pentest-Ressource | früh terminieren | **Go-Live** |
| M6 | Loop-Betriebsmodell | Auto mode + Human-Merge + Container | Bau-Autonomie |

> **Nichts hiervon blockiert den POC** (siehe `POC.md`) außer indirekt M1 (nur für die
> hochprivilegierten Grant-Pfade). Der POC beweist Architektur, Sicherheit und Kernnutzen und
> kann parallel zu diesen Entscheidungen starten.
