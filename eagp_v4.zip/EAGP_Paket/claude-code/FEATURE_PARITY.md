# FEATURE_PARITY.md — App-Identity-Surface (MVP-Abnahme-Gate)

> Macht das **Vollständigkeitsprinzip (ADR-021)** messbar: der *gesamte* App-Registration-/
> Enterprise-Application-Surface, gegen den „vollständig" geprüft wird. Abgeglichen mit den
> Microsoft-Graph-Ressourcen `application` + `servicePrincipal` (v1.0) und der Custom-Claims-
> Provider-Doku. Jede Fähigkeit: **im Produkt = ja** (ADR-021); offen nur **Welle** + **Härte
> (ADR-022)**. Governance-Domänen-Grenzen sind markiert (read/report/handoff statt Authoring).
>
> **Legende Welle:** P1 = MVP · P2 = Ausbau · P3 = Erweiterung · C = konditional (nur falls genutzt) ·
> **Härte:** H0/H1/H2/H3 (siehe ADR-022) · **DG** = Domänengrenze (kein Authoring in EAGP).

## A. Application Object (App Registration)

| Fähigkeit | Welle | Härte |
|---|---|---|
| Basis: displayName, identifierUris (appId-URI), Logo/Branding, publisherDomain, ToS/Privacy-URLs, notes, tags, serviceManagementReference | P1 | H0 |
| Platform-Config Web: redirectUris, front-channel logout, implicit-grant-Flags | P1 | H1 |
| Platform-Config SPA / Mobile / Desktop (public client) | P1 | H1 |
| **Federated Identity Credentials (FIC)** (issuer/subject/audience) | P1 | H1 |
| API-Exposition: **App-Rollen (Definition)**, oauth2PermissionScopes, preAuthorizedApplications, requestedAccessTokenVersion | P1 | H1 |
| API-Konsum: requiredResourceAccess (Delegated **+ Application Permissions**) | P1 | **H1/H3** (Application-type → H3) |
| Token: optionalClaims, groupMembershipClaims, token-encryption, signInAudience | P1 | H1 (signInAudience-Wechsel H2) |
| Credentials: Client Secrets, Certificates, FIC | P1 | H1 (risiko-gestuft) |
| **servicePrincipalLockConfiguration** (sensible Properties gegen Änderung sperren) | P1 | H2 |
| requestSignatureVerification, defaultRedirectUri, isFallbackPublicClient, isDeviceOnlyAuthSupported, nativeAuthenticationApisEnabled | P2 | H1 |
| Directory-/Schema-Extension-Properties am App-Objekt | P2 | H0/H1 |
| **onPremisesPublishing** (App Proxy) | C | H2 |
| Zugewiesene Policy-Objekte: tokenLifetimePolicies, claimsMappingPolicies, homeRealmDiscoveryPolicies, tokenIssuancePolicies, **appManagementPolicies** | P2 | H2 |
| Technische **Owners** (App) | P1 | H1 |

## B. Service Principal (Enterprise Application)

| Fähigkeit | Welle | Härte |
|---|---|---|
| Properties: accountEnabled, **appRoleAssignmentRequired** (ADR-019), homepage/login/logout-URL, notes, tags, servicePrincipalType | P1 | H0/H1 (`AssignmentRequired`→false = **H2**) |
| **User/Group-Assignments** + App-Rollen-Zuweisung (via Security-Gruppen erzwungen) | P1 | H1 |
| **SSO-Config SAML**: NameID, Claims/Transformation, Signing-Cert + Ablauf, Encryption-Cert, RelayState, preferredTokenSigningKeyThumbprint, samlMetadataUrl | P1 | H2 (Signing-Änderung) |
| SSO OIDC / Linked / Header-based (App Proxy) · preferredSingleSignOnMode | P1 (Kern) / C | H1/H2 |
| **SCIM-Provisioning** vollständig (Lifecycle, Health, Credentials, Mappings, Scoping) — ADR-020 | P1 (Kern) / P2 (Mappings) | H1 / **H2** (Mappings/Scoping) |
| **Consent & Permission-Grants**: delegated (oauth2PermissionGrants), Admin-Consent, App-Role-Assignments (App-Permissions) · Consent Approval Center | P1 | **H2/H3** (Admin/App-Consent) |
| **delegatedPermissionClassifications** (Low-Risk für User-Consent) | P2 | H2 |
| **Conditional-Access-Bezug** (Reports „App ohne CA" / „welche CA greift"; CA-Impact-Check bei H2) | P1 (Report) | **DG** (Authoring = IAM) |
| **Directory-Rollen des SP** (read/report; entziehen+vergeben) — ADR-025 | P1 (Report) | **H3** (Änderung) |
| **Azure-RBAC-Rollen des SP** (read/report + Handoff) — ADR-025 | P1 (Report) | **DG** (Authoring = Resource-Gov) |
| **Custom Security Attributes** (Governance-Tagging, Policy-Exemptions) | P2 | H1 (H2 wenn Policy-Exemption) |
| **Custom Authentication Extension / Custom Claims Provider** (Token Issuance Start → externe REST-API) | P2/C | **H2** |
| notificationEmailAddresses (SAML-Cert-Ablauf-Benachrichtigung) | P1 | H1 |
| Self-Service-Access / My-Apps-Sichtbarkeit | P2 | H1 |
| remoteDesktopSecurityConfiguration | C | H2 |
| SP **Owners** | P1 | H1 |

## C. Querschnitt (alle Objekte)

| Fähigkeit | Welle | Härte |
|---|---|---|
| Lifecycle: Create / Update | P1 | je Aktion |
| **Soft-Delete → Restore → Purge** · Decommissioning-Workflow (disable→soak→delete→purge) | P1 (delete/restore) / P2 (Workflow) | **H2** (Purge/Delete) |
| Credential-Hygiene · Expiry-Monitoring · Rotation (inkl. SCIM- & SAML-Signing-Certs) | P1 | H1 |
| **Credential Re-Reveal** aus KV (ADR-029) — gültige, im KV liegende Credentials | P1 | **H2** (Owner-Bindung delegiert; Admin ohne) |
| **Credential-History & Zero-Downtime-Overlap** (ADR-031) — aktiv+historisch, create→switch→verify→retire | P1 | H1 / **H2** (retire-old) |
| **Rotations-Führung** (ADR-030) — Secret=Entra-SoT→KV; Cert=KV→Public-Key; FIC secretless; Klartext nie persistiert (ADR-035) | P1 | — (Invariante) |
| **EAGP-API** (kein Graph-Write) + optional Terraform-Provider / PowerShell-Modul | P1 (API) / P2 (Provider) | — |
| **Chatbot-Zugriff** via OBO (ADR-032) — Metadaten direkt, Secret nur via H2-Reveal; AuthZ gegen DB-`owner` | P2 | **H2** (Secret) / H0 (Metadaten) |
| **Configuration Backend** als Tier-0-Kontrollpunkt (ADR-033) — Config-as-Code, Domänen+Schutzklassen, Kill-Switches, hart kodierte Untergrenzen | P1 (Kern) | **H1–H3** je Domäne (+ Self-Ref-Sperre) |
| **Tier-Klassifikation M/A/P/E** + Governance je Tier (ADR-016) | P1 (Klassifikation) / P2 (A/P/E-Governance) | — |
| Drift-Detection · **Out-of-Band-Detection** · Reconcile (inkl. `emergency-fallback`, ADR-026) | P2 (Drift/OOB) / P1 (Reconcile-Basis) | — |
| Immutable Audit · Change-History · Approvals | P1 | — |
| **Read-Access-Logging** · **Reveal-Anomalie-Alerting** (ADR-027) | P1 | — |
| Bulk-Operationen (Massen-Rotation/-Tagging/-Import) | P2 | je Aktion |
| Brownfield-Import (4-stufig, leerer-Plan-Gate, Canary) | P2 | H2 |
| **EAGP-eigene API** + optional Terraform-Provider / PowerShell-Modul | P1 (API) / P2 (Provider) | — |

## Domänengrenzen (bewusst kein Authoring in EAGP)
- **Conditional Access** → IAM-Team (EAGP: read/report + Impact-Check).
- **Cross-Tenant / B2B-Settings** → IAM/Identity-Governance (inaktiv, offen halten — ADR-024).
- **Azure-RBAC-Assignments** → Resource-Governance (EAGP: read/report + Handoff — ADR-025).
- **Security-Gruppen-Lifecycle** → ggf. IGA (EAGP: nutzt + reportet).

## Abnahme-Kriterium (MVP-Gate)
MVP gilt als „vollständig genug", wenn **alle P1-Zeilen** verwaltbar sind (nicht nur
anzeigbar), die Härte-Einstufung je Aktion durch den Klassifikator (ADR-022) durchgesetzt ist
und die Domänengrenzen als read/report/handoff implementiert sind. P2/P3/C folgen nach
Backlog. Claude Code prüft die tatsächlichen Feld-/Endpunkt-Namen gegen die **dann-aktuelle**
Graph-Version (eingebauter Drift-Schutz gegen diese Momentaufnahme, Stand Anfang 2026).

---

## Erweiterte Fähigkeiten (ADR-036–042) — Bau-Welle & Härte

| Fähigkeit | Bau-Welle | Härte / Governance |
|---|---|---|
| **Admin & Configuration Console** (ADR-036) — UI over Config-as-Code, Report-Delivery 4 Modi, Feature-Flags/Kill-Switches, Two-Tier Config Plane | P1 (Kern) / P2 (Delivery-Modi) | H1–H3 je Domäne; Controls nie abschaltbar |
| **Backup & Restore** (ADR-037) — Datenklassen-Backup, Immutable Vault + Soft Delete + MUA, Daily+PITR, Restore-Drills | P1 | Backup = Control (hart), Config H2 |
| **Deployment-Pattern** (ADR-038) — data-driven Module + State je App, plan→approve→apply, Secrets-Split | P1 (Fundament) | — (Invariante: keine Secrets in TF) |
| **Business Application Registry** (ADR-039) — First-Class-Entity, 1:n-Mapping mit Funktion, Zwei-Ebenen-Ownership | P1 (native) | H0/H1; Owner-Zuweisung H1 |
| **CMDB-Federation** (ADR-039) — read-only, defensiv, Provenance, Coverage-Gap-Reporting | P3 (zuschaltbar) | read-only (nie Write ServiceNow) |
| **Drift Control & Reconciliation** (ADR-040) — duale Detektion, Revert/Adopt mit Change-Mgmt | P1 (detect) / P2 (Adopt-Flow) | Revert/Adopt = Härte des Diffs; Adopt-Laundering-Guardrails |
| **Target-System Entitlements — Azure RBAC** (ADR-041) — Verify (Resource Graph) + Assign (bounded Korridor) | P2 | Reader H1 / Contributor H2 / Owner-UAA H3+Security; Root = Deny-List |
| **Entitlements — Power BI / SharePoint** (ADR-041) — Verify + Declare | P3 | read/verify |
| **Executor Decomposition** (ADR-042) — ~5 Least-Privilege-Executors, per-Executor FIC+CA, ACA-Jobs, isolierte Runner | P1 (Fundament) | Read breit+stehend / Write eng+gated; High-Priv JIT |

## CI/CD, Stack & FinOps (ADR-005 revidiert · ADR-043)

| Fähigkeit | Bau-Welle | Härte / Governance |
|---|---|---|
| **Tech-Stack** (ADR-005 rev.) — Terraform + Python (einsprachig), kein PowerShell-Runtime | P0 | Invariante: keine Secrets in TF; msgraph-sdk-Spike zuerst |
| **CI/CD Multi-Tenant** (ADR-043) — Azure DevOps, Dev→Prod-Tenant, secretless WIF, Test-Pyramide | P0/P1 | Environments + Approval-Gate; planHash |
| **Parität-/Capability-Detection** (ADR-043) — Prod-Canary statt False-Green | P1 | report-only, Ring-Rollout |
| **FinOps CA-Coverage-Report** (ADR-043) — P2 per-User + WI-Premium per-SP, nicht tenant-weit | P2 | Lizenz-Compliance sichtbar |
