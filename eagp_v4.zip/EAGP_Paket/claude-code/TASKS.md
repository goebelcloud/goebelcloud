# TASKS.md — Agent-Backlog für Claude Code

> Reihenfolge = Build-Order (SPEC §15). Jeder Task ist **agent-sized** und hat ein
> **machine-checkable Definition of Done (DoD)** — das Orakel, an dem der Loop selbst prüft,
> ohne Menschen. Der Agent arbeitet **von oben nach unten**, ein PR pro Task (oder kleine
> Gruppe). **Harness zuerst** — keine Fachfunktion vor grüner Harness.
>
> Konvention: `[ ]` offen · `[~]` in Arbeit · `[x]` gemerged. `Härte`/`ADR` = Referenz.
> **Blocker:** Tasks mit 🔴 warten auf eine Management-/Fakt-Entscheidung (DECISIONS.md).

## Welle 0 — Fundament & Harness (zuerst, blockiert alles)
- [ ] **T00 Repo-Scaffold** — `/api /executor /modules/entra-application /platform-iac /scripts /policies /docs`, `CLAUDE.md`, `SPEC.md`, `DECISIONS.md` eingecheckt.
      *DoD:* `make check` existiert und läuft (auch wenn leer grün); Repo-Struktur wie `CLAUDE.md` §6.
- [ ] **T01 CI-Gates** — SAST/SCA/IaC-Scan/Secret-Scan/Doc-Drift in Pipeline.
      *DoD:* Pipeline failt bei eingebautem Secret-Pattern, bei `tflint`-Fehler, bei uncommitted Doc-Diff.
- [ ] **T02 Policy-Engine-Testsuite (die 4 Invarianten)** — als Tests **vor** der Engine.
      *DoD:* 4 Tests existieren und sind **rot** (Engine fehlt noch): (1) Deny-List nie via delegated flow; (2) Approver≠Requester; (3) planHash-Mismatch→reject; (4) App-Group-Scope-Isolation.
- [ ] **T03 Synthetische Brownfield-Fixtures** — Wegwerf-Testdaten (Apps mit Secrets/Alt-Config).
      *DoD:* Fixture-Loader erzeugt reproduzierbaren Zustand; Import-Dry-Run darauf ergibt später „leeren Plan".
- [ ] **T04 Dev-Tenant-Isolation-Guard** — Executor verweigert Nicht-Dev-Tenant im Testkontext.
      *DoD:* Test beweist: Ziel-Tenant ≠ Dev-Tenant → harter Abbruch.

## Welle 1 — Plattform-IaC (Dev-Tenant, Plan-only bis Review)
- [ ] **T10 Plattform-IaC-Skeleton** — Networking (PE), Identitäten, PostgreSQL Flexible Server, Storage, KV, Service Bus, ACA, **Split-Sink-Logging (ADR-015)**.
      *DoD:* `terraform validate` + `checkov` grün; `plan` erzeugt erwartete Ressourcen; **kein** öffentlicher Endpoint im Plan.
- [ ] **T11 Datenmodell + Migrations** — apps, app_groups, delegations, approvals, runs, drift_findings, audit_refs, owners, change_records, permission_requests, config, **app_tier**, **agent_refs**.
      *DoD:* Migration up/down grün; Schema-Tests bestätigen Tabellen/Constraints.

## Welle 2 — Sicherheitskern (MVP)
- [ ] **T20 AuthN/AuthZ + Policy Engine** — erfüllt die 4 Invarianten (T02 wird grün).
      *DoD:* T02-Tests **grün**; AUTHZ-Regeln (App-Group-Scope, Object-ID-Trust=nein) getestet.
- [ ] **T21 Terraform-Modul `entra-application` + Executor-Job** — Tier-M-App create aus Template (Happy Path, WIF, secretless).
      *DoD:* E2E gegen Dev-Tenant: create→plan→apply→verify via Graph; **kein Secret in State/Log** (Scrubbing-Test grün).
- [ ] **T22 Approval-Workflow + Consent Approval Center + Audit-Pipeline** — Härte-Klassifikator (ADR-022) verdrahtet.
      *DoD:* H2-Aktion erfordert 2-of-N; jede privilegierte Aktion erzeugt WORM-Audit-Event (fehlt Event → Test rot).
- [ ] **T23 Credentials** — FIC/Cert/Secret, KV-Storage, **Expiry-Monitoring**, Rotation; One-time-Reveal (TTL) + **Reveal-Anomalie-Alert (ADR-027)**.
      *DoD:* Reveal auditiert + TTL erzwungen; Expiry-Report listet ablaufende Creds; Reveal-Spike löst Alert-Test aus.
- [ ] **T23a Rotations-Führung (ADR-030)** — Secret via Graph `addPassword` an App Reg (Entra=SoT) → direkt KV; Cert via KV (Public Key via `addKey`); FIC secretless.
      *DoD:* Test beweist: Secret-Klartext nur flüchtig, landet in KV, **nie** in State/Log; Cert-Private-Key verlässt KV nie; generischer KV-Auto-Rotate für App-Reg-Secrets ist ausgeschlossen.
- [ ] **T23b Re-Reveal (ADR-029)** — wiederholter KV-Reveal, H2, Owner-Bindung (delegiert), Step-up-MFA + Justification + TTL + WORM-Audit.
      *DoD:* Owner-Match erforderlich (nicht `ownedBy`); Admin ohne Owner-Bindung; Custody/nur-Hash → kein Re-Reveal; jeder Reveal auditiert.
- [ ] **T23c Credential-History & Overlap (ADR-031)** — aktive+historische Credentials; Zero-Downtime-Overlap (create→both→switch→verify→retire-old als eigener H2-Schritt).
      *DoD:* altes aktives Credential wird nie automatisch entfernt; Overlap-Status sichtbar; SAML-Signing-Rollover erzwingt Overlap.
- [ ] **T23d Klartext-Hygiene-Tests (ADR-035)** — Scrubbing + CI-Secret-Scan auf Log/Plan/Trace/Error; TLS-only; No-Store-Reveal.
      *DoD:* eingebautes Secret in Log/State/Error/URL wird vom CI-Scan gefangen (rot); Reveal-Response hat No-Store + TTL.
- [ ] **T24 User/Group-Assignment + `AssignmentRequired` + Compliance-Report (ADR-019)** — 4-Zustands-Taxonomie, gescoped auf user-facing/SSO.
      *DoD:* Report klassifiziert Fixtures korrekt (CRITICAL/GAP/COMPLIANT); Öffnen auf `false` triggert H2-Approval.
- [ ] **T25 SP-Privileged-Access-Report (ADR-025)** — Directory-Rollen + Azure-RBAC + High-Priv-Graph-App-Permission.
      *DoD:* Report findet in Fixtures den SP mit Directory-Rolle/priv. RBAC; RBAC ist read-only (kein Authoring-Pfad).
- [ ] **T26 Read-Access-Logging + Backup-Integrität (ADR-027)** — immutable/verschlüsselte Backups.
      *DoD:* Zugriff auf Config/Cred-Metadaten erzeugt Log-Eintrag; Backup-Restore-Test grün; Backup ist WORM.
- [ ] **T27 Emergency-Access + Post-Fallback-Reconciliation (ADR-026)** — OOB via `directoryAudits`, `emergency-fallback`-Tag.
      *DoD:* simulierte Portal-Änderung wird erkannt, in Desired State adoptiert, mit Tag auditiert.
- [ ] **T28 EAGP-API (read + Kernaktionen) + Chatbot-OBO (ADR-032)** — Automatisierung *durch* EAGP; Chatbot via On-Behalf-Of.
      *DoD:* API-Contract-Tests grün; kein Graph-Write; mutierende Endpunkte durch Policy-Engine + Audit; Chatbot-AuthZ gegen DB-`owner` (nicht `ownedBy`), serverseitig (prompt-injection-resistent), keine tenant-weite Sicht.

## Welle 2b — Configuration Backend (Tier-0-Kontrollpunkt, ADR-033) — MVP-relevant
- [ ] **T-CFG-1 Config-Schema & Domänen** — Config-as-Code (JSON/YAML + Validierung), vier Domänen + Schutzklassen.
      *DoD:* Schema-Validierung grün; Domänen (Security-kritisch/Zugriff/Compliance/Operativ) mit Härte-Zuordnung modelliert.
- [ ] **T-CFG-2 Config-Change-Workflow** — jede Änderung durch Härte-Klassifikator (H1–H3) + Selbst-Referenz-Sperre + WORM-Audit (vorher→nachher/wer/warum).
      *DoD:* Security-kritische Änderung erzwingt H3 + Self-Ref-Sperre (Test: Quorum nicht über sich selbst absenkbar); jede Änderung versioniert/rückrollbar.
- [ ] **T-CFG-3 Hart kodierte Untergrenzen** — 4 Invarianten + „Deny-List nie via Self-Service" **nicht** per Config abschaltbar.
      *DoD:* Test beweist: auch mit Approval lässt sich keine Invariante deaktivieren.
- [ ] **T-CFG-4 Laufzeit-Flag-Store + Kill-Switches** — Chatbot-Master-Kill + Feature-Flags, serverseitig, sofort wirksam ohne Deployment; Autorisierung über EAGP-Approval.
      *DoD:* Flag-Flip wirkt zur Laufzeit; API verweigert bei Kill; Flag-Änderung durchläuft Approval + Audit.
- [ ] **T-CFG-5 Fail-safe-Verhalten** — Config unerreichbar/fehlt → restriktivste Auslegung; Kill aus → verweigern.
      *DoD:* Test: Config-Ausfall führt zu Deny (kein fail-open).
- [ ] **T-CFG-6 Config-Zugriffstrennung** — nur Admins/T0 sehen/ändern; App-Group-Admins nie; Config-Read selbst auditiert.
      *DoD:* App-Group-Admin-Zugriff auf Config wird verweigert + auditiert.

## Welle 3 — Governance-Ausbau & Compliance (Phase 2)
- [ ] **T30 SCIM voll (Mappings/Scoping mit What-if + Approval, ADR-020)** · **T31 SSO-Tiefe (SAML/OIDC, Cert-Klasse-3-Monitoring)** · **T32 Tier A/P/E-Governance (App-Mgmt-Policies, Agent-ID-Integration, Consent/Risk)** · **T33 Drift + OOB breit** · **T34 Brownfield-Import (4-stufig, Canary)** · **T35 Audit-Evidenz-Engine + Auditor-Read-Only-Rolle (ADR-028)** · **T36 Reporting-Breite R3–R11 + Compliance-Dashboard** · **T37 Decommissioning-Workflow · Bulk-Ops**.
      *DoD je Task:* Feature verwaltbar (nicht nur Report), Härte durchgesetzt, Tests grün, `FEATURE_PARITY.md`-Zeile abgehakt.

## Welle 4 — Erweiterung (Phase 3)
- [ ] **T40 ServiceNow-CMDB-Reconciliation (über IRE, ADR-017)** · **T41 Terraform-Provider/PowerShell-Modul** · **T42 Time-bound/JIT-App-Permissions** · **T43 Cross-Service-Discovery-Breite**.

## 🔴 Blockiert bis Management-Entscheidung
- [ ] **T22b Grant-/Consent-Ausführungspfad (Weg A oder B)** — hängt an **ADR-008 (M1)**. Bis dahin: Approval-Workflow bauen, **Ausführung** hochprivilegierter Grants stubben + `// BLOCKED: ADR-008`.

## Welle 3 — Erweiterte Fähigkeiten (ADR-036–042)

### Config Console & Report-Delivery (ADR-036)
- [ ] **T-CFG-7 Report-Delivery-Engine** — 4 Modi (Dashboard-only/On-Demand/Scheduled-Push/Event-Triggered) + Scheduler (Frequenz/Timezone/Business-Days) + Channels (Teams/E-Mail/SharePoint) + RBAC je Report + Snapshots.
      *DoD:* Scheduled-Push feuert zur konfigurierten Zeit; Event-Trigger löst bei Bedingung aus; RBAC verweigert unberechtigten Report-Zugriff.
- [ ] **T-CFG-8 Feature-Flag-Registry + Elementary-Lock** — Kill-Switches + Feature-Flags, laufzeit-wirksam; Controls (Audit/Invarianten/AuthZ/Deny-List/Kill-Switch) als „locked by policy" nicht abschaltbar.
      *DoD:* Test beweist: kein Control-Toggle möglich; Feature-Toggle wirkt zur Laufzeit.
- [ ] **T-CFG-9 Notification-Routing** — Channel/Severity/Digest-vs-Realtime/Quiet-Hours je Event.
- [ ] **T-CFG-10 Integration-Config** — ServiceNow/SIEM/PowerBI/Ticketing on-off + Endpoints + Field-Mapping (H2).

### Backup & Restore (ADR-037)
- [ ] **T-BKP-1 Immutable Vault + Soft Delete + MUA/Resource-Guard** — Enabled+Locked nach Retention-Validierung; Resource Guard anderer Owner/Subscription.
      *DoD:* Löschversuch auf Recovery Point wird blockiert; MUA-Approval erforderlich; Retention erst validiert, dann gelockt.
- [ ] **T-BKP-2 Daily-Snapshot + PITR** je Datenklasse (DB, Config, Flag-Store); KV Soft-Delete/Purge/Backup.
- [ ] **T-BKP-3 Backup-Config-Domäne** mit hart kodierten Floors (Retention/Immutability/Encryption/MUA/Geo).
- [ ] **T-BKP-4 Automatisierter Restore-Drill** in isolierte Umgebung + Integritätsprüfung (geplant).
      *DoD:* Restore-Drill läuft grün, Report erzeugt.

### Deployment-Pattern (ADR-038)
- [ ] **T-DEP-1 Gehärtetes Module `entra-app`** + Variable-Schema (Secure Defaults: single-tenant, kein Implicit Flow, AssignmentRequired=true).
- [ ] **T-DEP-2 Root-Template + State-je-App** (backend-key als Init-Parameter); WIF/OIDC-Auth.
- [ ] **T-DEP-3 plan→approve→apply-Bindung** (`plan -out=tfplan`, planHash, `apply tfplan`, kein Re-Plan).
- [ ] **T-DEP-4 Brownfield-Import** (tfvars aus Live-Objekt + `import`-Block).
- [ ] **T-DEP-5 State-Backend** privat + Versioning + Immutable/Locked (koppelt T-BKP).
      *DoD:* CI beweist: kein Secret in State/Plan; azuread_application_password verboten.

### Business Registry & CMDB-Federation (ADR-039)
- [ ] **T-BAR-1 Business-App-Entity + Link-Tabelle** (1:n, Funktion je Link, Environment).
- [ ] **T-BAR-2 Zwei-Ebenen-Ownership** (Business-Owner als Gruppe + per-Identity db_owner).
- [ ] **T-BAR-3 Create-Flow-Pflichtfelder** (Business App + Funktion bei Anlage).
- [ ] **T-CMDB-1 Read-only Connector** (`cmdb_read`, OAuth, IP-Allowlist, Table API + Instance API).
- [ ] **T-CMDB-2 Matcher + Provenance** (Confidence-Schwelle, Vorschlag→Bestätigung, kein Blank-Overwrite).
- [ ] **T-CMDB-3 Coverage-Gap-Reports + Override-Log** (Identitäten ohne CI / CIs ohne Identitäten).
      *DoD:* EAGP schreibt nie ServiceNow; leeres CMDB-Feld überschreibt nie gepflegtes EAGP-Feld.

### Drift Control (ADR-040)
- [ ] **T-DRF-1 Duale Detektion + Korrelation** (`terraform plan` + `directoryAudits`).
- [ ] **T-DRF-2 Severity-Scoring** via Change-Klassifikator (ADR-022).
- [ ] **T-DRF-3 Revert-Flow** (Approval = Härte des Revert-Diffs; Fast-Path Containment).
- [ ] **T-DRF-4 Adopt-Flow** (Ticket optional + Grund Pflicht; erbt Härte; Deny-List nie; kein Selbst-Adopt).
- [ ] **T-DRF-5 Drift-Board + Reports** je App/Business App + Recurring-Eskalation.
      *DoD:* Emergency-Fallback-Drift wird als erwartet erkannt; Adopt einer High-Priv-Änderung erzwingt H3+Security.

### Target-System Entitlements (ADR-041)
- [ ] **T-ENT-1 Azure-RBAC-Verifier** — Resource Graph `AuthorizationResources` (SP-Assignments über Scopes) + PIM-Eligibility-Reader.
- [ ] **T-ENT-2 Azure-RBAC-Assign** (bounded Korridor at-and-below Governance-MG; Owner/UAA Deny-List; time-bound bevorzugt).
- [ ] **T-ENT-3 Intent-Modell + Reconciliation-Reports** (Over-Privileged/Undeklariert/Standing-High-Priv/…), Rollup je Business App.
- [ ] **T-ENT-4 Connector Power BI / SharePoint** (Verify+Declare; PowerBI Admin API, Graph Sites.Selected).
      *DoD:* Ist gegen API verifiziert (kein Textfeld); Owner@Root-Zuweisung wird verweigert.

### Executor Decomposition (ADR-042)
- [ ] **T-EXE-1 Executor-Definitionen (IaC)** — ~5 Executors, per-Executor App Reg + FIC.
- [ ] **T-EXE-2 Per-Executor CA for Workload Identities** (IP-Lock; NAT-Egress-IP je Runtime).
- [ ] **T-EXE-3 Runner-Isolation** — ACA-Jobs; Tier-0-Write in separater Environment + ephemer; Rest gemeinsam gehärtet.
- [ ] **T-EXE-4 Orchestrator ohne Resource-Rechte** + out-of-band Gating (planHash).
- [ ] **T-EXE-5 Anomaly-Baseline je Executor**.
      *DoD:* kein Executor hält kombiniert `.All`+RoleMgmt+UAA+KV; High-Priv-Token existiert nur im Job/PIM-Fenster.

## Welle 0/3 — CI/CD, Stack & FinOps (ADR-005 revidiert · ADR-043)

### Stack (ADR-005 revidiert)
- [ ] **T-STK-1 msgraph-sdk-Spike (Welle 0)** — kritische Ops gegen `msgraph-sdk` (Python) validieren: addPassword/addKey→KV, Admin-Consent-Grant, PIM-Schedule-Create, `directoryAudits`-Query, Resource-Graph-Query. Lücke → Direct-REST-Wrapper (kein PowerShell in Runtime).
      *DoD:* alle 5 Ops laufen aus Python; kein PowerShell im App-Container.

### CI/CD & Multi-Tenant (ADR-043)
- [ ] **T-CICD-1 Azure-DevOps-Multi-Stage-Pipeline** — CI → Dev → Gate → Prod; **WIF-Service-Connection je Tenant** (Dev/Prod, Entra-Issuer, secretless).
- [ ] **T-CICD-2 Test-Pyramide in CI** — pytest (mock) · `tfsec`/`checkov`/`conftest` auf Plänen (Deny-List, keine Secrets im State, `prevent_destroy`) · bandit/pip-audit/gitleaks/Container-Scan.
- [ ] **T-CICD-3 Dev-Tenant-Integrationstests** — echter App-Lifecycle/Cred-Rotation/Drift/RBAC im Dev-MG.
- [ ] **T-CICD-4 Environments + Approvals-Gate** + planHash-Review vor Prod.
- [ ] **T-CICD-5 Parität-/Capability-Detection + Prod-Canary-Routing** — parität-abhängige Tests (PIM, CA-for-WI) nur bei vorhandener Dev-Config, sonst Canary (report-only, Ring-Rollout).
- [ ] **T-CICD-6 VNet-Agents** — Self-hosted / Managed DevOps Pool mit VNet-Injection für Private-Endpoint-Zugriff.
      *DoD:* Prod-Deploy nur nach grünen Tests + Approval; kein Secret in Pipeline/State; Dev==Prod-Annahme technisch verhindert.

### FinOps / Lizenzen (ADR-043)
- [ ] **T-FIN-1 CA-Coverage-/Lizenz-Report** — welche SPs sind CA-for-WI-lizenziert (Workload ID Premium) vs. nicht; Empfehlung High-Risk-Targeting; P2 nur Approver-Pool.
      *DoD:* Report listet unlizenzierte High-Risk-SPs; keine tenant-weite Pauschal-Lizenzierung angenommen.
