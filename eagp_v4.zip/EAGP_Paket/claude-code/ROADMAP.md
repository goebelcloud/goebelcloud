# EAGP — Roadmap / Phasen-Schnitt

> Das Projekt muss nicht Hau-Ruck umgesetzt werden — die Sicherheitsrelevanz rechtfertigt
> mehr Zeit für eine gründliche Implementierung. Diese Roadmap ordnet den Scope in Phasen,
> sodass ein sicherer, lauffähiger Kern zuerst entsteht und der Rest darauf aufsetzt.

## Prinzipien der Reihenfolge

1. **Assessment vor Design-Finalisierung.** Read-only Tenant-Assessment
   (`scripts/eagp-assessment.ps1`) klassifiziert den Bestand in M/A/P/E und liefert die
   Guardrail-/Risiko-Baseline — bestimmt Scope-Größe und Tier-Verteilung.
2. **Harness vor Features.** CI-Gates, Fixtures und die Policy-Engine-Testsuite (die 4
   Sicherheits-Invarianten) zuerst — sonst driftet die Code-Generierung an den Guardrails
   vorbei.
3. **Sicherheitskern vor Komfort.** Identity Separation, Approval-Engine, Audit und
   Emergency-Revoke gehören in den MVP; Reporting-Breite und ITSM-Integration später.
4. **Managed vor Governed.** Erst der Tier-M-Lifecycle stabil und security-getestet, dann
   die Tier-A/P/E-Governance (setzt auf Discovery + Kernmechanik auf).
5. **Prod-Rollout ist selbst ein Testschritt** (Canary-Import), weil der Dev-Tenant die
   Prod-Realität nicht abbildet.

## Blocker

**ADR-008 (Executor-Modell, gehärtetes Weg B)** braucht Security-Freigabe und muss vor dem
Executor-Grant-Pfad (Build-Schritt 6/7) getroffen sein. Alles davor ist unabhängig baubar.

---

## Phase 0 — Fundament (Voraussetzung)

| Element | Inhalt |
|---|---|
| **Assessment** | `scripts/eagp-assessment.ps1` (Global Reader) → M/A/P/E-Klassifikation, App-Management-Policy-Stand, Lizenz-SKUs, Agent-ID-Stand |
| Prereqs | Entra ID P2, Workload ID Premium, Defender App Governance, Dev-Tenant, ZPA-App-Segment |
| Harness | CI-Gates (SAST/SCA/IaC/Secret-Scan/Doc-Drift), synthetische Brownfield-Fixtures, Policy-Engine-Testsuite, Dev-Tenant-Isolation-Guard |
| Plattform-IaC | Networking, Identitäten, PostgreSQL, Storage, KV, Service Bus, ACA, **Split-Sink-Logging** (Plan-only bis Review) |
| Governance-Setup | Art.-30-Eintrag, BR-Status, Pentest-Ressource, CDOC/Sentinel-Workspace-Klärung (Region/Tier/RBAC), Power-Platform-Governance challengen |

## Phase 1 — Sicherheitskern (MVP)

Ziel: ein sicherer, auditierter, freigabegesteuerter Kern für **Tier-M**-Apps (Greenfield).

| Feature | Warum MVP |
|---|---|
| Lifecycle (create/update/delete/restore) via Terraform, State pro App | Kernzweck (Tier M) |
| AuthN/AuthZ + Policy Engine (SEC-05), test-first | Sicherheitsfundament |
| App-Gruppen + Delegation (`OwnedBy` + Policy-Scoping) | Delegationsmodell |
| Approval-Engine (konfigurierbar) + Consent Approval Center | 4-Augen an der gefährlichsten Stelle (auch Tier-E-Fläche) |
| Credentials: FIC/Cert/Secret, KV-Storage, Expiry-Monitoring, Rotation | größter Alltagsnutzen |
| Cert-3-Klassen inkl. SAML-Signing-Cert-Monitoring/Rollover | Top-SSO-Ausfallgrund |
| **App Management Policies** (Secret/Cert-Guardrails, tenant-weit) | präventiver Guardrail gegen Credential-Sprawl (Entra ID Free) |
| Immutable Audit Log + Split-Sink-Routing | Nachweisbarkeit, Tier-0-Pflicht |
| Emergency-Revoke (Kill-Switch) | Incident-Response, Tier-0-Pflicht |
| Business-Owner-Modell (+ Sekundär) | Zuständigkeit, Notify-Ziel, R4-Basis |
| Configuration Backend (kritische Domänen) | Guardrails ohne Deployment änderbar |
| Credential-Expiry-Report (R1) + Permission-Risk-Report (R2) | unmittelbarer Governance-Wert |
| Notifications (Teams/Mail, Severity-Routing) | Betrieb |
| Naming/Tagging-Enforcement | Governance-Basis für Reports/FinOps |

**MVP-Abschluss-Gate:** Sicherheits-Invarianten-Tests grün, Security Testing (CI) grün,
**Pentest bestanden** vor produktivem Einsatz.

## Phase 2 — Governance-Ausbau (Tier A/P/E + Brownfield)

| Feature | Nutzen |
|---|---|
| **Tier-Discovery & Classification** (M/A/P/E) + Owner-Attribution | „nicht unsere Apps" sichtbar & zugeordnet |
| **Tier P**: App-Management-Policy-Compliance, Over-Privilege-/Secret-Hygiene-Flags, Recertify (Access Reviews) | NHI-Sprawl-Governance |
| **Tier A**: Agent-ID-Integration (Sponsor-SLA, hochpriv. Agent-Grants → T0, Inventar-Pane) | AI-Agenten-Governance ohne Reimplementierung |
| **Tier E**: Consent-Governance (User-Consent-Restriktion, App Consent Policies), Publisher-Verification, Defender-App-Governance-Risk-Reporting | Marketplace-/OAuth-App-Governance |
| Brownfield-Import (Tier M, 4-stufig, leerer-Plan-Gate, Canary-Rollout) | Übernahme der Bestands-Apps |
| Drift-Detection (FR-40/41) | Desired-State-Konsistenz |
| Out-of-Band-Detection (FR-45) | „Wer hat am Tool vorbei geändert" |
| Change-History (FR-66) + freie Ticket-Referenz | fachliche Nachvollziehbarkeit |
| Reporting-Breite: R3–R11 (inkl. R10 Identity Attribute Dependency + What-if) | vollständige Governance-Sicht |
| Attestation / Rezertifizierung | Access-Review-Nachweis (BSI C5 / ISO 27001) |

## Phase 3 — Erweiterung & Integration

| Feature | Nutzen |
|---|---|
| Cross-Service-Discovery (Azure RBAC, DevOps Service Connections, Power Platform) | „welche Rolle hat die App anderswo" |
| Validierte ITSM-Integration (ServiceNow) | Change-Management-Kopplung |
| **ServiceNow CMDB Reconciliation** (EAGP → CMDB, einseitig, über IRE; ADR-017/FR-80) | CMDB als Enterprise-SoR füttern: Attestation/Audit, Showback (Owner→Cost Center), Orphan-/Impact-Analyse |
| App-Dependency-Mapping (knownClientApplications / pre-authorized) | Impact bei Änderung/Löschung |
| Time-bound / JIT-Permissions für Apps (Auto-Expiry + Re-Approval) | Permission-Sprawl reduzieren |
| Policy-as-Code (OPA) für Guardrails | Governance-Reife |
| FinOps-Showback pro App-Gruppe (Tag-basiert) | Kosten-/Lizenz-Transparenz |
| DR-Ausbau (falls RTO/RPO strenger wird) | Resilienz |
| Git-Mirror der generierten TF-Config (PR-Review der Diffs) | Review-Komfort |

---

## Querschnitts-Disziplinen (alle Phasen)

- **Testing**: Unit test-first (Policy Engine); Integration/E2E nur gegen Dev-Tenant;
  Resilience/Chaos bewusst im Wegwerf-Tenant.
- **Security Testing**: SAST/SCA/IaC/Secret-Scan in CI ab Commit 1; Pentest als
  Release-Gate vor jedem Go-Live.
- **Dokumentation**: docs-as-code, generierte Doku CI-erzwungen; Runbooks als Living
  Documents.

## Grobe Sequenz (vereinfacht)

```mermaid
flowchart LR
    A0["Assessment\nM/A/P/E-Baseline"] --> P0["Phase 0\nFundament + Harness"]
    P0 --> P1["Phase 1\nSicherheitskern MVP (Tier M)"]
    P1 --> GATE{"Pentest\nbestanden?"}
    GATE -->|ja| PROD["Produktiver\nGreenfield-Einsatz"]
    PROD --> P2["Phase 2\nTier A/P/E-Governance + Import"]
    P2 --> P3["Phase 3\nErweiterung + Integration"]
    ADR["ADR-008 A/B\n(Management)"] -.blockiert Grant-Pfad.-> P1
```
