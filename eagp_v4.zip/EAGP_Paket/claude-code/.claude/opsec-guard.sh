#!/usr/bin/env bash
# EAGP PreToolUse OPSEC guard (Tier-0). Deterministic block of dangerous Bash commands
# BEFORE execution. Complements settings.json deny rules (defense in depth).
# Contract: reads the tool-call JSON on stdin; exit 0 = allow, exit 2 = block (stderr = reason).
set -euo pipefail
INPUT="$(cat)"
CMD="$(printf '%s' "$INPUT" | python3 -c 'import sys,json; print(json.load(sys.stdin).get("tool_input",{}).get("command",""))' 2>/dev/null || true)"

block() { echo "OPSEC-GUARD BLOCK: $1" >&2; exit 2; }

# 1) Never touch prod / real tenant / apply real infra
echo "$CMD" | grep -Eiq 'terraform +(apply|destroy)'            && block "terraform apply/destroy is human-only"
echo "$CMD" | grep -Eiq '(login\.microsoftonline\.com|graph\.microsoft\.com/v1\.0|graph\.microsoft\.com/beta)' \
    && block "no network to real Entra/Graph endpoints from the dev loop"
echo "$CMD" | grep -Eiq '\baz +login\b|\bConnect-MgGraph\b'      && block "no interactive cloud auth in the loop"

# 2) Destructive / irreversible
echo "$CMD" | grep -Eiq 'rm +-[a-z]*r[a-z]* +(/|~|\$HOME)'       && block "recursive delete of root/home"
echo "$CMD" | grep -Eiq 'git +push +(-f|--force)'               && block "force push"
echo "$CMD" | grep -Eiq '(drop +database|drop +table)'          && block "database drop"

# 3) Protect the security invariants + secrets + branch protection
echo "$CMD" | grep -Eiq '(tests/invariants|invariant)'          && grep -Eiq 'rm|mv|>' <<<"$CMD" \
    && block "no modification/deletion of invariant tests"
echo "$CMD" | grep -Eiq '\.env(\.| |$)'                         && block "no access to .env files"

# 4) Enforce feature-branch discipline (no commits straight to main)
echo "$CMD" | grep -Eiq 'git +checkout +main|git +switch +main'  && grep -Eiq 'commit' <<<"$CMD" \
    && block "commit on main forbidden; use a feature branch"

exit 0
