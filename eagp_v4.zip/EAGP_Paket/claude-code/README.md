# EAGP — Entra App Governance Platform

Zentrale, DSGVO-konforme Plattform zur **Governance aller App-Identitäten** in Microsoft
Entra: App Registrations und Enterprise Applications (Service Principals). Lifecycle,
Permissions, Credentials, SSO/SAML/OIDC, Delegation, Reporting und Out-of-Band-Erkennung —
über einen auditierten, freigabegesteuerten Workflow.

> **Tier-0-System.** Die Plattform kann bei Missbrauch den gesamten Tenant kompromittieren.
> Sicherheit hat Vorrang vor Funktionsumfang. Vor Beitrag: `CLAUDE.md`, dann `SPEC.md` lesen.

> **Reframe:** EAGP ist keine „App-Lifecycle-Verwaltung", sondern eine **Governance-Plattform
> mit einer verwalteten Teilmenge**. Der Großteil der App-Identitäten ist nicht unsere —
> sie werden *governt*, nicht *gemanaged* (siehe Tier-Taxonomie unten).

## App-Tier-Taxonomie (das Kernmodell)

Grundlage: **App Registration** (Definition, Home-Tenant) vs. **Service Principal** (lokale
Instanz in unserem Tenant).

| Tier | Beispiele | App Reg bei uns? | EAGP-Rolle |
|---|---|---|---|
| **M — Managed** | eigene LOB-Apps | ja | **Full Lifecycle** (Terraform) |
| **A — Agent** | Copilot Studio / Foundry AI-Agenten | Agent Identity | **Govern** via Entra Agent ID + ID Governance |
| **P — Platform-created** | Power Platform / D365 / Power BI SPs | teils | **Govern** (Guardrail, Attribuieren, Recertify) |
| **E — External/Consented** | Marketplace-/Multi-Tenant-SaaS | nein (nur SP) | **Govern** (Consent, Access, OAuth-Risk) |

Nur **Tier M** durchläuft den Terraform-Lifecycle. A/P/E werden erkannt, klassifiziert,
mit Owner attribuiert, per Guardrail (App Management Policies, Power Platform Governance,
Agent ID) gesichert und ins Reporting/Approval gezogen — **nie** lifecycle-verwaltet.

## Dokumente in diesem Paket

| Datei | Zweck | Zielgruppe |
|---|---|---|
| `CLAUDE.md` | **Handoff/Context für Claude Code** (Constraints, Stack, Tiers, Guardrails, Build-Order, Stand) | Claude Code / Entwickler |
| `SPEC.md` | Vollständige Build-Spezifikation (Anforderungen, ADRs, Guardrails) | Entwickler |
| `ROADMAP.md` | Phasen-Schnitt (MVP vs. Phase 2+) inkl. Tier-Governance | Projekt / Planung |
| `scripts/eagp-assessment.ps1` | Read-only Tenant-Assessment (Tier-Klassifikation, Guardrail-Baseline) | Architekt / Betrieb |
| `EAGP_Entscheidungsvorlage.docx` / `.pptx` | **Aktuelle** Management-Vorlage (Produkt, Nutzen, Sicherheit, Leistungskatalog, Entscheidungen M1–M6) | Management |

## Architektur (Überblick)

Vollständig **PaaS/serverless**, private-first. Die API/Oberfläche hält **keine** schreibenden
Graph-Rechte; Änderungen führt allein der abgeschottete **Executor** über Terraform aus (ein
State-File pro App). Secrets entstehen out-of-band via Graph und landen direkt im Key Vault —
niemals im Terraform-State, in Logs oder Telemetrie.

```mermaid
flowchart TB
    Admin["Admin / Team-Admin / Reader"]
    ZPA["Zscaler ZPA + Entra SSO (MFA)"]
    subgraph AZ["Azure - germanywestcentral, Private Endpoints"]
      FE["Frontend (React SPA)"]
      API["Management API (Python/FastAPI)\nkeine Graph-Write-Rechte"]
      EXEC["Executors (~5, least-privilege) (Container Apps Jobs)\nApp Reg + Workload Identity Federation"]
      WATCH["Out-of-Band Detector + Reporting + Notification"]
      SQL[("PostgreSQL Flexible Server - Metadaten")]
      ST[("Storage - TF-State pro App")]
      KV["Key Vault - Secrets/Certs"]
      AUD[("Immutable Audit (WORM)")]
    end
    GRAPH["Microsoft Graph"]
    SIEM["CDOC / Sentinel (Security-Sink)"]
    Admin --> ZPA --> FE --> API
    API --> SQL
    API --> EXEC --> GRAPH
    EXEC --> ST
    EXEC --> KV
    API --> AUD
    WATCH --> GRAPH
    WATCH --> SIEM
```

## Sicherheitsprinzipien (Kurz)

- **Privilege Separation** — API ohne Graph-Write; nur der Executor schreibt.
- **Secretless Executor** — App Registration + Workload Identity Federation; kein
  gespeichertes Secret; Conditional Access for Workload Identities.
- **Private-first** — alles über Private Endpoints, Zugang nur intern via ZPA + MFA.
- **4-Augen-Prinzip** — konfigurierbar; Application-type Permissions / Admin Consent über
  den T0-Pfad (ADR-008 gehärtetes Weg B, siehe `SPEC.md` §7).
- **Split-Sink-Logging** (ADR-015) — Security/Audit → CDOC/Sentinel; Ops → günstiger
  Workspace/Basic Logs; Immutable Audit → WORM-Storage. Nie Ops-Logs nach Sentinel.
- **App Management Policies** — präventiver Guardrail gegen Credential-Sprawl (Tier P/E).
- **Emergency-Revoke** — Kill-Switch für kompromittierte Apps.
- **EU/DSGVO** — Region `germanywestcentral`, Datensparsamkeit, definierte Retention.

## Tech Stack (ADR-005 revidiert — Terraform + Python)

| Ebene | Technologie |
|---|---|
| Deklaratives Provisioning (Entra app/SP/FIC, Azure RBAC) | **Terraform** (`azuread`/`azurerm`, gepinnt) |
| Anwendung + Graph-/Credential-/Verifikations-Ops | **Python** (FastAPI, `msgraph-sdk`, Azure-SDK, `azure-identity`) |
| Frontend | **TypeScript / React** (intern + Zscaler) |
| Runtime | **Azure Container Apps (Jobs)** — ephemer, VNet-integriert |
| Daten / Secrets / State | **PostgreSQL Flexible Server**, Key Vault, Blob (immutable TF-State) |
| UI | **React-Konsole** (primär); Teams (Approvals) & Power BI (Reports) als optionale Kanäle |
| Doku | Markdown / MkDocs (docs-as-code), Mermaid |

> **Hard Rule:** Graph via `msgraph-sdk` / direct REST — **nie** legacy AzureAD/MSOnline (retired).
> **Kein PowerShell in der Runtime** (App einsprachig Python); **kein .NET**.

## Repo-Struktur

```
/api               Management API (Python / FastAPI)
/executor          Terraform-Runner + Graph-/Credential-Ops (Container; Python)
/modules/          Terraform-Modul: entra-application (Tier M)
/platform-iac      Terraform für die Plattform selbst
/scripts           Python: Discovery, Classification, Recert, Assessment (optional standalone PowerShell)
/policies          App Management Policies, Consent Policies, Config-as-Code
/frontend          React/TypeScript Admin-Konsole (intern + Zscaler)
/docs              docs-as-code, ADRs, Diagramme
CLAUDE.md          Handoff/Context für Claude Code
SPEC.md            vollständige Spezifikation
ROADMAP.md         Phasen
```

## Getting Started (Dev)

1. **Tenant-Assessment ausführen:** `pwsh ./scripts/eagp-assessment.ps1` (Rolle: Global
   Reader). Output `00_SUMMARY.json` → Bestand in M/A/P/E klassifizieren, Baseline lesen.
2. **Prereqs prüfen:** Entra ID P2, Workload ID Premium, Defender App Governance,
   Power-Platform-Governance-Stand, Dev-Tenant, Zugriff (siehe `SPEC.md` Anhang A).
3. **Harness zuerst** aufsetzen (CI-Gates, Fixtures, Policy-Engine-Tests) — vor der ersten
   Fachfunktion (`SPEC.md` §15).
4. Plattform-IaC im **Dev-Tenant** ausrollen (`platform-iac`, Plan-Review Pflicht).

> Integrationstests laufen **ausschließlich** gegen den Dev-Tenant, nie prod. Der
> Dev-Tenant ist ein Wegwerf-Tenant: ideal für destruktive Resilience-Tests, bildet aber
> die Prod-Realität nicht ab (`SPEC.md` §11 NFR-04).

## Offene Grundsatzentscheidung

`ADR-008` (Executor-Modell, gehärtetes Weg B) braucht **Security-Freigabe**
und blockiert Teile des Executor-Modells. Details + Entscheidungsvorlage:
`EAGP_Management_Vorlage.docx/.pptx`, technisch in `SPEC.md` §7.
