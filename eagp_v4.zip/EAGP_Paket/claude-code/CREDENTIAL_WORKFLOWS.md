# CREDENTIAL_WORKFLOWS.md — API-Level-Workflows (technisches Backup)

> Die **konkreten Abläufe** hinter dem Credential-Handling, auf API-Ebene (Microsoft Graph +
> Key Vault). Die Management-Dokumente zeigen dieselben Workflows in Klartext-Schritten; hier
> die technische Referenz für Claude Code. Bezug: ADR-029/030/031/032/035, SPEC §6.2 (FR-10..17).

## 1. Client Secret — Create & Rotate (Zero-Downtime via Overlap)
Entra ist **Source of Truth** für die Secret-Erzeugung; Key Vault ist Ablage (ADR-030).

```mermaid
sequenceDiagram
    participant M as Expiry Monitor
    participant EX as Executor (Workload Identity Federation)
    participant G as Microsoft Graph (App Registration)
    participant KV as Key Vault
    participant DB as EAGP DB
    M->>EX: Client Secret expiring (30/14/3 days)
    EX->>G: POST addPassword (neues Client Secret)
    G-->>EX: secretText (Plaintext) — genau EINMAL
    Note over EX: Plaintext nur flüchtig im Memory
    EX->>KV: setSecret (neue Version, TLS, Private Endpoint)
    Note over EX: Memory-Variable verworfen (No-Store)
    EX->>DB: persist keyId + endDateTime (KEIN Plaintext)
    Note over G: beide Client Secrets gültig (Overlap-Fenster)
    EX->>EX: Consumer umstellen + verify
    EX->>G: POST removePassword (altes keyId) — eigener H2-Schritt NACH verify
```

## 2. Certificate — KV-native (Private Key verlässt Key Vault nie)
Bei Certificates ist der Key Vault führend; Entra bekommt nur den Public Key (ADR-030/035).

```mermaid
sequenceDiagram
    participant EX as Executor
    participant KV as Key Vault (HSM-backed)
    participant G as Microsoft Graph (App Registration)
    EX->>KV: createCertificate (Policy: exportable=false)
    Note over KV: Private Key entsteht im KV, verlässt ihn NIE
    KV-->>EX: Public Key / Certificate (nur öffentlicher Teil)
    EX->>G: POST addKey (Public Key)
    Note over G: App authentifiziert sich künftig per Certificate
```

## 3. Credential Re-Reveal (Owner hat Client Secret vergessen)
Wiederholter Reveal aus KV, H2, Owner-gebunden (ADR-029). Ersetzt „one-time only".

```mermaid
sequenceDiagram
    participant O as App Owner
    participant API as EAGP API
    participant PE as Policy Engine (AuthZ)
    participant KV as Key Vault
    participant AUD as WORM Audit
    O->>API: GET secret of App X
    API->>PE: caller == DB-owner? (NICHT ownedBy)
    PE-->>API: yes → require Step-up MFA + Justification (H2)
    O->>API: MFA + Justification
    API->>KV: getSecret (active version)
    KV-->>API: Plaintext (TLS)
    API-->>O: display, TTL ~15 min, No-Store (nicht cachebar)
    API->>AUD: reveal event (who/when/why) + Anomaly-Alert-Check
```

## 4. Chatbot Access (On-Behalf-Of, server-side AuthZ)
Bot ist Frontend, kein Berechtigungsträger (ADR-032).

```mermaid
sequenceDiagram
    participant O as App Owner (Chatbot)
    participant BOT as Chatbot
    participant API as EAGP API
    participant PE as AuthZ (server-side)
    O->>BOT: "Application (Client) ID of App X?"
    BOT->>API: call with On-Behalf-Of token (echte Owner-Identität)
    API->>PE: owner-check + Feature-Flag enabled? Kill-Switch off?
    PE-->>API: ok (low-sensitive)
    API-->>BOT: Application ID + Metadaten
    Note over API: Client Secret NUR über Re-Reveal (Workflow 3) — nie als Chat-Antwort
```

## Invarianten über alle Workflows (ADR-035)
- Client-Secret-Plaintext: **nur flüchtig im Executor-Memory** → direkt KV → verworfen. Nie State/DB/Log/Trace/Error.
- Certificate-Private-Key: **entsteht im KV, verlässt ihn nie**.
- Übertragung: **nur TLS**, nie in URL/Query. Reveal-Response **No-Store + TTL**.
- Terraform: `azuread_application_password` **verboten** (persistiert Plaintext im State).
- Rangfolge policy-erzwungen: **FIC > Certificate > Client Secret**.
