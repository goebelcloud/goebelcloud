# SPEC — Entra App Governance Platform (EAGP)

> Autoritative Build-Spezifikation für Claude Code. Vor jeglicher Code-Generierung
> vollständig lesen. Bei Konflikt zwischen einer Anforderung (FR/SEC/GDPR/DOC) und
> Bequemlichkeit gewinnt die Anforderung. Diese Spec ist die Source of Truth für
> Scope, Sicherheit und Architektur.

---

## 0. Status & offene Grundsatzentscheidung

**Ein einziger Punkt ist noch offen und blockiert Teile des Executor-Modells:**
`ADR-008` (Executor-Modell für High-Priv-Grants — gehärtetes Weg B, siehe §7).
Management-Entscheidung. Bis dahin ist die Spec so geschrieben, dass beide Wege
gebaut werden könnten; die betroffenen Stellen sind mit **`[A/B]`** markiert.

Alle übrigen Detailentscheidungen sind getroffen (siehe ADR-Tabelle) und bewusst
**konfigurierbar** ausgelegt (Configuration Backend, FR-70).

**Reframe:** EAGP ist keine „App-Lifecycle-Verwaltung", sondern eine **Governance-Plattform
mit einer verwalteten Teilmenge**. Der Großteil der App-Identitäten im Tenant ist nicht
unsere — sie werden *governt*, nicht *gemanaged* (siehe §5.5 App-Tier-Taxonomie, ADR-016).

**Vor Implementierung:** Read-only Tenant-Assessment ausführen (`scripts/eagp-assessment.ps1`)
→ klassifiziert den Bestand in M/A/P/E und liefert den Guardrail-/Risiko-Baseline (Anhang A).

---

## 1. Threat-Framing

EAGP ist ein **Tier-0-System**. Die ausführende Identität kann (je nach ADR-008)
Credentials an Applikationen hängen und Permissions grantieren — potenziell
tenant-übernahmefähig. Design-Entscheidungen sind gegen dieses Bedrohungsmodell zu
rechtfertigen, nicht gegen Feature-Bequemlichkeit.

Primäre Bedrohungen:
- **T1** Kompromittierung der Web/API-Schicht → Pivot zu tenant-weitem App-Takeover.
- **T2** Privilege Escalation durch delegierten App-Group-Admin (High-Priv-Grant/Consent).
- **T3** Secret-Leak über Terraform-State, Plan, Logs, Telemetrie.
- **T4** Insider-Missbrauch ohne Nachweisbarkeit.
- **T5** Drift: Out-of-Band-Änderungen am Portal invalidieren den Desired State.

---

## 2. Goals / Non-Goals

**Goals (Phase 1 / MVP-Kern):**
- Voller Lifecycle (create/update/delete/restore) von App Registrations + Service
  Principals via Terraform, ein State-File pro App.
- Volles Konfig-Spektrum: API-Permissions, App-Rollen, OAuth2-Scopes, Redirect-URIs,
  SSO (SAML + OIDC/OAuth), Claims-Mapping, Token-Konfiguration, Owner, Credentials
  (Federated Identity Credentials, Certificates, Client Secrets).
- App-Gruppen + Delegation an Entra-Security-Groups (server-seitig autoritativ).
- Zwei globale Rollen (`EAGP-Admins`, `EAGP-Readers`) + pro App-Gruppe delegierte
  Admin-Gruppen.
- Freigabe-Workflow (4-Augen, konfigurierbar) inkl. Consent Approval Center.
- Credential-Storage im Key Vault; Secret-Werte nie in State/DB/Logs.
- Drift- und Out-of-Band-Erkennung.
- Credential/Cert-Expiry-Monitoring + Notifications (Teams/Mail).
- Emergency-Revoke (Kill-Switch).
- Immutable Audit Log + fachliche Change-History.
- Business-Owner-Modell.
- Configuration Backend (FR-70).
- Brownfield-Import.

**Non-Goals (Phase 2+):**
- Cross-Service-Usage-Discovery (Azure RBAC, Azure DevOps Service Connections, Power
  Platform). Datenmodell erweiterbar vorsehen (`app_usage`), nicht implementieren.
- Multi-Tenant-Verwaltung (nur Home-Tenant in Phase 1).
- Validierte ITSM-Integration (ServiceNow) — MVP nutzt freie Ticket-Referenz.
- App-Dependency-Mapping (knownClientApplications/pre-authorized).
- Hot-DR / Multi-Region (Phase 1: Backup-basiert, siehe NFR-01).

---

## 3. Architecture Decisions (ADR-Übersicht)

| ADR | Entscheidung | Kern |
|---|---|---|
| ADR-001 (D1) | Secret-Reveal: **Hybrid** | KV-Referenz Default; auditierter One-time-Reveal (Justification, TTL ~15 min) |
| ADR-002 (D2) | Region: **germanywestcentral** | `eastus` = MUST NOT; DR/Geo siehe NFR-01 |
| ADR-003 (D3) | **Kein CMK** | Platform-managed Keys; begründet in GDPR-07 |
| ADR-004 (D4) | Generierte TF-Config: **Versioned Blob** | Generator autoritativ; Git-Mirror = Phase-2-Option |
| ADR-005 (revidiert) | Stack: **Terraform + Python** (einsprachige App; **kein PowerShell in der Runtime**, kein .NET) | App + Graph-/Credential-/Verifikations-Ops = Python (FastAPI, `msgraph-sdk`, Azure-SDK, `azure-identity`); deklaratives Provisioning = Terraform; Frontend = TS/React; PowerShell nur optionales Standalone-Assessment. msgraph-sdk (GA) deckt Graph-Ops ab → kleinere, auditierbare Codebasis |
| ADR-006 (D6) | Frontend: **Internal-only + Zscaler ZPA** | PE + Private DNS; CA bleibt unabhängig scharf; kein WAF |
| ADR-007 (D7) | Executor = **App Registration + Workload Identity Federation** | Secretless; CA for Workload Identities; Plattform-Apps auf Deny-List (kein Self-Mgmt) |
| **ADR-008** | **Executor-Modell (High-Priv-Grants)** | **RECOMMENDED — gehärtetes Weg B (B-timeboxed): Executor führt aus, kein stehendes Tier-0, JIT via time-boxed active SP-Assignment nach Team-PIM-Aktivierung; Tiered Approval (H2 Team / H3 Team+Security). Security-Freigabe offen. Fallback: „Weg A mit Team-Pool". Details: §7 + DECISIONS.md** |
| ADR-009 | Cert-Modell: **3 Klassen** | (1) self-signed EAGP-managed, (2) Custody für beigestellte, (3) Lifecycle-Orchestrierung für MS-SAML-Signing-Certs |
| ADR-010 | Credential-Verwaltung durch App-Group-Admins: **risiko-gestuft** | autonom bei harmlosen, approval-pflichtig bei potenten/kritischen Apps |
| ADR-011 | Approval-Modell: **konfigurierbar** | Approver-Pool + Quorum + optional Named-Required; Default 2-of-N für HIGH-T0; Pool = qualifizierte T0-Teilmenge |
| ADR-012 | Brownfield-Alt-Credentials: **gestuft** | Duldung mit überwachter Rotations-Frist |
| ADR-013 | Ticket-Pflicht: **überall optional, konfigurierbar** | pro Change-Typ × Kritikalität aktivierbar (Configuration Backend) |
| ADR-014 | Business-ID-Auflösung: **ausschließlich über Entra** | nie SailPoint/SAP direkt; Attributname = Config; Snapshot + Refresh |
| ADR-015 | Log-Sink-Topologie: **Split-Sink** | Security/Audit-Signale → zentraler CDOC/**Sentinel**-Workspace; Ops/Diagnostic → günstiger dedizierter Workspace oder **Basic Logs**, kurze Retention; Immutable Audit → WORM-Storage (separat). Nie Ops-Logs in einen Sentinel-Workspace (Sentinel bepreist alle ingested Daten) |
| ADR-016 | **App-Tier-Taxonomie M/A/P/E** | Nur Tier M = Full Lifecycle. Tier A (Agenten) → Entra Agent ID; Tier P (Plattform-SPs) → Guardrail/Attribuieren/Recertify; Tier E (Marketplace) → Consent/Access/Risk. Discover-Classify statt Lifecycle für A/P/E (siehe §5.5) |
| ADR-017 | **ServiceNow CMDB: Reconciliation (einseitiger Feed), kein bidirektionaler Sync** | EAGP = autoritative *discovery source* für einen App-Identity-CI-Slice; Push **über IRE** (Service Graph Connector oder IRE-REST-API), nie naiver Table-API-Insert; **Reconciliation-/Precedence-Rules** = EAGP autoritativ nur für eigene Attribute. **Optional, Phase 3, entkoppelt vom Control-Loop** (Kill-Switch/Approval nie CMDB-abhängig). Details §6.10 |

---

## 4. Architecture

Vollständig **PaaS/serverless**, private-first.

```mermaid
flowchart TB
    Admin["Admin / Team-Admin / Reader"]
    ZPA["Zscaler ZPA + Entra-Login (MFA)"]
    subgraph AZ["Azure - germanywestcentral, Private Endpoints"]
      FE["Frontend - App Service"]
      API["Management API (Python/FastAPI)\nRichtlinien, Rollen, Freigaben\n(keine Graph-Write-Rechte)"]
      EXEC["Executors (~5, least-privilege) - Container Apps Jobs\nApp Reg + WIF"]
      WATCH["Out-of-Band Detector + Reporting + Notification (Jobs)"]
      SB["Service Bus (Serialisierung pro App)"]
      SQL[("PostgreSQL Flexible Server - Metadaten")]
      KV["Key Vault - Secrets/Certs"]
      ST[("Storage - TF-State pro App")]
      AUD[("Audit-Log - append-only")]
    end
    GRAPH["Microsoft Entra / Graph"]
    TEAMS["Teams / Mail"]
    Admin --> ZPA --> FE --> API
    API --> SQL
    API --> SB --> EXEC --> GRAPH
    EXEC --> ST
    EXEC --> KV
    API --> AUD
    WATCH --> GRAPH
    WATCH --> TEAMS
```

> **Hinweis (ADR-042):** Der unten als „Executor“ gezeigte Schreib-Pfad ist in **~5 least-privilege Executors** zerlegt (Verifier · Lifecycle · Credential · Azure-RBAC · High-Priv), jeder mit eigener App Registration + FIC + Conditional Access. Das Diagramm zeigt die konzeptionelle Ebene.

### 4.1 Komponenten & Identitäten

| Komponente | Azure-Dienst | Identität | Notiz |
|---|---|---|---|
| Frontend | App Service (Linux) | Easy Auth (Entra SSO) | intern via ZPA, `publicNetworkAccess=Disabled` |
| Management API | Container Apps (**Python/FastAPI**) | System-MI, **Low-Priv**: SQL, SB-send, KV-Metadaten, Graph **read-only** | Policy Engine, RBAC, Approvals; Auth via azure-identity + msgraph-sdk (Python) |
| Executors (~5, ADR-042) | Container Apps **Jobs**, KEDA aus Service Bus | **App Registration + FIC je Executor** (secretless; MI nicht als agierende Identität) | Verifier / Lifecycle / Credential / Azure-RBAC / High-Priv — least-privilege; High-Priv nur JIT via PIM |
| Out-of-Band Detector | Container Apps Job (scheduled) | Read-Pattern wie API + State-Read | pollt `directoryAudits` (Watermark) |
| Reporting Engine | Container Apps Job (scheduled) | Read-only Graph + DB | täglicher Snapshot (Historie) |
| Notification Service | Teil API/Jobs | dediziertes Mail-Postfach (Application Access Policy) | Teams via Workflows-Webhook |
| Queue | Service Bus (Sessions) | — | Session-ID = App-Object-ID → Serialisierung pro App |
| Metadaten-DB | Azure Database for PostgreSQL Flexible Server | Entra-only Auth, Encryption-at-rest, PE | Metadaten/Cache/Gruppierung — **nicht** zweite Source of Truth |
| TF-State | Storage (Blob) | Entra-only (`use_azuread_auth`), Shared-Key disabled | `states/<app-object-id>/terraform.tfstate`, Versioning + Soft Delete |
| Secrets | Key Vault (RBAC-Modus) | Purge Protection, Soft Delete, PE | getrennt von Plattform-Infra-Secrets |
| Audit-Store | Storage, Append Blobs | Immutability Policy | getrennt vom operativen Log |
| Observability | Log Analytics + Defender for Cloud | — | EU-Region; Alerts auf privilegierte Ops |

### 4.2 Identity Separation (SEC-01, nicht verhandelbar)
- Web/API-Schicht hat **null** Graph-Write-Permissions (mitigiert T1).
- Executor ist die einzige Graph-schreibende Identität; Auth via WIF — **kein**
  gespeichertes Secret existiert.
- Executor via Conditional Access for Workload Identities geschützt (Standort-Lock auf
  ACA-Egress + risk-based Block). Lizenz: Workload ID Premium — verifizieren.
- Executor validiert jede Queue-Nachricht (Schema, Signatur, Approval-Referenz) und
  führt niemals Freitext aus.

### 4.3 Networking (NFR-NET)
- Alle Data-Plane-Dienste hinter Private Endpoints; Public Access disabled.
- Container Apps VNet-integriert; Egress via Firewall/NSG FQDN-Rules auf
  `login.microsoftonline.com`, `graph.microsoft.com`, Provider-Registry (ggf. Mirror).
- Frontend intern; Zugang via **Zscaler ZPA** (App Segment auf internen FQDN; Connector
  braucht Line-of-Sight zum PE). ZPA ≠ AuthN — Entra SSO + CA bleiben unabhängig scharf.
- TLS 1.2+ überall; HTTPS only; HSTS am Frontend.

---

## 5. Personas & Authorization

| Persona | Entra-Gruppe | Rechte |
|---|---|---|
| Platform Admin (EAGP-Admin/Hauptuser) | `EAGP-Admins` | **stehender Voll-Lese-/Schreibzugriff über gesamten Bestand aller Tiers** (Apps/Gruppen, Delegation, Policies, Approvals, Credentials inkl. Re-Reveal). **Owner-Bindung gilt NICHT** (ADR-034). H2 ausführbar (= Audit+Alert, keine Sperre). H3 nur über den PIM/JIT-T0-Pfad (ADR-008 gehärtetes B). |
| Reader | `EAGP-Readers` | read-only; keine Secret-Werte, nur Metadaten |
| App Group Admin | je App-Gruppe eine Gruppe (Mapping in DB) | CRUD **nur** in eigener Gruppe, gemäß Policy Engine; keine Delegation/Moves. **Owner-Bindung greift hier** (Secret-Reveal nur für eigene Apps). |
| T0-Approver | `EAGP-T0-Approvers` (**qualifizierte T0-Teilmenge**) | Freigabe hochprivilegierter Grants; entkoppelt von „ist T0" |

- **AUTHZ-01** Autorisierung server-seitig auf **jeder** mutierenden Anfrage. Frontend
  passt nur die UI an, ist nie Enforcement-Punkt.
- **AUTHZ-02** Gruppen-Claims aus Token; Group-Overage via `checkMemberGroups`
  auflösen; Membership-Cache max. 5 min.
- **AUTHZ-03** Jede mutierende Operation re-validiert, dass die Ziel-App zur
  App-Gruppe des Callers gehört. Kein Object-ID-Trust vom Client.
- **AUTHZ-04** User als **Object-ID** persistieren, nie UPN. UPN/Name nur zur Anzeige
  auflösen (GDPR-04).
- **AUTHZ-05 Owner-Bindung ist eine Scoping-Regel für den *delegierten* Pfad** (App Group
  Admin + Chatbot/OBO): Secret-Reveal/Metadaten nur für Apps, deren DB-`owner` (nicht
  `ownedBy`) der Caller ist. **Gilt nicht für Platform Admins** (ADR-034). Hart kodierte
  Untergrenzen (4 Invarianten + Deny-List-Self-Service) gelten für **alle**, auch Admins.

### 5.5 App-Tier-Taxonomie (ADR-016) — der Kern des Governance-Modells

Grundlage: **App Registration** (Definition, im Home-Tenant) vs. **Service Principal**
(lokale Instanz in unserem Tenant). Daraus vier Tiers mit **unterschiedlichem** Handling:

| Tier | Beispiele | App Reg bei uns? | EAGP-Rolle | Primär-Kontrollen |
|---|---|---|---|---|
| **M — Managed** | eigene LOB-Apps | ja | **Full Lifecycle** (CRUD via Terraform) | Terraform, Approval, WORM-Audit |
| **A — Agent** | Copilot Studio / Foundry AI-Agenten | Agent Identity (SP-Subtyp) | **Govern** via **Entra Agent ID** + ID Governance | Blueprints, Sponsors, Access Packages, Access Reviews, Blueprint-CA |
| **P — Platform-created** | Power Platform Connectors, D365 App Users, Power BI SPs | teils (First-Party-SP/App Reg) | **Govern** (Discover, Attribuieren, Guardrail, Recertify) — **kein Lifecycle** | App Management Policies, PP Managed Environments/DLP, Access Reviews |
| **E — External/Consented** | Marketplace-/Multi-Tenant-SaaS, Gallery | **nein** (nur SP; Definition beim Vendor) | **Govern** (Consent, Access, Risk) — **kein Lifecycle** | Consent Policies, Publisher Verification, Defender App Governance, CA |

- **TIER-01 (Discovery & Classification)** — Job (Python/msgraph-sdk) enumeriert alle
  Apps/SPs, klassifiziert nach `appOwnerOrganizationId` (Home-Tenant = M/P; Microsoft-Owner
  = First-Party; anderer = E) + erzeugender Identität/Tags/Publisher; persistiert
  `app_tier`. Basis-Erhebung: `scripts/eagp-assessment.ps1`.
- **TIER-02 (Owner/Sponsor-Attribution)** — auch Plattform/Agent-erzeugte Objekte brauchen
  einen menschlichen Owner/Sponsor (Mapping über PP-Environment-Owner, Dataverse-App-User,
  PBI-Workspace-Admin, Agent-Sponsor). Keine Orphan-NHIs.
- **TIER-03 (App Management Policies)** — höchster präventiver Guardrail (Entra ID Free).
  Getrennt `applicationRestrictions` (Tier M/P) vs. `servicePrincipalRestrictions`
  (Tier E, Multi-Tenant): Block-Password-Addition, max Secret/Cert-Lifetime, Trusted-CA.
  **Caveats:** greift nur auf *neue* Create/Update-Ops (bestehende Creds bleiben gültig →
  „erst Blutung stoppen"); Cert-Lifetime-Restriktion **trifft auch SAML-Signing-Certs**
  (Bezug FR-14 Klasse 3). Als Policy-Domäne im Configuration Backend (FR-70) verwaltet.
- **TIER-04 (Tier A — Agent ID)** — EAGP **reimplementiert Agent ID nicht** (GA 2026);
  es orchestriert/reportet darüber: Sponsor-Zuweisungs-SLA erzwingen, hochprivilegierte
  Agent-Grants in T0-Review routen, Agent-Inventar in dieselbe Reporting/Approval-Fläche
  ziehen, Agent-Aktivität in den CDOC/Sentinel-Sink korrelieren. Enumeration:
  `GET /servicePrincipals/microsoft.graph.agentIdentity`,
  `GET /applications/microsoft.graph.agentIdentityBlueprint`.
- **TIER-05 (Tier E — Consent & Risk)** — Governance = **Consent + Access + Risk**, nie
  Lifecycle (keine App Reg vorhanden). User-Consent restringieren, App Consent Policies
  (nur Low-Risk von verifizierten Publishern), Admin-Consent-Workflow → **Consent Approval
  Center (FR-32)** ist die Tier-E-Fläche. OAuth-Risk via **Defender for Cloud Apps App
  Governance** (Lizenz prüfen). Terraform-Reichweite hier: nur `azuread_service_principal`
  + Assignments + `..._delegated_permission_grant`, **nicht** die Definition.
- **TIER-06 (Anti-Pattern-Guard)** — Plattform/Agent-erzeugte Objekte **nicht** per
  Terraform-Import lifecyclen (kämpft gegen die Plattform, bricht bei Re-Creation). Zwei
  Tiers strikt trennen: *managed* (M) vs. *governed* (A/P/E).

---

## 6. Functional Requirements

### 6.1 Lifecycle
- **FR-01** App Registration + SP aus typisiertem Template (Form → validiertes Modell →
  generiertes Terraform → Plan → Approval falls nötig → Apply).
- **FR-02** Update jedes Attributs via Plan/Apply; keine direkten Graph-Writes für
  verwaltete Attribute.
- **FR-03** Delete = Soft-Delete in Entra; UI zeigt 30-Tage-Restore-Fenster + Restore.
  Hard-Delete (Purge) = Platform-Admin + Approval.
- **FR-04** Templates mit Secure Defaults: SAML-SSO, OIDC-Web, SPA, Daemon/API,
  Federated-Credential-Workload. Kein Implicit Flow, keine Wildcard-Reply-URLs,
  `requestedAccessTokenVersion=2`.
- **FR-05** Brownfield-Import (siehe §10).

### 6.2 Credentials
- **FR-10** Credential-Hierarchie policy-erzwungen: **FIC > Certificate > Secret**.
  Client Secret nur mit Justification, Cap 180 Tage; Cert 12 Monate.
- **FR-11** Secret-Werte werden vom Executor per **direktem Graph-Call** (`addPassword`
  **an der App Registration**) erzeugt (**Entra = Source of Truth**, ADR-030); Klartext
  existiert **nur flüchtig im Executor-Speicher**, wird **direkt in den Key Vault**
  geschrieben und danach verworfen; nur `keyId`/`displayName`/`endDateTime` in DB.
  **Nie via Terraform** (`azuread_application_password` persistiert den Wert im State —
  verboten, ADR-035). Der KV kann ein App-Reg-Secret **nicht** erzeugen und rüberschreiben.
- **FR-12** Expiry-Monitoring: täglicher Scan; Notifications 30/14/3 Tage an Business
  Owner. Getrennt: **SAML-Signing-Certs** (Klasse 3, Ablauf = SSO-Ausfall).
- **FR-13** Rotation = **Zero-Downtime-Overlap** (ADR-031): neues Credential erstellen →
  **beide gültig** → Consumer umstellen → verifizieren → **altes retire (eigener H2-Schritt
  nach Verifikation)**. Altes, noch aktives Credential wird **nie automatisch** entfernt.
- **FR-14 (Cert-Klassen, ADR-009)**:
  - *Klasse 1* self-signed via Key Vault, EAGP-managed, rotierbar (App-Auth). **KV erzeugt,
    Private Key bleibt im KV/HSM; Entra bekommt via `addKey` nur den Public Key** (ADR-030).
  - *Klasse 2* beigestelltes Cert: Custody (sicherer `.pfx`-Upload direkt in KV, nie
    über API-Logs; einmalig, auditiert); Herkunft/Chain = Verantwortung des Owners;
    Change-Record „Cert extern beigestellt".
  - *Klasse 3* MS-SAML-Signing-Cert: EAGP fasst es **nie** an; orchestriert nur
    Lifecycle (Monitoring, Rollover: neues Cert inaktiv bereitstellen → Umschaltzeitpunkt
    → RP-Notification). **Overlap erzwungen** (RP/AWS-Anbindung muss neues Cert kennen,
    bevor umgeschaltet wird).
- **FR-15 Credential Re-Reveal (ADR-029)**: wiederholter Reveal aus dem KV für **gültige,
  im KV liegende** Credentials (nicht mehr nur one-time). **H2**: nur DB-`owner` (+Secondary),
  Step-up-MFA + Justification + TTL, **jeder Reveal = WORM-Audit + Anomalie-Alert**. **Kein**
  Re-Reveal bei Custody/nur-Hash (Klasse 2). Owner-Bindung gilt für delegierte Rollen/Chatbot,
  **nicht** für EAGP-Admins (FR-06/Personas).
- **FR-16 Credential-History (ADR-031)**: aktive + historische Credentials — Metadaten immer
  (`keyId`, Erstell-/Ablauf-/Entfern-Datum, wer, warum), **Klartext nur** für aktive im KV.
  Overlap-Status („Rotation läuft: alt+neu") als sichtbarer Zustand.
- **FR-17 Klartext-Hygiene (ADR-035)**: Klartext-Secrets **nie persistiert**
  (Disk/State/DB/Queue/Log/Trace/Error/Telemetrie), **nie im Klartext übertragen** (nur TLS,
  nie in URL/Query). Rangfolge **FIC > Zertifikat > Client Secret** policy-erzwungen.
  Reveal-Response **No-Store**, TTL. Durchgesetzt via Log-/Exception-Scrubbing + CI-Secret-Scan,
  Private Endpoints, HSM-backed KV, Memory-Hygiene.

### 6.3 App Groups & Delegation
- **FR-20** CRUD App-Gruppen (Platform Admin). App gehört zu genau einer Gruppe
  (Default `unassigned`).
- **FR-21** Delegation-Mapping App-Gruppe → Entra-Security-Group (per Object-ID).
- **FR-22** App-Move zwischen Gruppen: Platform Admin + Approval.
- Scoping-Mechanik: Executor ist **Owner** nur der verwalteten Apps →
  `Application.ReadWrite.OwnedBy` deckt „nur meine Apps" ab, tenant-weit unmöglich. Die
  Policy Engine beschränkt jede Operation auf die App-Gruppe des Callers.

### 6.4 Approvals (konfigurierbar, ADR-011)
- **FR-30** Approval erforderlich (4-Augen, Approver ≠ Requester) für: Grants außerhalb
  Allowlist, Admin Consent, Delete/Purge, App-Group-Moves, Delegationsänderungen,
  Änderungen an Policies/Allowlist (Configuration Backend).
- **FR-31** Approvals sind First-Class-Objekte: gerenderte Plan-Summary, Requester,
  Approver, Zeitstempel, Entscheidung, Justification, **planHash** — alles auditiert.
  Approval an planHash gebunden (Approve-X-Execute-Y unmöglich); zeitlich begrenzt.
- **FR-32 Consent Approval Center**: offene `PermissionRequest`s **pro App gruppiert**,
  je Permission mit Risk-Tier; **selektiv** oder Batch approvebar (Default selektiv).
  HIGH-T0 **nie als „Approve all"**; Deny-List-Klasse nie über diesen Pfad grantbar.
  Freigabe direkt im Tool (kein Portal) — Ausführung gemäß **[A/B]**.
- Approval-Policy-Modell: Approver-Pool + Quorum (N) + optional Named-Required, frei pro
  Risiko-Tier. Deadlock-Validierung (Quorum ≤ verfügbare Approver), Selbst-Referenz-Sperre
  (Policy-Änderung braucht höchsten Pfad), Break-Glass-Vertreter.

### 6.5 Drift & Out-of-Band
- **FR-40** Scheduled Drift-Detection pro App (`plan -detailed-exitcode`, batched vs.
  Throttling). Attribut-Level-Diff.
- **FR-41** Reconcile: revert / adopt (mit Approval) / acknowledge. Drift auf
  Credentials/Permissions = HIGH.
- **FR-45 Out-of-Band-Detection**: Poll `auditLogs/directoryAudits` (Watermark,
  Intervall konfigurierbar). Korrelation `actor ≠ Executor-SP ∧ target ∈ managed` →
  Finding mit Wer/Wann + gezieltem Plan. Shadow-App-Detection (Create außerhalb →
  Import-Angebot). Änderungen an Plattform-Apps = CRITICAL. Dead-Man-Switch auf den
  Detektor (Retention Graph-Audit ~30 Tage → Catch-up-Logik).

### 6.6 Emergency-Revoke
- **FR-46 Kill-Switch**: kompromittierte App neutralisieren — alle Credentials entziehen
  + SP `accountEnabled=false`. **Nachgelagertes** (nicht vorgelagertes) Approval.
  **Grenze:** SP-Token-Revocation ist in Graph nur eingeschränkt möglich (Access Tokens
  leben bis Ablauf); Mitigation = kurze Token-Lifetime-Policy. Runbook muss das klarstellen.

### 6.7 Reporting (täglicher Snapshot, read-only)
- **FR-60** R1 Credential Expiry (inkl. SAML-Signing-Certs) · R2 Permission Risk (Tiers,
  Deltas) · R3 Credential Hygiene · R4 Stale/Orphaned (inkl. „Owner nicht auflösbar") ·
  R5 SSO/Config Hygiene · R6 Consent Risk · R7 OOB/Drift Summary · R8
  Governance-Abdeckung (managed vs. unmanaged) · R9 Platform Ops · **R10 Identity
  Attribute Dependency** (NameID/Claims/SCIM-Matching-Quellen; Impact-Tiers
  BREAKING/CORRUPTING/DEGRADING) + **What-if** für Attributänderungen · R11 Change-Report
  (pro App/App-Gruppe, **nie** pro Owner-Person — BR/Leistungskontrolle).
- Exporte (CSV/XLSX) auditiert; enthalten Owner-PII → GDPR-04/06.

### 6.8 Owner & Change (§ Datenmodell)
- **FR-65 Business Owner**: primär Person (Team-Zuweisung selten möglich) + optional
  sekundär (Eskalation/Vertreter). Felder `ownerObjectId` (Anker, Pseudonym),
  `ownerDisplayName` (PII), `ownerBusinessId` (PII, aus Entra-Attribut, Name via Config).
  Auflösung ausschließlich über Entra; Snapshot-Persistenz + Konsistenz-Refresh;
  Lifecycle-Löschung via R4. Sekundär-Owner für kritische Apps erzwingbar.
  **Keine Auswertung pro Owner-Person.**
- **FR-66 Change-History**: `ChangeRecord` je App — `changeType` (enum), `summary`
  (business-lesbar), `tickets[]` (n:m, optional), requester/approver, `planHash`/`auditRef`,
  `notes` (editierbar). Projektion über Audit-Events + fachliche Anreicherung; ersetzt
  Audit-Log **nicht**. Kein zweites ITSM.

### 6.9 Configuration Backend (Tier-0-Kontrollpunkt, ADR-033)
- **FR-70**: zentraler, **versionierter, approval-pflichtiger** Konfigurationsbereich für
  alle Policy-Domänen. **So mächtig wie die Aktionen, die er steuert** → Tier-0-Schutz.
  Config-**as-Code**, nicht mutable DB-Zeile; jede Änderung versioniert/rückrollbar/auditiert.
  Zugriff strikt getrennt (nur Admins/T0), App-Group-Admins nie; Config-Read selbst auditiert.
  **Domänen + Schutzklasse (Härte der Config-Änderung):**
  - *Security-kritisch* (Approval-Pool/Quorum, Härte-Kalibrierung H0–H3, Kritikalitäts-Definition,
    Deny-List) = **H3 + Selbst-Referenz-Sperre** (Regeln nicht über sich selbst absenkbar).
  - *Zugriff/Exposition* (Chatbot-Kill-Switch + Feature-Flags, API-Aktivierung, stehende-Rechte) = **H2**.
  - *Compliance/Daten* (Retention, Standard-Mappings, Read-Access-Log-Level) = **H2**.
  - *Operativ* (Notification-Routing, Report-Schedules, Cert-Expiry-Vorlauf) = **H1**.
- **FR-71 Hart kodierte Untergrenzen**: die **4 Sicherheits-Invarianten** + „Deny-List nie via
  Self-Service" sind **nicht konfigurierbar** — auch nicht mit Approval. **Fail-safe Defaults**:
  Config fehlt/unerreichbar → restriktivste Auslegung (nie fail-open).
- **FR-72 Laufzeit-Flag-Store**: sofort wirksame Kill-Switches/Feature-Flags **ohne Deployment**;
  **serverseitig durchgesetzt**; Autorisierung der Flag-Änderung dennoch über EAGP-Approval
  (kein „jeder mit Portal-Zugriff kippt das Flag").

### 6.9a EAGP-API & Chatbot (ADR-032)
- **FR-75 EAGP-API**: private, Entra-authentifizierte API; **kein Graph-Write** (wie UI —
  kein neuer privilegierter Pfad). Alle mutierenden Endpunkte laufen durch Policy Engine + Audit.
  Ermöglicht Automatisierung **durch** EAGP statt daran vorbei.
- **FR-76 Chatbot-Zugriff**: via **On-Behalf-Of** (echte Nutzeridentität, **nie** App-only-
  „für-alle"). **AuthZ gegen DB-`owner`** (explizit **nicht** `ownedBy`) + Secondary.
  Low-Sensitive (App-ID/Metadaten) direkt; **Secret-Klartext nur über FR-15 Re-Reveal (H2)**,
  nicht als Chat-Antwort. **Serverseitige AuthZ** (prompt-injection-resistent), Rate-Limiting,
  **keine tenant-weite Sicht** (Owner sieht nur eigene Apps).
- **FR-77 Abschaltbarkeit**: Master-Kill-Switch + **granulare Feature-Flags** über FR-72;
  Metadaten-Pfad ≠ Secret-Pfad **unabhängig** abschaltbar; **fail-safe** (aus/unerreichbar →
  verweigern); **Bot-Secret-Re-Reveal Default AUS**.

### 6.10 ServiceNow CMDB Reconciliation (FR-80, **optional / Phase 3**, ADR-017)

Ziel: die CMDB mit dem App-Identity-Bestand **füttern** (EAGP → CMDB), nicht bidirektional
synchronisieren. EAGP wird eine **autoritative discovery source** für einen klar
abgegrenzten CI-Slice; ServiceNow Discovery bleibt autoritativ für Infra-CIs.

- **FR-80.1 Feed über IRE**: Push **ausschließlich** über die Identification &
  Reconciliation Engine — via **Service Graph Connector** (IntegrationHub ETL/RTE → IRE)
  oder **IRE-REST/-Scriptable-API** (`createOrUpdateCIEnhanced`). **Nie** naiver
  Table-API-Insert auf `cmdb_ci*` (umgeht IRE → Duplikate, keine Reconciliation).
- **FR-80.2 Identification**: Identifier-Entry auf **stabilem Key** (`appId`/`objectId` als
  `object_id`/Source Native Key), damit Re-Runs matchen statt duplizieren.
- **FR-80.3 Reconciliation/Precedence**: EAGP ist per **Reconciliation-Rule** autoritativ
  **nur für die eigenen Attribute** (Tier M/A/P/E, Owner/Sponsor, Credential-Expiry,
  Permission-Risk-Tier, Consent-State, Publisher-Verifikation, Enabled, Last-Sign-in,
  Drift/OOB-Status, `managed_by_eagp`). Keine Hoheit über CI-Klassen anderer Sources.
- **FR-80.4 CI-Modellierung (CSDM)**: dedizierte CI-Klasse für App-Identities (Extension
  von `cmdb_ci`), Relation zu Business Application/Application Service und zu Owner
  (`sys_user`/Group). **Klasse + CSDM-Platzierung mit dem CMDB/Config-Management-Team
  abstimmen** — nicht unilateral anlegen (sonst CSDM-Drift, Health-Scan-Fehler).
- **FR-80.5 Nie pushen**: Secret-Werte (grundsätzlich), Immutable Audit (bleibt WORM in
  Azure), vollständige Permission-Dumps (verlinken statt kopieren).
- **FR-80.6 Connectivity/Auth**: Outbound EAGP → ServiceNow via MID Server (falls vom CMDB-
  Team gefordert) oder direktem Egress (FQDN-Allowlist auf Instanz-URL); OAuth2 mit
  **least-privilege Integration-User** (nur IRE/Import-API + Ziel-CI-Klasse), Credential im
  Key Vault. **Kein** Inbound-Schreibpfad CMDB → EAGP.
- **FR-80.7 Entkopplung**: der Feed ist Enrichment/Reporting, **kein** Bestandteil des
  Security-Control-Loops. Kill-Switch, Approvals und Drift dürfen **nie** von CMDB-
  Verfügbarkeit/-Aktualität abhängen. Der ServiceNow-Integration-User ist selbst eine zu
  governende Identität (Tier P/E).
- **DSGVO**: Owner-PII (`ownerDisplayName`/`ownerBusinessId`) liegt nach dem Push auch in
  ServiceNow → im Art.-30-Verzeichnis vermerken; Retention/Access über CMDB-Governance.
- **FinOps-Hinweis**: von Connectoren erzeugte CIs erhöhen den ServiceNow-Subscription-Unit-
  Verbrauch — mit ServiceNow abklären.

---

## 6a. Extended Capabilities (ADR-036–042 — Volltext & Rationale in `DECISIONS.md`)

Diese Fähigkeiten wurden in einer zweiten Design-Runde entschieden; hier die FR-relevanten Kernpunkte. Härte je Aktion folgt ADR-022; Bau-Welle siehe `FEATURE_PARITY.md`/`ROADMAP.md`.

**FR-CFG (ADR-036) Admin & Configuration Console.** UI over Config-as-Code (jede Änderung → versioniert, PR-gated, rückrollbar; keine mutable Settings-Tabelle). Toggles schalten **Features**, nie **Controls** (WORM-Audit, 4 Invarianten, AuthZ/Owner-Bindung, Deny-List, Fail-safe, Kill-Switch bleiben „locked by policy"). Config-Domänen mit Schutzklasse (Approval inkl. Vertretung H3+Self-Ref, Härte-Kalibrierung H3, Credential-Policy H2, Reports H1/H2, Feature-Flags H2, Integrationen H2, Retention nur über Legal-Floor H2). Report-Delivery **4 Modi** (Dashboard/On-Demand/Scheduled-Push mit Freq+TZ+Empfänger/Event-Triggered) + RBAC + Snapshots + Subscriptions. Two-Tier Config Plane (Config-as-Code Store + Runtime-Flag-Store, Kandidat Azure App Configuration).

**FR-BKP (ADR-037) Backup & Restore.** Data-Durability nach Datenklasse (Config-as-Code, Operational DB **PITR+Daily**, Audit/WORM, Key Vault Soft-Delete/Purge/Backup, Flag-Store). Drei Tier-0-Kontrollen: **Immutable Vault (Enabled+Locked/WORM)** + **Soft Delete (14–180d)** + **MUA/Resource-Guard** (anderer Owner/Subscription = Access-Trennung). Daily+PITR config-steuerbar (H2) mit **hart kodierten Floors**; Restore-Pfad + **automatisierte Restore-Drills**; EU-Residency (germanywestcentral, Immutable-Kopie Germany North); keine Klartext-Secrets in Backups.

**FR-DEP (ADR-038) Deployment.** Ein gehärtetes **data-driven Module** + Parameter-Datensatz je App (`tfvars.json`) + **State je App**; Tool schreibt **Daten, nie per-App-HCL**. `hashicorp/azuread` v3.x. Secrets-Split: App/SP/FIC=Terraform; **Client Secret nie TF** (→Graph `addPassword`→KV), Certificate=KV-native+`addKey`, High-Priv=gegateter PIM-Pfad. State-Backend privat+Immutable/Locked. Drift=`plan`; Brownfield=`import`; Auth=WIF/OIDC; **planHash-Bindung** (`plan -out`→approve→`apply tfplan`).

**FR-BAR (ADR-039) Business Registry + CMDB-Federation.** Business App = First-Class-Entity, EAGP-native führend; **1:n-Mapping mit Funktion** (SSO/SCIM/Automation/API); Zwei-Ebenen-Ownership (Business-Owner als Entra-Gruppe + per-Identity `db_owner`). CMDB **read-only, opt-in, defensiv**: ServiceNow führend, **EAGP schreibt nie zurück** (`cmdb_read`/OAuth/IP-Allowlist, Table API `cmdb_ci_business_app`); Provenance je Record; gematchte Records → ServiceNow überschreibt **gefüllte** Felder (**kein Blank-Overwrite**); nichts auto-linken; **Coverage-Gap-Reporting** als Primärnutzen; Sync Phase 3.

**FR-DRF (ADR-040) Drift Control.** Duale Detektion korreliert (`terraform plan` = Was + `directoryAudits` = Wer/Wann). Severity via Change-Klassifikator. **Revert** (Härte des Revert-Diffs) / **Adopt** (in Config-as-Code; **Ticket optional + Grund Pflicht**; erbt Härte; **Deny-List nie adoptierbar**; kein Selbst-Adopt). Emergency-Fallback-Routing; Auto-Revert konservativ (Human-in-Loop Default; Security → Auto-Contain). Drift-Board je App/Business App.

**FR-ENT (ADR-041) Target-System Entitlements.** Identity→Authorization-Plane. Tiers: **Manage** (Azure RBAC Schritt 1 + Graph + KV) / **Verify+Declare** (Power BI, SharePoint). **Verification-first** (real gegen API). Azure verify = Resource Graph `AuthorizationResources` (+ PIM-Eligibility); assign = ARM `roleAssignments`, **Write-Korridor at-and-below Governance-MG, nie `/`**; Reader H1/Contributor H2/Owner-UAA H3+Security; **Owner/UAA@Root = Deny-List**; time-bound bevorzugt. Intent-vs-Actual-Reports; Rollup je Business App.

**FR-EXE (ADR-042) Executor Decomposition.** ~5 Least-Privilege-Executors (Verifier read breit+stehend / Lifecycle OwnedBy / Credential KV+Graph / Azure-RBAC bounded / High-Priv JIT-nichts-stehend). Read breit / Write eng+gated. Per-Executor App Reg+FIC+CA (IP-Lock; MI ausgeschlossen → NAT-Egress-IP). Orchestrator ohne Resource-Rechte; Gating out-of-band (planHash). **Runtime = ACA Jobs**, Tier-0-Write in separater Environment + ephemer; Graph via CA-IP-Lock+CAE, KV/Storage/DB/ARM via Private Endpoints.

**FR-CICD (ADR-043) CI/CD & Multi-Tenant-Promotion.** Azure DevOps Pipelines; **secretless** via Workload Identity Federation (je Tenant eine Service Connection). **„Umgebung" = eigener Entra-Tenant:** erst gegen einen separaten **Dev-Tenant** deployen/testen, dann **Prod-Tenant**. Test-Pyramide: Unit (mock) · Policy (`tfsec`/`conftest` auf Plänen: Deny-List, keine Secrets im State) · SAST/SCA/Secret-/Container-Scan · echte **Integration im Dev-Tenant** · manuelle Freigabe → Prod. **Parität-Handling:** Capability-/Parität-Detection; parität-abhängige Tests (PIM, CA-for-WI, App-Mgmt-Policy) laufen nur wenn Dev die Config hat, sonst **Prod-Canary** (report-only, Ring-Rollout) statt False-Green. **Netzwerk:** private Ressourcen → **Self-hosted Agents / Managed DevOps Pool mit VNet-Injection**. **Lizenz/FinOps:** P2 **per-User** (Approver-Pool) + Workload ID Premium **per-SP** (Executors), nicht tenant-weit; Dev via Trials; EAGP reportet CA-Coverage.

## 7. Permission Approval & T0-Modell  [A/B]

**Ein Katalog, drei Konsumenten:** Deny-List (SEC-05), Default-Allowlist und
Report-Risk-Tiers speisen sich aus **einem** versionierten Permission-Katalog.

Risiko-Tiers:
- **LOW** (allowlisted, z. B. `User.Read`, `openid`, `profile`, `offline_access`) → kein
  Approval; effektiver Grant bevorzugt bereits tenant-weit vorkonsentiert.
- **MEDIUM** (breitere, nicht-übernahmefähige Scopes) → 4-Augen `EAGP-Admins`.
- **HIGH / T0** (Application-type Permissions, Admin Consent, Deny-List-Klasse:
  `Application.ReadWrite.All`, `Directory.ReadWrite.All`, `RoleManagement.ReadWrite.Directory`,
  `AppRoleAssignment.ReadWrite.All`) → T0-Pfad, **[A/B]**.

**Deny-List-Klasse ist über den delegierten App-Group-Flow niemals grantbar** (auch nicht
über das Consent Center) — sie erzwingt den vollen T0-Pfad.

```mermaid
flowchart TB
    start["Hochkritischer Grant (Application-type / Admin Consent / Directory-Rolle an SP)"]
    start --> q["Team-Quorum-Approval (planHash-gebunden); H3: + 1 Security"]
    q --> pim["Team-Mitglied aktiviert scoped Priv-Rolle via PIM (2. Mitglied approved + YubiKey + PAW via CA)"]
    pim --> tb["time-boxed ACTIVE Zuweisung fuer Executor-SP (z. B. 1 h) - kein stehendes Recht"]
    tb --> do["Executor fuehrt Grant aus"]
    do --> exp["Zuweisung laeuft automatisch ab -> wieder low-priv + WORM-Audit + Anomaly-Alert"]
```

**Kein binäres „Weg A vs. Weg B" mehr.** Die Achse ist *nicht* Mensch-vs-Maschine-Auth (eine
Workload Identity lässt sich stark härten), sondern **wo tenant-übernahme-fähige Macht *stehend*
liegt** — plus der verifizierte Fakt: ein **Service Principal kann nicht PIM-eligible** sein
(kein Self-Service-JIT für Maschinen), nur *stehend aktiv* oder *time-limited active*.

### Zielzustand — gehärtetes Weg B (B-timeboxed) · empfohlen
- Executor hält **kein stehendes Tier-0**; stehend nur `Application.ReadWrite.OwnedBy` + Read-Scopes.
- Für den seltenen High-Priv-Grant: **Team-Quorum-Approval** → Team-Mitglied **aktiviert scoped
  Priv-Rolle via PIM** (2. Team-Mitglied approved) → legt dem Executor-SP eine **time-boxed active**
  Zuweisung an (z. B. 1 h) → Executor führt aus → **Auto-Expiry** → WORM-Audit + Anomaly-Alert.
- **Executor-Härtung:** App Registration + **FIC (secretless)** · **CA for Workload Identities**
  (IP-Lock auf Pipeline-Egress, non-trusted Named Location) · **ID Protection + CAE** (Echtzeit-
  Revoke bei Risk/Disable/Delete → 401). *(Caveat: Managed Identities sind von CA for Workload
  Identities ausgeschlossen → App Reg + WIF korrekt; CAE nur gegen Graph; CA-Policy den SP direkt
  targeten, nicht via Gruppe.)*
- **Tiered Approval:** H2 (moderat, häufig) = **Team-Quorum (2)**; H3 (tenant-übernahme-fähig:
  `Directory.ReadWrite.All`, `RoleManagement.ReadWrite.Directory`, Directory-Rolle an SP) =
  **Team-Quorum + 1 Security/T0**; **Deny-List = nie per Self-Service**.
- **Approval↔Execution planHash-gebunden**, out-of-band-Approval-Plane (Key, den der Executor nicht besitzt).
- **Flaschenhals-Fix:** Team = PIM-eligible Approver-Pool (Quorum ≥2) → jedes qualifizierte Team-Paar
  kann handeln statt eines bestimmten verteilten T0.

### Fallback — „Weg A mit Team-Pool" (falls Security maschinelle Ausführung ablehnt)
Team-Mitglied führt den Grant im frisch aktivierten Fenster **selbst** aus; EAGP macht den Rest
(Assessment/Plan/Audit/Lifecycle). Kleiner Delta, **gleiche No-Standing-Eigenschaft**.

### Verworfen — B-standing
Executor hält **stehende** Grant-Rechte (`AppRoleAssignment.ReadWrite.All` + Directory-Rolle). Genau
die stehende Konzentration, die einen Control-Plane-Bug in eine Tenant-Übernahme verwandelt — kein
Grund dafür, sobald B-timeboxed existiert.

**Empfehlung:** gehärtetes Weg B (B-timeboxed) als Zielzustand; **Security-Freigabe offen** (ADR-008
revised in `DECISIONS.md`). Security-Rolle = Guardrails + periodische Audit-Oversight, nicht
Per-Transaction-Approval. **Plattform-eigene App Registrations stehen auf
der Deny-List — EAGP verwaltet sich nie selbst.**

---

## 8. Security Requirements

- **SEC-01** Identity Separation (§4.2). Kein Bauteil außer dem Executor hält Graph-Write.
  CI schlägt fehl, wenn IaC-Rollenzuweisungen das verletzen.
- **SEC-02** Keine Secret-Werte in State/Plan/Logs/Telemetrie/DB/Queue/Errors. **(ADR-035
  verschärft)** Klartext-Secrets **nie persistiert** und **nie im Klartext übertragen** (nur
  TLS, nie in URL/Query); Client-Secret-Klartext existiert nur **flüchtig im Executor-Speicher**
  → direkt KV → verworfen; Cert-Private-Keys **entstehen im KV und verlassen ihn nie**;
  Reveal/Re-Reveal **No-Store + TTL**; erzwungen via Log-/Exception-Scrubbing + CI-Secret-Scan,
  Private Endpoints, HSM-backed KV, `azuread_application_password`-Verbot.
  Log-Scrubbing-Middleware + CI-Check (Secret-Pattern) auf Plan-Output.
- **SEC-03** TF-State-Storage: Versioning, Soft Delete; Blob-Lease als State-Lock;
  Shared-Key disabled; RBAC via Entra; Executor einziger Writer.
- **SEC-04** Key Vault: RBAC-Modus, Purge Protection, Soft Delete, PE. Naming
  `app-<objectId>-<keyId>`. App-Group-Admins ohne direkten KV-Zugriff (Reveal via API).
- **SEC-05 Permission-Policy-Engine** mit Allowlist pro App-Gruppe + hartkodierter
  Deny-List (nicht approvebar via delegiertem Flow). Alles außerhalb → Approval.
- **SEC-06 Immutable Audit** (Append Blob + Immutability) für jede Secret-Lesung, jede
  mutierende Operation, jede Approval-Entscheidung, jeden Platform-Admin-Login.
  Event-Taxonomie: `actor` (Object-ID + Name-Snapshot), `action` (enum:
  `app.create`, `credential.reveal`, `permission.grant`, `approval.decide`, …), `target`,
  `context` (Justification, Approval-Ref, planHash), `result`, `timestamp`, `correlationId`
  (UI → API → Queue → Executor).
- **SEC-07** Conditional Access auf EAGP: phishing-resistente MFA, Compliant Device,
  erlaubte Standorte.
- **SEC-08** Break-Glass-Runbook: manueller Portal-Pfad + Notfall-Accounts, falls EAGP
  ausfällt; EAGP-Ausfall darf Incident-Response nie blockieren. Plattform-Identitäten
  über separaten minimalen Pfad (nie durch EAGP).
- **SEC-09** Supply Chain: gepinnte Terraform-/Provider-Versionen (exakt), Lockfiles
  committed, Container-Images aus interner Registry mit Scanning, SBOM in CI, kein `latest`.
- **SEC-10** Plattform-IaC via Pipeline mit **OIDC-Federation** (keine Pipeline-Secrets),
  Plan-Review + manueller Approval-Gate für prod.
- **SEC-11** Defender for Cloud aktiv; Alerts: Executor-Identität außerhalb ACA-Egress,
  ungewöhnliches Graph-Write-Volumen, KV-/State-Zugriffs-Anomalien.

---

## 9. GDPR / DSGVO

- **GDPR-01** Personenbezogene Datenkategorien (Art.-30-Verzeichnis, Anhang A):
  Owner-Identität (`ownerObjectId`, `ownerDisplayName`, `ownerBusinessId`),
  Change-Akteure (requester/approver Object-IDs + Name-Snapshots), Audit-Akteure.
- **GDPR-02 Residency**: alle Ressourcen in EU (`germanywestcentral`); Log Analytics
  gleiche Region. Graph-Daten im Tenant (EU Data Boundary — verifizieren). **Split-Sink
  (ADR-015):** ein ggf. gemeinsam genutzter CDOC/Sentinel-Workspace muss ebenfalls in der
  EU liegen, sonst bricht die Residency-Posture; Ops-Logs in günstigem EU-Workspace/Basic
  Logs, kurze Retention.
- **GDPR-03 Retention**: Ops-Logs 90 Tage; Audit 2 Jahre (Immutability), danach Löschung;
  Drift-Reports 180 Tage. Konfigurierbar (FR-70).
- **GDPR-04 Datenminimierung**: Object-IDs persistieren, Namen/UPN zur Anzeige auflösen.
- **GDPR-05 Erasure**: Audit-Logs während Retention von Löschung ausgenommen
  (Sicherheits-/Rechtspflicht, dokumentiert); übrige User-Referenzen dynamisch.
- **GDPR-06** Zugriff auf PII/Audit nur `EAGP-Admins`; Zugriff selbst auditiert.
- **GDPR-07 Encryption**: Platform-managed Keys (kein CMK, begründet).
- **GDPR-08** Microsoft als Auftragsverarbeiter über Tenant-AVV; keine externen
  Subprozessoren; keine externen SaaS-Calls aus der Plattform.
- **GDPR-09 Business Owner (personenbezogen)**: Zweck = Kontakt/Secret-Zustellung/Freigabe,
  Rechtsgrundlage Art. 6 Abs. 1 lit. f. `ownerBusinessId` = PII (personengebunden),
  persistiert, Löschung an Owner-Lifecycle (R4). **Keine Auswertung pro Owner-Person**
  (Leistungs-/Verhaltenskontrolle ausgeschlossen — BR-relevant). Art.-30-Eintrag +
  dokumentierter BR-Status = Go-Live-Voraussetzung.

---

## 10. Terraform & Import

- **TF-01** Ein Root-Modul-Instanz pro App; Backend-Key
  `states/<app-object-id>/terraform.tfstate`; `use_azuread_auth=true`.
- **TF-02** Modul `modules/entra-application`: `azuread_application`,
  `azuread_service_principal`, optional `azuread_application_federated_identity_credential`,
  `azuread_application_certificate`, `azuread_app_role_assignment`,
  `azuread_service_principal_delegated_permission_grant`, SAML-Settings, Claims-Policy.
  **Explizit NICHT**: `azuread_application_password` (FR-11). Alle Ressourcen `// VERIFY`
  gegen Provider-Doku.
- **TF-03** Config **generiert** aus dem Modell (Template + tfvars JSON), versioniert
  (Blob), reproduzierbar/deterministisch.
- **TF-04** Executor-Pipeline pro Op: Modell holen → Config rendern → `init` → `plan -out`
  → Policy-Checks auf Plan-JSON (SEC-05-Gate, Destroy-Protection) → `apply` des Plans →
  Post-Apply-Verify via Graph → Run-Record + gescrubbte Plan-Summary in Audit.
- **TF-05** `prevent_destroy` auf der Application-Resource; Delete = expliziter,
  approved Destroy-Run.

**Brownfield-Import (FR-05, ADR-012), vierstufig & abbruchsicher:**
1. **Discover** — Graph liest alle Apps/SPs; klassifiziert unmanaged / platform-owned
   (Deny-List) / managed. Read-only.
2. **Reconcile** — pro App Config aus Live-Zustand generieren; via `import`-Block in
   frisches State-File. Ownership setzen (Executor als Owner — privilegierter Bootstrap-
   Schritt, geht durch T0/Approval-Pfad).
3. **Verify** — `terraform plan` **muss leer sein**; sonst „import-pending". **Harte
   Abnahmebedingung.**
4. **Adopt** — erst nach leerem Plan „managed", DB-Metadaten + App-Gruppe, auditiert.
   Bestehende (wertunbekannte) Secrets: gestufte Rotations-Frist (ADR-012), koordiniert
   mit Owner, als Change-Record + Report-Kachel „Übernahme-Fortschritt".

**Canary-Prod-Rollout:** Import in prod in Wellen (erst unkritische Apps, leeren Plan
verifizieren, beobachten, dann skalieren) — kompensiert die Dev-Tenant-Realitätslücke.

---

## 11. Non-Functional Requirements

- **NFR-01 Availability/DR**: 99,5 % Ziel; single-region; RTO 8h / RPO 1h. **DR ist selbst
  zu designen** (Azure-managed Failover gepaarter Regionen ist keine primäre DR-Strategie;
  `germanynorth` ist zugriffsbeschränkt, nur GRS-Backup-Ziel). Konkret entscheiden: SQL
  (Backup vs. Failover-Group), Storage (GRS nach `germanynorth` vs. ZRS), Recovery-Runbook.
  Portal-Break-Glass (SEC-08) deckt Ausfälle. State + DB Backups Pflicht.
- **NFR-02 Scale**: Design für 1.000 Apps, 50 concurrent Nutzer; Drift-Scans batched
  (Graph-Throttling: Backoff, `Retry-After`, Delta-Queries).
- **NFR-03 Observability**: strukturierte Logs (Correlation-IDs), Dashboards (Expiring
  Credentials, Drift, Approval-Queue-Alter, Executor-Failures). **Split-Sink (ADR-015):**
  Security/Audit → CDOC/Sentinel-Workspace; Ops/Diagnostic → günstiger Workspace/Basic
  Logs (kurze Retention); Immutable Audit → WORM-Storage. Nie Ops-Logs nach Sentinel.
- **NFR-04 Testing** (siehe §12): Unit test-first für Policy Engine; Integration/E2E
  **ausschließlich gegen Dev-Tenant**, nie prod. Dev-Tenant = Wegwerf-Tenant: validiert
  Mechanik + Sicherheits-Invarianten vollständig, bildet **Prod-Realität nicht** ab.
  Kompensation: (a) synthetische Brownfield-Fixtures (leerer Plan erzwungen), (b) leerer
  Plan als Per-App-Gate im Prod-Import, (c) Canary-Rollout, (d) destruktives
  Resilience-Testing bewusst im Wegwerf-Tenant.
- **NFR-05 Environments**: dev (Dev-Tenant) / prod (Prod-Tenant); identische IaC,
  parametrisiert; keine geteilten Identitäten.
- **NFR-06 Kostenrahmen** (Größenordnung, US-Listenpreise): Infrastruktur **tuned
  ~80–180 €/Monat**, ungetuned bis ~300 €. Swing-Faktoren: **Log Analytics-Ingestion**
  (Analytics ~2,30 $/GB; via Split-Sink + Basic Logs steuerbar) und **SQL-Compute**
  (Serverless auto-pause vs. kleine provisioned Tier). **Floor:** private-first Networking
  (Private Endpoints ~7 $/PE/Mo + ACA-VNet) ≈ 60–100 €/Mo — bewusster Trade-off der
  Security-Posture. Lizenzen separat (P2, Defender App Governance, Workload ID Premium);
  App Management Policies = Entra ID Free. Vor Budget-Freigabe mit EA-Rabatt + realem
  Log-Volumen im Azure Pricing Calculator gegenrechnen.

---

## 12. Test- & Security-Strategie (Querschnitt, CI-erzwungen)

**Test-Pyramide:**

| Ebene | Fokus | Umgebung | Pflicht |
|---|---|---|---|
| Unit | Policy Engine, planHash, Approver≠Requester, Group-Scoping | Mocks | **härteste Pflicht** |
| Integration | Graph, Terraform, KV-Write, Service-Bus-Serialisierung | Dev-Tenant | Pflicht |
| Contract | Graph/azuread-Provider-Verhalten (Schema-Drift) | Dev-Tenant | empfohlen |
| E2E | create→declare→approve→grant→drift→import→delete→restore | Dev-Tenant | Release |

**Sicherheits-Invarianten (Unit, nicht verhandelbar) — Verweigerung erzwingen:**
1. Deny-List-Permission ist **nie** über den delegierten App-Group-Flow grantbar (auch
   nicht via Consent Center).
2. Approver == Requester → **immer** abgelehnt.
3. planHash ≠ ausgeführte Aktion → **immer** abgelehnt.
4. App-Group-Admin kann **keine** App außerhalb seiner Gruppe anfassen.
Fehlt eine davon als Test → Bug (CLAUDE.md-Guardrail).

**Weitere Kategorien:** Negative/Fehler, Boundary, Resilience/Chaos (State-Korruption →
Recovery, Executor-Crash mid-apply, Notification-Pfad tot), Idempotenz (Run 2× → kein
Diff, Import 2× → leerer Plan).

**Security Testing:** SAST + SCA/SBOM + Secret-Scanning + IaC-Scanning (Checkov/tfsec) je
PR in CI; DAST in Staging; STRIDE-Threat-Model in Design; **Pentest vor Go-Live**
(Ressource offen — Go-Live-Gate). **Pentest-Scope-Vorgabe** (sonst verfehlt ein
Standard-Pentest die tool-spezifischen Pfade): Approval-Gate-Bypass, horizontaler
Group-Breakout, vertikale Deny-List-Umgehung, planHash-Manipulation, Race Approve↔Execute,
Injection über App-Namen/Justification-Felder, Configuration Backend (FR-70) als
Angriffsfläche, Dev-Tenant-Isolation-Guard.

---

## 13. Guardrails für Code-Generierung (→ CLAUDE.md)

- Nie Graph-Endpoints oder Terraform-Attribute erfinden — gegen Doku verifizieren; bei
  Unsicherheit stubben und `// VERIFY` markieren.
- Nie Request/Response-Bodies loggen, die Credentials enthalten können.
- Nie Rechte einer Identität ausweiten „damit es läuft" — stattdessen laut scheitern.
- Alle Azure-Ressourcennamen über ein Naming-Modul; Pflicht-Tags erzwingen (Owner,
  Criticality, Environment, Cost Center).
- Jeder privilegierte Code-Pfad emittiert ein Audit-Event; fehlendes Audit = Bug.
- **Stack (ADR-005 revidiert):** App + Graph-/Credential-/Verifikations-Ops in **Python**
  (`msgraph-sdk`, Azure-SDK, `azure-identity`), deklaratives Provisioning in **Terraform**,
  Frontend **TS/React**. **Kein PowerShell in der Runtime, kein .NET.** **Nie** legacy
  AzureAD/MSOnline (retired) — Graph via msgraph-sdk / direct REST.
- Identity nur via `azure-identity`/`msgraph-sdk` (Python); keine eigene
  Token-Validierung/Claims-Parsing.
- Kommentare erklären **Intent/Constraints** („warum"), nie den Code nacherzählen.
  Nacherzählende Kommentare = Review-Defekt.
- Änderungen an Identitäten/Datenflüssen/Berechtigungen brauchen ADR-Referenz.
- Dev-Tenant-Isolation-Guard: Executor verifiziert Ziel-Tenant-ID = Dev-Tenant in
  Test-Kontexten.

---

## 14. Dokumentation (DOC-Block)

- **DOC-A Entwickler**: docs-as-code (`/docs` im Repo, Review im selben PR); ADRs
  (D1–D7 + ADR-008..014); generierte Doku hat Vorrang (OpenAPI, DB-Schema,
  Permission-Katalog) — CI failt bei uncommitted Diff; Linter (ruff/PSScriptAnalyzer/tflint) erzwingt Naming +
  Doc-Comments auf public members; C4-Diagramme (Mermaid); Day-1-Setup + Fresh-Eyes-Test.
- **DOC-B Bediener**: task-orientierte Guides pro Persona; In-App-Kontexthilfe
  (Deep-Links, Link-Checker in CI); Runbooks (CRITICAL-Finding, Executor-Ausfall,
  Break-Glass, Emergency-Revoke); Publishing via MkDocs (Markdown) intern hinter ZPA,
  Doku-Version = Release-Tag; Release Notes aus Conventional Commits.
- **Anti-Pattern**: manuell gepflegtes Wiki neben dem Code → veraltet, wird irreführend.
  Eine Quelle (Repo), ein Build, eine Site.

---

## 15. Build Order (für Claude Code)

0. **Read-only Tenant-Assessment** (`scripts/eagp-assessment.ps1`) ausführen → Bestand in
   M/A/P/E klassifizieren, Guardrail-/Risiko-Baseline lesen (Anhang A). Input für ADR-008
   und die Tier-Scope-Größe.
1. Repo-Scaffold: `/api` (Python/FastAPI), `/executor`, `/modules/entra-application`,
   `/platform-iac`, `/scripts` (Python; optional standalone PowerShell), `/policies` (Config-as-Code),
   `/frontend` (thin, optional), `/docs`, `CLAUDE.md` (Guardrails §13 als Hard Rules).
2. **Harness zuerst**: CI-Gates (SAST/SCA/IaC/Secret-Scan/Doc-Drift), Test-Fixtures
   (synthetische Brownfield-Apps), Policy-Engine-Testsuite (die 4 Invarianten),
   Dev-Tenant-Isolation-Guard. **Vor der ersten Fachfunktion.**
3. Plattform-IaC-Skeleton (Networking, Identitäten, PostgreSQL, Storage, KV, Service Bus, ACA;
   **Split-Sink-Logging** ADR-015) — Plan-only bis Review.
4. Datenmodell + Migrations (apps, app_groups, delegations, approvals, runs,
   drift_findings, audit_refs, owners, change_records, permission_requests, config,
   **app_tier**, **agent_refs**).
5. AuthN/AuthZ + Policy Engine (SEC-05) — **Unit-Tests zuerst**.
6. Terraform-Modul + Executor-Job (Happy Path: Tier-M-App create aus Template).
7. Approval-Workflow + Consent Center + Audit-Pipeline.
8. Credentials (FR-10..14).
9. Drift + Out-of-Band + Emergency-Revoke.
10. **Tier-Governance** (§5.5): Discovery/Classification M/A/P/E, Owner-Attribution, App
    Management Policy-Verwaltung, Agent-ID-Integration, Tier-E Consent/Risk-Reporting.
11. Brownfield-Import (Tier M) + Reporting + Notifications + Configuration Backend.

> **ADR-008 (Executor-Modell, gehärtetes Weg B) braucht Security-Freigabe vor Schritt 6/7** — es bestimmt das
> Executor-Berechtigungsmodell und die Ausführung des Consent Center.

---

## Anhang A — Prerequisites / offene Klärungen

| Punkt | Status |
|---|---|
| ADR-008 Executor-Modell | **Security-Freigabe offen (gehärtetes Weg B empfohlen)** |
| **Read-only Tenant-Assessment** ausführen | `scripts/eagp-assessment.ps1` (Global Reader) → M/A/P/E-Klassifikation + Baseline |
| Entra ID **P2** (PIM, Access Reviews, Agent-ID-Governance) verfügbar? | verifizieren (PIM-Pfad für ADR-008 + Tier-A/P-Governance) |
| **Defender for Cloud Apps – App Governance** verfügbar? | verifizieren (Tier-E OAuth-Risk) |
| **Power Platform Governance** (Managed Environments, DLP, Tenant Isolation, wer erstellt Agenten/Connectors?) | beim PP-Verantwortlichen challengen (Tier-P-Quelle) |
| **App Management Policy-Stand** (`GET /policies/appManagementPolicies`) | Default = „keine Restriktion" = Risiko; im Assessment enthalten |
| **Agent ID Enablement** (Copilot Studio pro Environment; Agent Registry) | evaluieren (Tier A); im Assessment enthalten |
| **Log-Sink-Topologie** (ADR-015): CDOC/Sentinel-Workspace vorhanden? Region EU? Commitment Tier? RBAC? | mit CDOC/Security klären |
| Workload ID Premium verfügbar/beschaffbar? | verifizieren (Executor-Härtung) |
| `ownerBusinessId` Attributname + Typ (Extension vs. Custom Security Attribute) | nachliefern → Config; ggf. `CustomSecAttributeAssignment.Read.All` |
| Pentest-Ressource (intern/extern) | Go-Live-Gate; mit Security klären |
| BR-Status + Art.-30-Eintrag (Business Owner) | Go-Live-Voraussetzung |
| DR-Konzept (SQL/Storage/Runbook) | NFR-01 entscheiden |
| EU Data Boundary für Graph-Daten | verifizieren |
