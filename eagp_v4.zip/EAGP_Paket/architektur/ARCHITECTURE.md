# EAGP — Architektur-Überblick

**Entra App Governance Platform · für Team & technische Leitung**

Dieses Dokument zeigt, *wie EAGP funktioniert*: welche Bausteine es gibt, wie sie miteinander kommunizieren, wie die Executors aufgesetzt sind, welche Technologie wo/wann läuft, und wie die App selbst aufgebaut ist. Bewusst **kein** API-Call-Deep-Dive — sondern das Gesamtbild. Die vollständigen Entscheidungen stehen in `DECISIONS.md` (ADR-001…043), die fachliche Spezifikation in `SPEC.md`.

---

## 1. Was EAGP ist (in zwei Sätzen)

EAGP ist das zentrale, interne **Governance- und Control-Plane-Werkzeug** für *alle* App-Identitäten im Microsoft-Entra-Tenant — App Registrations **und** Enterprise Applications (Service Principals). Es ist so vollständig gedacht, dass niemand mehr für Routine-Aufgaben ins Azure-Portal muss, und es wird selbst als **Tier-0-System** behandelt (höchste Kritikalität), weil ein Werkzeug, das alle App-Identitäten verwalten kann, selbst hochkritisch ist.

**Leitprinzipien, die die ganze Architektur prägen:**

| Prinzip | Bedeutung in der Architektur |
|---|---|
| **Gewaltenteilung** | Die Bedien-Oberfläche hat *keine* Schreibrechte auf Entra. Nur streng getrennte, minimal-berechtigte Executors ändern etwas. |
| **Secretless** | Ausführende Identitäten nutzen Workload Identity Federation (FIC) — kein Client Secret, das gestohlen werden könnte. |
| **Private-first** | Kein öffentlicher Zugriff; interne Erreichbarkeit, Private Endpoints, IP-gebundene Executors. |
| **Least Privilege + JIT** | Nur die harmlosen Rechte sind dauerhaft; die gefährlichsten existieren nur in einem zeitlich begrenzten, freigegebenen Fenster. |
| **Alles nachweisbar** | Unveränderliches (WORM) Audit; jede Änderung ist attribuierbar. |

---

## 2. Architektur auf einen Blick (System-Kontext)

```mermaid
flowchart TB
    subgraph users["Nutzer (intern, MFA, Zscaler)"]
      PLAT["Plattform-Team"]
      OWN["Fachbereichs-Owner"]
      CHAT["Chatbot-Nutzer"]
    end

    subgraph eagp["EAGP (Tier-0, privat)"]
      UI["Admin-Konsole (React)"]
      API["API / Backend (Python/FastAPI)"]
      ORCH["Orchestrator (hält KEINE Rechte)"]
      EXE["Executors (mehrere, least-privilege)"]
      DATA[("PostgreSQL + Key Vault + Config Store")]
    end

    subgraph targets["Ziel- & Nachbarsysteme"]
      ENTRA["Microsoft Entra (Graph)"]
      ARM["Azure Resource Manager / RBAC"]
      SNOW["ServiceNow CMDB (read-only)"]
      SIEM["Sentinel / SIEM (Audit-Sink)"]
    end

    PLAT & OWN --> UI
    CHAT --> API
    UI --> API --> ORCH --> EXE
    API <--> DATA
    EXE -->|deklarativ + imperativ| ENTRA
    EXE -->|RBAC im Korridor| ARM
    API -->|Federation, read-only| SNOW
    API -->|WORM-Events| SIEM
```

**Kernaussage:** Der Datenfluss geht immer über die API → Orchestrator → **Executor**. Die UI redet nie direkt mit Entra. Die gefährliche Fläche (Schreiben auf Entra/Azure) ist auf kleine, isolierte Executors konzentriert.

---

## 3. Logische Bausteine (Komponenten)

```mermaid
flowchart LR
    subgraph fe["Frontend"]
      RE["React-SPA<br/>(intern, Zscaler)"]
    end
    subgraph be["Backend (Python)"]
      APIG["API / AuthZ / RBAC"]
      WF["Approval- & Workflow-Engine"]
      REC["Reconciliation- & Drift-Engine"]
      REP["Report- & Delivery-Engine"]
      CFG["Config-Backend (Kill-Switch, Flags)"]
      BOT["Chatbot-Endpoint (On-Behalf-Of)"]
    end
    subgraph ex["Execution Plane"]
      ORCH["Orchestrator"]
      V["Verifier (read)"]
      L["Lifecycle (write, eng)"]
      C["Credential (KV + Graph)"]
      R["Azure-RBAC (bounded)"]
      H["High-Priv (JIT)"]
    end
    subgraph st["State & Secrets"]
      DB[("PostgreSQL<br/>Flexible Server")]
      KV[("Key Vault")]
      TF[("Terraform State<br/>(Blob, immutable)")]
      AUD[("WORM Audit")]
    end

    RE --> APIG
    APIG --> WF & REC & REP & CFG & BOT
    WF --> ORCH
    REC --> ORCH
    ORCH --> V & L & C & R & H
    APIG --> DB
    C --> KV
    L & R & H --> TF
    APIG --> AUD
```

| Baustein | Aufgabe |
|---|---|
| **React-SPA** | Interne Admin-Konsole. Zeigt Bestand, Status, Workflows; löst *Anträge* aus, ändert selbst nichts direkt. |
| **API / Backend** | Herzstück. AuthZ (Personas + Owner-Bindung), Geschäftslogik, DB-Zugriff, Orchestrierung. |
| **Approval-/Workflow-Engine** | Setzt die gestufte Freigabe (H0–H3) um; Quorum, Vier-Augen, PIM-Anbindung. |
| **Reconciliation-/Drift-Engine** | Korreliert Soll (Terraform-Plan) mit Ist (Audit-Logs); erzeugt Drift-Einträge. |
| **Report-/Delivery-Engine** | Erzeugt Reports; liefert sie (Dashboard / On-Demand / geplant / ereignisbasiert). |
| **Config-Backend** | Feature-Flags, Kill-Switches, Policy-Kalibrierung — als Config-as-Code mit Oberfläche. |
| **Chatbot-Endpoint** | On-Behalf-Of-Zugriff; sieht nur die Apps des angemeldeten Nutzers; serverseitig gegated. |
| **Orchestrator** | Routet Arbeit an den *richtigen* Executor. Hält selbst **keine** Ressourcen-Rechte. |
| **Executors (×5)** | Die einzigen Identitäten mit Rechten auf Entra/Azure. Siehe §5. |

---

## 4. Technologie-Stack — was wo läuft

| Schicht | Technologie | Rolle | Warum |
|---|---|---|---|
| **Deklaratives Provisioning** | **Terraform** (`azuread`/`azurerm` v3.x/4.x) | App/SP/FIC anlegen & ändern, Azure-RBAC zuweisen | Org-Default; reifster Weg für „Entra-as-Code"; State = Basis der Drift-Erkennung |
| **Anwendung + imperative Ops** | **Python** (FastAPI, `msgraph-sdk`, Azure-SDK, `azure-identity`) | API, Orchestrator, Workflows, Reconciliation, Credential-Ops (addPassword/addKey→KV), Consent, PIM, Verifikation | Eine Sprache für App **und** Graph-Ops → kleine, auditierbare Codebasis, ein Testframework |
| **Frontend** | **TypeScript / React** | Interne Admin-Konsole | Web-Standard; intern + Zscaler (ADR-006) |
| **Runtime** | **Azure Container Apps (Jobs)** | Ausführung der Executors (on-demand & geplant) | Serverless, VNet-integriert, per-Executor-Identität, ephemer — **kein AKS nötig** |
| **Datenbank** | **Azure Database for PostgreSQL Flexible Server** | Operational State (Inventar, Owner, Credential-*Metadaten*, Approvals, Config) | PITR, Immutable-Backup, Private Endpoint |
| **Secrets** | **Azure Key Vault** | Client Secrets, Certificate-Private-Keys | Private Key entsteht *im* KV, verlässt ihn nie |
| **IaC-State** | **Blob Storage** (versioniert, immutable/locked) | Terraform-State je App | Private, WORM, State-Locking |
| **Audit** | **WORM-Store + Sentinel/SIEM** (Split-Sink) | Unveränderliche Nachweise + Security-Signale | Compliance (ISO/TISAX/C5), Manipulationssicherheit |
| **CI/CD** | **Azure DevOps Pipelines** | Build/Test/Deploy nach Dev- → Prod-Tenant | secretless via Workload Identity Federation |

**PowerShell** ist **nicht** Teil der Runtime. Die gesamte App ist einsprachig (Python); ein optionales read-only Assessment-Skript kann als Standalone-PowerShell existieren, ist aber Kür.

---

## 5. Die Executors — das Kern-Sicherheitskonzept

Statt **einer** übermächtigen Maschine (die genau der „super-mächtige Service Principal" wäre, den EAGP verhindern soll) gibt es **mehrere schwache** — jeder nur mit dem Minimum für seine Funktion. So ist eine Kompromittierung eines Executors *begrenzt* schlimm, nicht katastrophal.

```mermaid
flowchart TB
    ORCH["Orchestrator — hält KEINE Rechte, routet nur"]
    APPR["Out-of-band Approval + planHash"]

    ORCH -->|read/report| V["① Verifier<br/>Graph-Read, Resource-Graph<br/>breit + stehend · low risk"]
    ORCH -->|eigene App| L["② Lifecycle<br/>Application.ReadWrite.OwnedBy<br/>H0–H1"]
    ORCH -->|Credential| C["③ Credential<br/>Key Vault + Graph addKey/addPassword<br/>H1–H2 · KV NUR hier"]
    ORCH -->|RBAC im Korridor| R["④ Azure-RBAC<br/>roleAssignments, bounded auf MG-Korridor<br/>H2–H3"]
    ORCH -->|High-Priv| H["⑤ High-Priv Grant<br/>NICHTS stehend · time-boxed via PIM<br/>H3"]

    APPR -. erforderlich .-> R
    APPR -. erforderlich .-> H
```

| # | Executor | Stehende Rechte | Plane | Härte | Kompromittierung ergibt |
|---|---|---|---|---|---|
| ① | **Verifier** | Graph-Read, ARG-Reader, read-only extern | Read (breit) | — | Information Disclosure — **kein** Write, keine Übernahme |
| ② | **Lifecycle** | `Application.ReadWrite.OwnedBy` (nur eigene Apps) | Write (eng) | H0–H1 | Manipulation *eigener* Apps, keine fremden |
| ③ | **Credential** | KV-Zugriff + Graph auf owned Apps | Write (Credential) | H1–H2 | Credential-Ops isoliert; nur hier sieht jemand den KV |
| ④ | **Azure-RBAC** | `roleAssignments`, gebounded auf Governance-MG | Write (Azure) | H2–H3 | RBAC nur im Korridor, nie tenant-weit; Owner/UAA = Deny-List |
| ⑤ | **High-Priv Grant** | **nichts** — JIT via PIM-Fenster | Write (Tier-0) | H3 | nur im offenen, freigegebenen Fenster wirksam — sonst nutzlos |

**Wie ein Executor aufgesetzt wird (jeder gleich, per IaC):**

```mermaid
flowchart LR
    AR["App Registration<br/>(eigene, je Executor)"] --> FIC["Federated Identity<br/>Credential (secretless)"]
    FIC --> CA["Conditional Access<br/>for Workload Identities<br/>(IP-Lock je Executor)"]
    CA --> RUN["Azure Container App Job<br/>(eigene Identität, fester NAT-Egress)"]
    RUN --> BASE["Least-Privilege<br/>Graph-/ARM-Rolle"]
```

- **Eigene App Registration + FIC** je Executor → kein geteiltes Credential; ein Leak trifft nur einen.
- **Eigene Conditional-Access-Policy** (IP-Lock) → ein gestohlenes Token von anderer IP ist nutzlos. (Managed Identities sind hier ausgeschlossen → daher App Reg + FIC + fester NAT-Egress.)
- **Eigene Anomaly-Baseline** → jeder Executor hat ein enges, vorhersagbares Verhalten; Abweichung fällt sofort auf.

---

## 6. Was läuft wo & wann (Runtime-Topologie)

```mermaid
flowchart TB
    subgraph vnet["Privates VNet (germanywestcentral)"]
      subgraph acaShared["ACA Environment — gehärtet, geteilt"]
        API["API / UI-Backend (Container, dauerhaft)"]
        V["Verifier-Job"]
        L["Lifecycle-Job"]
        C["Credential-Job"]
      end
      subgraph acaT0["ACA Environment — Tier-0-Write, isoliert"]
        R["Azure-RBAC-Job (on-demand, ephemer)"]
        H["High-Priv-Job (nur im PIM-Fenster, ephemer)"]
      end
      PE["Private Endpoints → KV · PostgreSQL · Storage · ARM"]
    end
    NAT["NAT Gateway (feste Egress-IP)"]
    GRAPH["Microsoft Graph (öffentl. API)"]

    acaShared & acaT0 --> PE
    acaShared & acaT0 --> NAT --> GRAPH
```

| Was | Wo | Wann | Auslöser |
|---|---|---|---|
| **API / UI-Backend** | ACA (dauerhafter Container) | immer | Nutzer-Requests |
| **Verifier** (Reports, Verifikation, Drift-Scan) | ACA-Job, geteilter Runner | **geplant** (z. B. täglich) + on-demand | Scheduler / UI |
| **Lifecycle / Credential** | ACA-Job, geteilter Runner | **on-demand** | genehmigter Antrag |
| **Azure-RBAC** | ACA-Job, **isolierte** Env | **on-demand**, ephemer | genehmigter Antrag (H2–H3) |
| **High-Priv Grant** | ACA-Job, **isolierte** Env | **nur** im time-boxed PIM-Fenster | Team-Aktivierung nach Quorum |
| **Drift-Detektion** | Verifier + `terraform plan` | **täglich** (Frequenz konfigurierbar) | Scheduler |
| **Backup** | Managed (PITR + Daily-Snapshot) | kontinuierlich + täglich | Plattform |

**Wichtig:** Verbindungen zu KV/DB/Storage/ARM laufen über **Private Endpoints**. Nur Microsoft Graph hat kein Private Link → Ausgang über die **feste NAT-Egress-IP**, abgesichert durch den CA-IP-Lock + CAE + ID Protection.

---

## 7. Kern-Abläufe (vereinfacht)

### 7a. App anlegen / ändern (mit Freigabe)
```mermaid
sequenceDiagram
    participant U as Owner/Admin
    participant API as API
    participant WF as Approval-Engine
    participant EX as Executor
    participant E as Entra
    U->>API: Antrag (neue App / Änderung + Parameter)
    API->>API: Terraform-Plan aus Template, Härte klassifizieren (H0–H3)
    API->>WF: Freigabe je Härte (Peer / Security-Quorum / Team+PIM)
    WF-->>API: planHash freigegeben
    API->>EX: apply tfplan (genau dieser Plan)
    EX->>E: App Registration + Enterprise App
    EX-->>API: Ergebnis + WORM-Audit
```

### 7b. Credential-Lebenszyklus
```mermaid
sequenceDiagram
    participant O as Owner
    participant API as API
    participant C as Credential-Executor
    participant KV as Key Vault
    participant E as Entra
    O->>API: Secret/Cert/FIC anfordern
    alt FIC (bevorzugt)
        API->>C: FIC anlegen (secretless, via Terraform)
    else Certificate
        C->>KV: Cert erzeugen (Private Key bleibt im KV)
        C->>E: nur Public Key (addKey)
    else Client Secret
        C->>E: addPassword (Wert entsteht in Entra)
        C->>KV: Wert direkt in KV (nie in Logs/State)
    end
    API-->>O: Referenz / Ablaufdatum (Wert nie im Klartext ausgegeben)
```

### 7c. Drift-Kontrolle
```mermaid
sequenceDiagram
    participant SCH as Scheduler
    participant REC as Drift-Engine
    participant TF as terraform plan
    participant AUD as directoryAudits
    SCH->>REC: täglicher Lauf
    REC->>TF: Soll-vs-Ist-Diff (Was)
    REC->>AUD: Wer/Wann/Wie
    REC->>REC: korrelieren + Severity (Change-Klassifikator)
    REC-->>REC: Drift-Board: Revert (rückgängig) oder Adopt (übernehmen + Begründung)
```

### 7d. High-Priv-Grant (der gefährlichste Pfad)
```mermaid
sequenceDiagram
    participant U as Antragsteller
    participant WF as Approval-Engine
    participant T as Team-Mitglied
    participant PIM as PIM
    participant H as High-Priv-Executor
    U->>WF: Antrag (z. B. Directory.ReadWrite.All)
    WF->>WF: H3 — Team-Quorum + 1 Security
    WF->>T: nach Freigabe: PIM aktivieren (YubiKey, PAW)
    T->>PIM: Aktivierung → Executor bekommt time-boxed active
    PIM-->>H: Fenster offen (z. B. 1 h)
    H->>H: ausführen → Recht läuft automatisch ab
```

---

## 8. Datenmodell (hohe Ebene)

```mermaid
erDiagram
    BUSINESS_APP ||--o{ IDENTITY_LINK : "1:n"
    APP_IDENTITY ||--o{ IDENTITY_LINK : "gehört zu"
    APP_IDENTITY ||--o{ CREDENTIAL_META : "hat"
    APP_IDENTITY ||--o{ ENTITLEMENT : "hält auf Zielsystem"
    BUSINESS_APP {
      string name
      string owner_group_oid
      string provenance "native|cmdb-linked"
      string cmdb_ci_ref "nullable"
    }
    APP_IDENTITY {
      string object_id
      string tier "M|A|P|E"
      string db_owner_oid
    }
    IDENTITY_LINK { string function "SSO|SCIM|Automation|API" }
    CREDENTIAL_META { string type "FIC|Cert|Secret" ; date expiry }
    ENTITLEMENT { string system "AzureRBAC|PowerBI|SharePoint" ; string declared_vs_actual }
```

Die DB hält **Metadaten**, nie Geheimnisse (die liegen im Key Vault). „Owner" sind Entra-Objekt-IDs/Gruppen, kein Freitext (DSGVO-Minimierung).

---

## 9. Sicherheits-Architektur (Zusammenfassung)

| Dimension | Umsetzung |
|---|---|
| **Trennung der Macht** | UI ohne Schreibrechte; nur Executors ändern; Orchestrator ohne Rechte |
| **Secretless** | FIC statt Client Secrets für alle EAGP-Identitäten |
| **Private-first** | Kein öffentlicher Zugriff; Private Endpoints; CA-IP-Lock je Executor |
| **Gestufte Freigabe** | H0 autonom · H1 Peer · H2 Security-Quorum · H3 Team+Security+PIM |
| **Deny-List** | Tenant-übernahme-fähige Rechte nie per Self-Service |
| **Nachweis** | WORM-Audit (unveränderlich) + Split-Sink nach Sentinel |
| **Not-Aus** | Kill-Switch / Emergency-Revoke, serverseitig |
| **Resilienz** | Immutable-Backup (WORM) + Soft Delete + Multi-User-Authorization; getestete Restores; Portal = Emergency-Fallback |

---

## 10. CI/CD & Umgebungen

```mermaid
flowchart LR
    PR["Pull Request"] --> CI["CI: Lint · Unit-Tests (mock) · terraform validate/tfsec · SAST · Secret-Scan · Container-Scan"]
    CI --> DEV["Dev-Deploy → Dev-Tenant<br/>Integration gegen echtes Directory"]
    DEV --> GATE{"Gate: Tests grün + Approval + planHash"}
    GATE --> PROD["Prod-Deploy → Prod-Tenant<br/>gestufte Freigabe für High-Priv"]
```

- **„Umgebung" = eigener Entra-Tenant.** Erst gegen einen separaten **Dev-Tenant** deployen und testen, dann **Prod**.
- **Secretless Pipeline-Auth** über Workload Identity Federation (je Tenant eine Service Connection).
- **Test-Pyramide:** viele Unit-Tests (gemockt) · Policy-Tests auf Plänen (Deny-List-Gate, keine Secrets im State) · echte **Integrationstests im Dev-Tenant** · manuelle Freigabe → Prod.
- **Parität-Handling:** EAGP erkennt je Tenant, was verfügbar/lizenziert ist (P2, CA-for-WI); wo Dev von Prod abweicht, laufen die betroffenen Tests als **Prod-Canary** (report-only, enger Scope), statt „grün in Dev" fälschlich als prod-safe zu werten.

---

## 11. Netzwerk & Vertrauensgrenzen (Kurzfassung)

| Grenze | Regel |
|---|---|
| Nutzer → UI | intern only, MFA, Zscaler; keine öffentliche Exposition |
| UI → API | interne Aufrufe; UI hat keine Entra-Rechte |
| API → Executors | über Orchestrator; Executors authentifizieren unabhängig (FIC) |
| Executors → KV/DB/Storage/ARM | **Private Endpoints** |
| Executors → Microsoft Graph | öffentliche API über **feste NAT-Egress-IP** + CA-IP-Lock |
| EAGP → ServiceNow | **read-only** (nie zurückschreiben), OAuth + IP-Allowlist |
| EAGP → Sentinel/SIEM | WORM-Events (Split-Sink) |

---

## 12. Technologie-Landkarte (Schnellreferenz)

| Frage | Antwort |
|---|---|
| **Was baut die App?** | Claude Code, in isolierter Umgebung ohne Prod-/Echt-Tenant-Zugang |
| **Womit ist sie gebaut?** | Terraform (Provisioning) + Python/FastAPI (App & Graph-Ops) + React (UI) |
| **Wo läuft sie?** | Azure Container Apps (Jobs) in privatem VNet, germanywestcentral |
| **Wo liegen Daten?** | PostgreSQL Flexible Server (Metadaten) + Key Vault (Secrets) + Blob (State) + WORM (Audit) |
| **Wie kommt Code nach Prod?** | Azure DevOps → Dev-Tenant → Test → Gate → Prod-Tenant (secretless) |
| **Wer darf schreiben?** | Nur 5 minimal-berechtigte Executors; die gefährlichsten nur JIT im PIM-Fenster |
| **Wie sicher ist es?** | Tier-0: secretless, private-first, gestufte Freigabe, Deny-List, WORM-Audit, Kill-Switch, Immutable-Backup |

---

*Referenzen: `DECISIONS.md` (ADR-001…043, autoritativ) · `SPEC.md` (fachliche Spezifikation) · `FEATURE_PARITY.md` (Funktionsumfang + Härte) · `TASKS.md` (Backlog).*
