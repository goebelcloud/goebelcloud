# EAGP — Gesamtpaket (QA-geprüft)

**Entra App Governance Platform** — geschlossenes, in sich konsistentes Deliverable-Paket. Voll-QA durchgeführt: durchgängig **ADR-001…043**, Stack **Terraform + Python** (kein PowerShell in der Runtime, kein .NET), DB **PostgreSQL Flexible Server**, Runtime **Azure Container Apps (Jobs)**, **~5 Least-Privilege-Executors** (App Reg + FIC), CI/CD **Azure DevOps** Dev-Tenant → Prod-Tenant.

## Inhalt & Lesereihenfolge
- **`claude-code/`** — Übergabe-Dossier (Start: **`CLAUDE.md`**), autoritatives `DECISIONS.md` (ADR-001…043), `SPEC.md`, `TASKS.md`, `FEATURE_PARITY.md`, u. a.; `.claude/` Guardrails; `eagp-assessment.ps1` (read-only, zuerst laufen).
- **`management/`** — `EAGP_Entscheidungsvorlage.docx` (~10 S.) + `..._Praesentation.pptx` (23 Folien). Entscheidungen M1–M7.
- **`architektur/`** — **`EAGP_Architektur.html`** (im Browser öffnen) + `.docx` + `.pptx` + `ARCHITECTURE.md`.
- **`mockup/`** — **`EAGP_Mockup.html`** (klickbar; Beispieldaten, kein echter Tenant).

## Wer bekommt was
| Zielgruppe | Ordner | Einstieg |
|---|---|---|
| Umsetzung (Claude Code / Dev) | `claude-code/` | `CLAUDE.md` |
| Management | `management/` | `EAGP_Entscheidungsvorlage.docx` |
| Team & technische Leitung | `architektur/` | `EAGP_Architektur.html` |
| „Wie sieht es aus?" | `mockup/` | `EAGP_Mockup.html` |

## Offen (klein, nicht bau-blockierend)
Governance-MG-ID · feste NAT-Egress-IP je Executor · **P2 im Dev-Tenant?** (sonst PIM-/CA-Tests als Prod-Canary) · Owner-Scope beim Reveal. Details: `claude-code/DECISIONS.md` (Teil D).
